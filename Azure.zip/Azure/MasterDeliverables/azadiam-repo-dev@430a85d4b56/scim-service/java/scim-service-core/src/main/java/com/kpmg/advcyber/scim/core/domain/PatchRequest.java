package com.kpmg.advcyber.scim.core.domain;

import java.util.List;

public class PatchRequest {
	private List<String> schemas;
	private List<PatchOperation> Operations;

	public List<String> getSchemas() {
		return schemas;
	}

	public void setSchemas(List<String> schemas) {
		this.schemas = schemas;
	}

	public List<PatchOperation> getOperations() {
		return Operations;
	}

	public void setOperations(List<PatchOperation> operations) {
		Operations = operations;
	}
	
	public String toString() {
		String returnString = "";
		if( schemas !=null && schemas.size()>0 ) {
			returnString += "Schema: ";
			for( int i=0; i<schemas.size(); i++) {
				returnString += "schemas["+i+"]: "+schemas.get(i);
			}						
		}
		
		if( Operations !=null && Operations.size()>0 ) {
			returnString += "Operations: ";
			for( int i=0; i<Operations.size(); i++) {
				returnString += "Operations["+i+"]: ";
				if(Operations.get(i)!=null) {
					returnString += ""+Operations.get(i).toString();					
				} else {
					returnString += "null";
				}
			}						
		}
		
		System.out.println("Patch Return String: "+returnString);
		return returnString;
	}
}
