package com.kpmg.advcyber.scim.core;

import java.util.List;
import java.util.Optional;

import org.springframework.context.ApplicationContext;

import com.kpmg.advcyber.scim.core.domain.PatchRequest;
import com.kpmg.advcyber.scim.core.domain.SearchParameter;

/**
 * Interface that will abstract the underlying repository implementation.
 * 
 * @param <T>
 */
public interface Repository<T> {
	Optional<T> get(String id) throws Exception;

	List<T> getAll(SearchParameter params);

	T save(T t);

	T update(T t) throws Exception;

	T updatePartial(PatchRequest patchRequest, String resourceId) throws Exception;

	void delete(String id) throws Exception;

	void setApplicationContext(ApplicationContext applicationContext);
}
