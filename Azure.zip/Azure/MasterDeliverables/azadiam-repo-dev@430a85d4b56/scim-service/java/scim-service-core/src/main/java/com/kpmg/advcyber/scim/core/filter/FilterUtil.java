package com.kpmg.advcyber.scim.core.filter;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FilterUtil {
	
	Logger logger = LoggerFactory.getLogger(FilterUtil.class);
	
	public Filter buildFilter(String filterString) {
		logger.info("Entering build");
		
		if( filterString ==null || filterString.equals("") ) {
			logger.debug("null filter string passed");
			logger.info("Exiting build");
			return null;
		}
		
		String[] splitAndString = filterString.toLowerCase().split(" and ");
		if( splitAndString != null && splitAndString.length > 0 ) {
			if( splitAndString.length > 1 ) { // AND operator found!!
				AndFilter andFilter = new AndFilter();
				andFilter.setFilterType(FilterType.AND);
				ArrayList<Filter> filterList = new ArrayList<Filter>();
				for( int i=0; i<splitAndString.length; i++ ) {
					String currentFilterString = splitAndString[i];
					String[] splitEqString = currentFilterString.toLowerCase().split(" eq ");
					
					if( splitEqString != null && splitEqString.length == 2  ) {
						EqFilter equalFilter = new EqFilter();
						equalFilter.setFilterType(FilterType.EQUAL);
						equalFilter.setAttributeName(splitEqString[0].trim());
						equalFilter.setAttributeValue(splitEqString[1].trim());
						logger.debug("attr name: "+splitEqString[0].trim());
						logger.debug("attr value: "+splitEqString[1].trim());
						filterList.add(equalFilter);
					} else {
						logger.debug("Filter string is invalid. Not able to parse equals operator");
						return null;
					}					
				}
				//Returning AND filter
				if(filterList.size() > 0) {
					logger.debug("Filter list size: "+filterList.size());
					andFilter.setFilterList(filterList);
					return andFilter;
				} else {
					logger.debug("Could not find equals operators within AND filter.");
					logger.info("Exiting build");
					return null;
				}
			} else { // Single equals operator
				String[] splitEqString = splitAndString[0].toLowerCase().split(" eq ");
				if( splitEqString != null && splitEqString.length == 2  ) {
					EqFilter equalFilter = new EqFilter();
					equalFilter.setFilterType(FilterType.EQUAL);
					equalFilter.setAttributeName(splitEqString[0].trim());
					equalFilter.setAttributeValue(splitEqString[1].trim());
					
					logger.debug("Found single equals filter");
					logger.debug("attr name: "+splitEqString[0].trim());
					logger.debug("attr value: "+splitEqString[1].trim());
										
					logger.info("Exiting build");
					return equalFilter;
				} else {
					logger.debug("Filter string is invalid. Not able to parse equals operator");
					return null;
				}				
			}
		}
				
		logger.info("Exiting build");
		return null;
	}
}
