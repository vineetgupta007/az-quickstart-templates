package com.kpmg.advcyber.scim.core.domain;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GroupResource extends BaseResource{
	private String displayName;
	private List<Member> members;
	
	public GroupResource() {
		Set<String>schemaList = new HashSet<String>();
		schemaList.add("urn:ietf:params:scim:schemas:core:2.0:Group");
		super.setSchemas(schemaList);
		
		Meta meta = new Meta();
		meta.setResourceType("Group");
		super.setMeta(meta);
	}
	
	public String getDisplayName() {
		return displayName;
	}
	
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
	public List<Member> getMembers() {
		return members;
	}
	
	public void setMembers(List<Member> members) {
		this.members = members;
	}
	
	public String toString() {
		String returnString = "id: "+getId()+"externalId: "+getExternalId()+" displayName: "+displayName;
		
		if( members != null ) {
			for( int i=0; i<members.size(); i++ ) {
				if(members.get(i) != null) {
					returnString += members.get(i).toString();
				}				
			}
		}
		return returnString;
	}
}
