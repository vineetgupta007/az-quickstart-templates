package com.kpmg.advcyber.scim.core.filter;

import java.util.List;

public class AndFilter extends Filter{
	
	private List<Filter> filterList;

	public List<Filter> getFilterList() {
		return filterList;
	}

	public void setFilterList(List<Filter> filterList) {
		this.filterList = filterList;
	}		
}
