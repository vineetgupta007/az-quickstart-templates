package com.kpmg.advcyber.scim.core.filter;

public enum FilterType {
	AND("and"),
	EQUAL("eq");

	private String stringValue;

	FilterType(String stringValue) {
		this.stringValue = stringValue;
	}

	public String getStringValue() {
		return stringValue;
	}

	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}
}
