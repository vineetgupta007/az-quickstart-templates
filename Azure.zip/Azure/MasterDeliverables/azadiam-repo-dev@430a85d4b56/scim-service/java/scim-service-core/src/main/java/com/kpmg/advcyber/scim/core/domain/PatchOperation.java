package com.kpmg.advcyber.scim.core.domain;

public class PatchOperation {
	private String op;
	private String path;
	private Object value;
	
	public String getOp() {
		return op;
	}
	
	public void setOp(String op) {
		this.op = op;
	}
	
	public String getPath() {
		return path;
	}
	
	public void setPath(String path) {
		this.path = path;
	}
	
	public Object getValue() {
		return value;
	}
	
	public void setValue(Object value) {
		this.value = value;
	}
	
	public String toString( ) {		
		String returnString = "";
		returnString += "op: "+op+" path: "+path+" value: ";
		
		if( value!=null ) {
			returnString += value.toString();
		} else {
			returnString += "null";
		}
		
		System.out.println("PatchOperation toString: "+returnString);
		return returnString;
	}
}
