package com.kpmg.advcyber.scim.core.domain;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;

public abstract class BaseResource {
	private String id;
	private String externalId;
	private Set<String> schemas;
	private Meta meta;
	private Map<String, Object> extendedAttributes=new HashMap<>();
	
	@JsonAnySetter
    public void addCustomAttributes(String uri, Map<String, Object> map) {
		extendedAttributes.put(uri, map);
        schemas.add(uri);
    }
	
	@JsonAnyGetter
    public Map<String, Object> getCustomAttributes(){
        return extendedAttributes;
    }
	
	public Meta getMeta() {
		return meta;
	}
	public void setMeta(Meta meta) {
		this.meta = meta;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getExternalId() {
		return externalId;
	}
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}
	public Set<String> getSchemas() {
		return schemas;
	}
	public void setSchemas(Set<String> schemas) {
		this.schemas = schemas;
	}		
}
