package com.kpmg.advcyber.scim.core.filter;

public abstract class Filter {
	private FilterType filterType;

	public FilterType getFilterType() {
		return filterType;
	}

	public void setFilterType(FilterType filterType) {
		this.filterType = filterType;
	}
		
}
