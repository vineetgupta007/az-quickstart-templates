package com.kpmg.advcyber.scim.rest.persistence.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.kpmg.advcyber.scim.core.Repository;
import com.kpmg.advcyber.scim.core.domain.PatchRequest;
import com.kpmg.advcyber.scim.core.domain.SearchParameter;
import com.kpmg.advcyber.scim.core.domain.UserResource;

/**
 * This is a dummy implementation of the persistence layer. The purpose of this class is to be able
 * to deploy the SCIM REST service and test without having to implement any repository plug-in.
 *
 */
@Component
public class RepositoryDefaultUserImpl implements Repository<UserResource> {

	Logger logger = LoggerFactory.getLogger(RepositoryDefaultUserImpl.class);
	private ApplicationContext applicationContext;
	
	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	@Override
	public Optional get(String id) {
		logger.debug("Reached Default get user method");
		return null;
	}

	@Override
	public List<UserResource> getAll(SearchParameter params) {
		logger.debug("Reached Default get ALL users method");
		return null;
	}

	@Override
	public UserResource save(UserResource t) {
		logger.debug("Reached Default save user method");
		return null;
	}

	@Override
	public UserResource update(UserResource t) {
		logger.debug("Reached Default update user method");
		return null;
	}

	@Override
	public void delete(String id) {
		logger.debug("Reached Default delete user method");
	}

	@Override
	public UserResource updatePartial(PatchRequest patchRequest,
			String resourceId) throws Exception {
		logger.debug("Reached Default updatePartial user method");
		return null;
	}



}
