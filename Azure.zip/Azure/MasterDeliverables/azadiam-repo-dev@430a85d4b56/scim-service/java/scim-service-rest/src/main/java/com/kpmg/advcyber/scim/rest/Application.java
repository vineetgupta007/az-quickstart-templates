package com.kpmg.advcyber.scim.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Entry point to start the Spring Boot application.
 *
 */
@SpringBootApplication
@ComponentScan(basePackages = {"com.kpmg.advcyber.scim"})
public class Application {

	public static void main(String[] args) {	    	
		SpringApplication.run(Application.class, args);		
	}
}
