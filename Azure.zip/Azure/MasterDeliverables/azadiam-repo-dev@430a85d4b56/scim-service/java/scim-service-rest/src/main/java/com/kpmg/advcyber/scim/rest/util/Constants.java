package com.kpmg.advcyber.scim.rest.util;

public final class Constants {
	
	//Response related constants
	public static final String ERROR_SCHEMA="urn:ietf:params:scim:api:messages:2.0:Error";
	
	public static final String RESPONSE_400="400";
	public static final String BAD_REQUEST="bad request";
	
	public static final String RESPONSE_404="404";
	public static final String NOT_FOUND="not found";
	
	public static final String RESPONSE_409="409";
	public static final String UNIQUENESS="uniqueness";
	
	public static final String RESPONSE_500="500";
	public static final String INTERNAL_SERVER_ERROR="internal server error";
	
	//Attribute names
	public static final String DISPLAY_NAME="displayName";
	public static final String USER_NAME="UserName";

	//Properties
	public static final String ENTITY_TYPE="entityType";
	public static final String REPOSITORY="repository";
	
	// Operators
	public static final String EQUALS="eq";
	public static final String COMMA=",";
	
}
