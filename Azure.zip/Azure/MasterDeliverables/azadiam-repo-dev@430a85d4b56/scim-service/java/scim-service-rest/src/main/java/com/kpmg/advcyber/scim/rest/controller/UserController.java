package com.kpmg.advcyber.scim.rest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kpmg.advcyber.scim.core.Repository;
import com.kpmg.advcyber.scim.core.domain.BaseResource;
import com.kpmg.advcyber.scim.core.domain.ErrorResponse;
import com.kpmg.advcyber.scim.core.domain.ListResponse;
import com.kpmg.advcyber.scim.core.domain.PatchRequest;
import com.kpmg.advcyber.scim.core.domain.SearchParameter;
import com.kpmg.advcyber.scim.core.domain.UserResource;
import com.kpmg.advcyber.scim.rest.configuration.BackendMapping;
import com.kpmg.advcyber.scim.rest.persistence.factory.RepositoryFactory;
import com.kpmg.advcyber.scim.rest.util.Constants;

/**
 * REST methods for User CRUD operations. 
 * SCIM format is required in request payload.
 * 
 *
 */
@RestController
@RequestMapping(path = "v1/Users")
public class UserController {

	Logger logger = LoggerFactory.getLogger(UserController.class);

	RepositoryFactory<UserResource> repoFactory = new RepositoryFactory<UserResource>();

	private static final String entityName = "user";	

	@Autowired
	private BackendMapping backendMapping;
	
	@GetMapping("/listHeaders")
	public ResponseEntity<String> listAllHeaders(
	  @RequestHeader Map<String, String> headers) {
	    //headers.forEach((key, value) -> {
	    //    LOG.info(String.format("Header '%s' = %s", key, value));
	    //});
		
		for (Map.Entry<String, String> entry : headers.entrySet()) {
			logger.debug("Key : " + entry.getKey() + " Value : " + entry.getValue());
		}

		
	    return new ResponseEntity<String>(
	      String.format("Listed %d headers", headers.size()), HttpStatus.OK);
	}
	

	@GetMapping
	public ResponseEntity findAll(@RequestParam(value="count", defaultValue="20") Integer count, 
			@RequestParam(value="startIndex",defaultValue="1") Integer startIndex,
			@RequestParam(required = false) String filter) {
		logger.info("Entering findAll");
		try {
			logger.debug("Page count : {}",count);    		
			logger.debug("Start index : {}",startIndex);    		
			
			//Validations
			if(startIndex==null || startIndex<0 ) {
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_400);
	    		error.setDetail(Constants.BAD_REQUEST);
	    		List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.BAD_REQUEST);
			}
			if(count==null || count<0 || count>50 ) {
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_400);
	    		error.setDetail(Constants.BAD_REQUEST);
	    		List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.BAD_REQUEST);
			}
			
			SearchParameter params = new SearchParameter();
			params.setCount(count);
			params.setStartIndex(startIndex);
			params.setSearchFilter(filter);

			List<? extends BaseResource> userResourceList = new ArrayList<UserResource>();
			try {
				Repository<UserResource> currentRepo = repoFactory.getObject(entityName, backendMapping);	    		
				userResourceList = currentRepo.getAll(params);		
				if( userResourceList != null ) {
					logger.debug("Number of users found: {}",userResourceList.size());
				}
			} catch (Exception ex) {
				logger.debug("Exception occurred while fetching all users: {}",ex.getMessage(),ex);
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_500);
	    		error.setDetail(Constants.INTERNAL_SERVER_ERROR+": "+ex.getMessage());
	    		List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);   		
			}

			//Initialize response object
			ListResponse resp = new ListResponse();
			resp.setTotalResults(userResourceList.size());
			resp.setResources(userResourceList);
			resp.setItemsPerPage(count);
			resp.setStartIndex(startIndex);
			logger.info("Exiting findAll");
			return new ResponseEntity<ListResponse>(resp, HttpStatus.OK);
		} catch ( Exception ex ) {
			logger.debug("Exception while searching for all users", ex);

			ErrorResponse error = new ErrorResponse();
			error.setStatus(Constants.RESPONSE_500);
    		error.setDetail(Constants.INTERNAL_SERVER_ERROR+": "+ex.getMessage());
    		List<String> schemas = new ArrayList<String>();
			schemas.add(Constants.ERROR_SCHEMA);
			error.setSchemas(schemas);
			
			return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(path = "/{username}")
	public ResponseEntity find(@PathVariable("username") String username) {
		logger.info("Entering find");

		try {
			if(username==null || username.trim().equals("") ) {
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_400);
	    		error.setDetail(Constants.BAD_REQUEST);
	    		List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.BAD_REQUEST);
			}

			Repository<UserResource> currentRepo = repoFactory.getObject(entityName, backendMapping);	    
			Optional<UserResource> currentUser = currentRepo.get(username);

			//Returning 404 error code in response if user not found. Still returning status 200.
			if( !currentUser.isPresent() ) {
				logger.debug("User not found: {}",username);
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_404);
				error.setDetail(Constants.NOT_FOUND);
				List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
			}

			logger.info("Exiting find");
			return new ResponseEntity<UserResource>(currentUser.get(), HttpStatus.OK);
		} catch(Exception ex) {
			logger.debug("Exception while searching for user: {}",username, ex);

			ErrorResponse error = new ErrorResponse();
			error.setStatus(Constants.RESPONSE_500);
    		error.setDetail(Constants.INTERNAL_SERVER_ERROR+": "+ex.getMessage());
    		List<String> schemas = new ArrayList<String>();
			schemas.add(Constants.ERROR_SCHEMA);
			error.setSchemas(schemas);
			
			return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(consumes = "application/scim+json")
	public ResponseEntity create(@RequestBody UserResource user) {
		logger.info("Entering create");  	
		try {
			//Validate
			boolean isBadRequest = false;
			if(user==null) {
				isBadRequest=true;
			} else {
				String userName = user.getUserName();
		    	if( userName == null || userName.equals("") ) {
		    		isBadRequest=true;
		    	}
			}
			
			if( isBadRequest ) {
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_400);
	    		error.setDetail(Constants.BAD_REQUEST);
	    		List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.BAD_REQUEST);
			}
			
			logger.debug("Incoming User Resource: {}",user.toString());
			
			Repository<UserResource> currentRepo = repoFactory.getObject(entityName, backendMapping);
			logger.debug("Finding existing user: {}",user.getUserName());
			
			SearchParameter params = new SearchParameter();
			params.setCount(5);
			params.setStartIndex(0);
			params.setSearchFilter(Constants.USER_NAME+" "+Constants.EQUALS+" "+user.getUserName());

			List<? extends BaseResource> userResourceList = new ArrayList<UserResource>();
			try {
				userResourceList = currentRepo.getAll(params);				
			} catch (Exception ex) {
				logger.debug("Exception occurred while fetching all users: {}",ex.getMessage(),ex);
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_500);
	    		error.setDetail(Constants.INTERNAL_SERVER_ERROR+": "+ex.getMessage());
	    		List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);   		
			}
			
			if( userResourceList != null &&  userResourceList.size()>0) {
				logger.debug("Number of users found: {}",userResourceList.size());
				// User exists. Return error code 409(conflict)
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_409);
				error.setDetail(Constants.UNIQUENESS);
				List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.CONFLICT);
			}

			//Create user
			UserResource createdUser = currentRepo.save(user);

			logger.info("Exiting create");
			return new ResponseEntity<UserResource>(createdUser, HttpStatus.CREATED);
		} catch ( Exception ex ) {
			logger.debug("Exception while creating user: {}",user.getUserName(), ex);

			ErrorResponse error = new ErrorResponse();
			error.setStatus(Constants.RESPONSE_500);
    		error.setDetail(Constants.INTERNAL_SERVER_ERROR+": "+ex.getMessage());
    		List<String> schemas = new ArrayList<String>();
			schemas.add(Constants.ERROR_SCHEMA);
			error.setSchemas(schemas);
			
			return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping(path = "/{username}")
	public ResponseEntity delete(@PathVariable("username") String username) {
		logger.info("Entering delete");
		try {			
			Repository<UserResource> currentRepo = repoFactory.getObject(entityName, backendMapping);
			Optional<UserResource> existingUser = currentRepo.get(username);

			// Check if user exists
			if( !existingUser.isPresent() ) {
				// User does not exist. Return error code 404(not found)
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_404);
				error.setDetail(Constants.NOT_FOUND);
				List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.NOT_FOUND);
			}

			currentRepo.delete(username);
			logger.info("Exiting delete");
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}  catch ( Exception ex ) {
			logger.debug("Exception while deleting user: {}",username, ex);

			ErrorResponse error = new ErrorResponse();
			error.setStatus(Constants.RESPONSE_500);
    		error.setDetail(Constants.INTERNAL_SERVER_ERROR+": "+ex.getMessage());
    		List<String> schemas = new ArrayList<String>();
			schemas.add(Constants.ERROR_SCHEMA);
			error.setSchemas(schemas);
			
			return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping(path = "/{username}")
	public ResponseEntity update(@PathVariable("username") String username, @RequestBody UserResource user) {
		logger.info("Entering update");
		try {
			
			//Validate
			boolean isBadRequest = false;
			if(user==null) {
				isBadRequest=true;
			} else {
				String userName = user.getUserName();
		    	if( userName == null || userName.equals("") ) {
		    		isBadRequest=true;
		    	}
			}
			
			if(isBadRequest) {
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_400);
	    		error.setDetail(Constants.BAD_REQUEST);
	    		List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.BAD_REQUEST);
			}

			Repository<UserResource> currentRepo = repoFactory.getObject(entityName, backendMapping);
			Optional<UserResource> existingUser = currentRepo.get(username);

			// Check if user already exists
			if( !existingUser.isPresent() ) {
				// User does not exist. Return error code 404(not found)
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_404);
				error.setDetail(Constants.NOT_FOUND);
				List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.NOT_FOUND);
			}

			UserResource returnUser = currentRepo.update(user);

			logger.info("Exiting update");
			return new ResponseEntity<UserResource>(returnUser, HttpStatus.OK);
		} catch( Exception ex ) {
			logger.debug("Exception while updating user: {}",username, ex);

			ErrorResponse error = new ErrorResponse();
			error.setStatus(Constants.RESPONSE_500);
    		error.setDetail(Constants.INTERNAL_SERVER_ERROR+": "+ex.getMessage());
    		List<String> schemas = new ArrayList<String>();
			schemas.add(Constants.ERROR_SCHEMA);
			error.setSchemas(schemas);
			
			return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PatchMapping(path = "/{username}")
	public ResponseEntity updatePartial(@PathVariable("username") String username, 
			@RequestBody PatchRequest patchRequest) {
		logger.info("Entering updatePartial");
		try {
			logger.debug("Patch request received for user: {}",username);	
			logger.debug("request body: {}",patchRequest.toString());    	
			
			//Validate
			boolean isBadRequest = false;			
			if( patchRequest.getOperations()==null || patchRequest.getOperations().size()==0 ) {
				isBadRequest=true;
			}			
			if( username == null || username.equals("") ) {
				isBadRequest=true;
			}
			
			if(isBadRequest) {
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_400);
	    		error.setDetail(Constants.BAD_REQUEST);
	    		List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.BAD_REQUEST);
			}

			Repository<UserResource> currentRepo = repoFactory.getObject(entityName, backendMapping);
			Optional<UserResource> existingUser = currentRepo.get(username);
						
			// Check if user exists
			if( !existingUser.isPresent() ) {
				// User does not exist. Return error code 404(not found)
				ErrorResponse error = new ErrorResponse();
				error.setStatus(Constants.RESPONSE_404);
				error.setDetail(Constants.NOT_FOUND);
				List<String> schemas = new ArrayList<String>();
				schemas.add(Constants.ERROR_SCHEMA);
				error.setSchemas(schemas);
				
				return new ResponseEntity<ErrorResponse>(error, HttpStatus.NOT_FOUND);
			}
			
			logger.debug("User exists: {}",existingUser.get().toString());
			
			//PatchUserUtils utils = new PatchUserUtils();
			//UserResource updatedResource = utils.convertPatchToResource(patchRequest, existingUser.get());
			UserResource returnUser = currentRepo.updatePartial(patchRequest, username);
									
			logger.info("Exiting updatePartial");
			return new ResponseEntity<UserResource>(returnUser, HttpStatus.OK);
						
		} catch ( Exception ex ) {
			logger.debug("Exception while updating user: {}",username, ex);

			ErrorResponse error = new ErrorResponse();
			error.setStatus(Constants.RESPONSE_500);
    		error.setDetail(Constants.INTERNAL_SERVER_ERROR+": "+ex.getMessage());
    		List<String> schemas = new ArrayList<String>();
			schemas.add(Constants.ERROR_SCHEMA);
			error.setSchemas(schemas);
			
			return new ResponseEntity<ErrorResponse>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}				
	}		
}