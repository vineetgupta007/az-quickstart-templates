package com.kpmg.advcyber.scim.mysql.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name="USER")
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="user_id", nullable=false)
	private Integer userid;

	@Column(name="username", nullable=false)
	private String username;
	
	@Column(name="externalId", nullable=false)
	private String externalId;
	
	@Column(name="name")
    private String name;
	
	@Column(name="email")
    private String email;
	
	@Column(name="status")
    private String status;
	
	@Column(name="title")
    private String title;
    
	@Column(name="city")
	private String city;
	
	@Column(name="state_name")
	private String stateName;
	
	@Column(name="postal_code")
	private String postalCode;
	
	@Column(name="country")
	private String country;
	
	@Column(name="telephone_number")
	private String telephoneNumber;
	
	@Column(name="role")
	private String role;
	
	@Column(name="employee_number")
	private String employeeNumber;
	
	@Column(name="office")
	private String office;
	
	@Column(name="department")
	private String department;
	
	@Column(name="created", nullable = false, updatable = false)
	@CreationTimestamp
	private Date created;
	
	@Column(name="updated")
	@UpdateTimestamp
	private Date updated;			
	
	public String getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
       
    @Override
    public String toString() {
        return "User{userId= "+userid + "username= " + username + ", name= " + name + 
        		", email= " + email +", externalId= " + externalId + ", status= "
                + status+", title= "+title+" city= "+city+" stateName= "+stateName+
                " postalCode= "+postalCode+" Country= "+country+" telephoneNumber= "+telephoneNumber+
                " role= "+role+" employeeNumber= "+employeeNumber+" department= "+department+" office= "+office 
                +"}";
    }
}
