package com.kpmg.advcyber.scim.mysql.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;

import com.kpmg.advcyber.scim.core.domain.Address;
import com.kpmg.advcyber.scim.core.domain.Email;
import com.kpmg.advcyber.scim.core.domain.Name;
import com.kpmg.advcyber.scim.core.domain.PatchOperation;
import com.kpmg.advcyber.scim.core.domain.PatchRequest;
import com.kpmg.advcyber.scim.core.domain.PhoneNumber;
import com.kpmg.advcyber.scim.core.domain.Role;
import com.kpmg.advcyber.scim.core.domain.UserResource;
import com.kpmg.advcyber.scim.mysql.util.Constants;

public class PatchUserUtils {
	Logger logger = LoggerFactory.getLogger(PatchUserUtils.class);

	public UserResource convertPatchToResource(PatchRequest patchRequest, UserResource existingUser) throws Exception {
		logger.info("Entering convertPatchToMap");
		List<PatchOperation> patchOpList = patchRequest.getOperations();

		BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(existingUser);
		if( patchOpList != null && patchOpList.size() > 0 ) {
			logger.debug("Number of operations: {}",patchOpList.size());
			for( int i=0; i<patchOpList.size(); i++ ) {
				PatchOperation patchOp = patchOpList.get(i);
				String currentOperation = patchOp.getOp();
				String currentPath = patchOp.getPath();
				Object currentValue = patchOp.getValue();

				logger.debug("Processing: currentOperation: {} currentPath: {} currentValue: ",
						currentOperation,currentPath,currentValue);
				
				if(currentOperation.equalsIgnoreCase(Constants.REPLACE_OPERATION) || currentOperation.equalsIgnoreCase(Constants.ADD_OPERATION)) {
					//Multi-valued attribute with a specific type (eg. emails[type eq "work"].value )
					if( currentPath.contains(Constants.OPEN_SQ_BRACKET) ) {
						logger.debug("Current attribute has a [");
						processMultivaluedWithOperator(currentPath, currentValue, existingUser);
					} else if( currentPath.contains(Constants.ENTERPRISE_USER_SCHEMA) || 
							currentPath.contains("urn:ietf:params:scim:schemas:extension:CustomExtensionName:2.0:User")) {
						logger.debug("Current attribute is enterprise or custom user attribute.");
						processCustomAttrs(currentPath, existingUser, currentValue);
					} else if( currentPath.contains(Constants.PERIOD) ) { // Simple multi-valued attribute eg. name.familyName
						logger.debug("Current attribute has a period");
						processComplexAttribute(currentPath, existingUser);
						invokeSetter(currentPath,currentValue,wrapper);
					} else { //Just a regular single-valued attribute
						logger.debug("Current attribute is single valued attribute");
						invokeSetter(currentPath,currentValue,wrapper);
					}
				}/* else if(currentOperation.equalsIgnoreCase("remove")) { To be implemented
					if( currentPath.contains("[") ) {
						logger.debug("Current attribute has a [");
						processMultivalued(currentPath, currentValue, existingUser);
					} else if( currentPath.contains(".") ) { // Simple multi-valued attribute eg. name.familyName
						logger.debug("Current attribute has a period");
						invokeSetter(currentPath,currentValue,wrapper);
					} else if( currentPath.contains("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User")) {
						logger.debug("Current attribute is enterprise user attribute");
					} else { //Just a regular single-valued attribute
						logger.debug("Current attribute is single valued attribute");
						invokeSetter(currentPath,currentValue,wrapper);
					}
				}*/
			}			
		}
		
		logger.debug("Return resource: {}",existingUser.toString());
		logger.info("Exiting convertPatchToMap");
		return existingUser;
	}
	
/*	private void processEnterpriseAttrs(String currentPath, UserResource res, String currentValue) {
		logger.info("Entering processEnterpriseAttrs");		
		
		int index = currentPath.lastIndexOf(":");		
		String prefix = currentPath.substring(0, index);		
		String attr=currentPath.substring(index+1);		
		logger.debug("prefix: "+prefix+" attr: "+attr);
		
		Map<String,Object> customAttributesMap = res.getCustomAttributes();
		
		if( customAttributesMap == null ) {
			customAttributesMap = new HashMap<String,Object>();
		}
		
		HashMap<String,Object> enterpriseMap = (HashMap<String,Object>)customAttributesMap.get(attr);
		if(customAttributesMap.get(attr) == null) {
			enterpriseMap = new HashMap<String,Object>();
		}
		enterpriseMap.put(attr, currentValue);			
		
		res.addCustomAttributes(prefix, enterpriseMap);
		logger.info("Exiting processEnterpriseAttrs");
	}*/
	
	private void processCustomAttrs(String currentPath, UserResource res, Object currentValue) {
		logger.info("Entering processCustomAttrs");		
		
		int index = currentPath.lastIndexOf(":");		
		String prefix = currentPath.substring(0, index);		
		String attr=currentPath.substring(index+1);		
		logger.debug("prefix: "+prefix+" attr: "+attr);
		
		Map<String,Object> customAttributesMap = res.getCustomAttributes();
		
		if( customAttributesMap == null ) {
			customAttributesMap = new HashMap<String,Object>();
		}
		
		HashMap<String,Object> customAttrsMap = (HashMap<String,Object>)customAttributesMap.get(prefix);
		if(customAttrsMap == null ) {
			customAttrsMap = new HashMap<String,Object>();
		}
		customAttrsMap.put(attr, currentValue);			
		
		res.addCustomAttributes(prefix, customAttrsMap);
		logger.info("Exiting processCustomAttrs");
	}
	
	private void processComplexAttribute(String currentPath, UserResource res) {
		logger.info("Entering processComplexAttribute");
		//Parsing String of format attribute.subAttribute
		if( currentPath != null && !currentPath.equals(Constants.BLANK_STRING) ) {
			String[] splitPath = currentPath.split(Constants.PERIOD);
			if( splitPath!=null && splitPath.length == 2) {
				//Name is the only single-valued complex attribute in SCIM spec
				if( splitPath[0].equalsIgnoreCase(Constants.NAME) ) {
					logger.debug("Current attribute is name");
					Name currentName = res.getName();
					//Instantiating name attribute if it is null
					if( currentName == null ) {
						logger.debug("null name detected. Instantiating");
						currentName = new Name();
						res.setName(currentName);
					}
				}
			}
		}
		logger.info("Entering processComplexAttribute");
	}
	
	private void processMultivaluedWithOperator(String currentPath, Object value, UserResource res) throws Exception {
		logger.info("Entering processMultivaluedWithOperator");
		
		//Parsing String of format attribute[key eq value].subAttribute
		if( currentPath != null && !currentPath.equals(Constants.BLANK_STRING) ) {
			String[] splitPath = currentPath.split(Constants.PERIOD);
			if( splitPath!=null && splitPath.length == 2) {
				int openIndex = splitPath[0].indexOf(Constants.OPEN_SQ_BRACKET);
				int closeIndex = splitPath[0].indexOf(Constants.CLOSE_SQ_BRACKET);
				
				logger.debug("openIndex: {} closeIndex: {}",openIndex,closeIndex);
				
				//key eq value
				String conditionString = splitPath[0].substring(openIndex+1, closeIndex);
				//attribute
				String attributeString = splitPath[0].substring(0,openIndex);
				
				logger.debug("conditionString: {} attributeString: {}",conditionString,attributeString);
				//only eq operator supported
				String [] splitCondition = conditionString.split(Constants.EQUALS);
				if( splitCondition!=null && splitCondition.length == 2) {
					logger.debug("Expected format for eq operator");					
					
					String formattedType = splitCondition[1].trim().replaceAll(Constants.ENCLOSING_DOUBLE_QUOTES, Constants.BLANK_STRING);
					formattedType = formattedType.replaceAll(Constants.ENCLOSING_SINGLE_QUOTES, Constants.BLANK_STRING);
					
					checkAddReplace(res, attributeString, splitPath[1], value, formattedType);
				} else {
					logger.debug("Unexpected format for eq operator. Exiting");
					logger.info("Exiting processMultivaluedWithOperator");
					throw new Exception("Unexpected format for equals operator");
				}
			} else {
				logger.debug("Unexpected format for list based conditional attribute. Exiting");
				logger.info("Exiting processMultivaluedWithOperator");
				throw new Exception("Unexpected format for list based conditional attribute");
			}
		}
		
		logger.info("Exiting processMultivaluedWithOperator");
	}
		
	private void checkAddReplace(UserResource res, String attributeName, String key, Object value, String type) throws Exception {
		logger.info("Entering checkAddReplace");
		
		switch(attributeName) {
			case Constants.EMAILS: 
				 processEmails(res, key, value, type);
				 break;
			case Constants.ADDRESSES:
				processAddresses(res, key, value, type);
				break;
			case Constants.PHONE_NUMBERS:
				processPhoneNumbers(res, key, value, type);
				break;
			case Constants.ROLES:
				processUserRoles(res, key, value, type);
				break;
			default:
				logger.debug("Current attribute is not being handled: {}",attributeName);
				throw new Exception("Current attribute is not being handled: "+attributeName);
		}
				
		logger.info("Exiting checkAddReplace");
	}
	
	private void processUserRoles(UserResource res, String key, Object value, String type) {
		logger.info("Entering processUserRoles");
		boolean isNewEntry = false;
		
		if( res.getRoles() == null ) { //entry does not exist
			isNewEntry = true;				
		} else { //some entries exist
			List<Role> roleList = res.getRoles();
			if( roleList!=null && roleList.size()>0 ) {
				boolean isEntryFound = false;
				for( int i=0; i<roleList.size(); i++ ) {
					Role currentRole = roleList.get(i);
					
					if( type.equalsIgnoreCase(String.valueOf(currentRole.getPrimary()) )) {
						logger.debug("Found role of existing type: {}",type);
						if( key.equalsIgnoreCase(Constants.DISPLAY) ) {
							currentRole.setDisplay((String)value);
						} else if( key.equalsIgnoreCase(Constants.TYPE) ) {
							currentRole.setType((String)value);
						} else if( key.equalsIgnoreCase(Constants.VALUE) ) {
							currentRole.setValue((String)value);
						}
						logger.debug("Completed setting role list values");
						isEntryFound=true;
						break;
					}
				}				
				if( !isEntryFound ) { //entry of primary role was not found after iterating the list
					logger.debug("Add new role entry to existing list");					
					Role currentRole = new Role();
					currentRole.setPrimary(Boolean.valueOf(type));
					
					if( key.equalsIgnoreCase(Constants.DISPLAY) ) {
						currentRole.setDisplay((String)value);
					} else if( key.equalsIgnoreCase(Constants.TYPE) ) {
						currentRole.setPrimary((Boolean)value);
					} else if( key.equalsIgnoreCase(Constants.VALUE) ) {
						currentRole.setValue((String)value);
					}
					logger.debug("Setting new Role list to user resource");
					res.getRoles().add(currentRole);
				}
			} else { //Role list attribute exists but is either null or empty list
				isNewEntry = true;				
			}			
		}
		
		if(isNewEntry == true) {
			logger.debug("New role entry detected");
			ArrayList<Role> roleList = new ArrayList<Role>();
			Role currentRole = new Role();
			currentRole.setPrimary(Boolean.valueOf(type));
			
			if( key.equalsIgnoreCase(Constants.DISPLAY) ) {
				currentRole.setDisplay((String)value);
			} else if( key.equalsIgnoreCase(Constants.TYPE) ) {
				currentRole.setPrimary((Boolean)value);
			} else if( key.equalsIgnoreCase(Constants.VALUE) ) {
				currentRole.setValue((String)value);
			}
			logger.debug("Setting new Role list to user resource");
			roleList.add(currentRole);
			res.setRoles(roleList);
		}
		logger.info("Exiting processUserRoles");
	}
	
	private void processPhoneNumbers(UserResource res, String key, Object value, String type) {
		logger.info("Entering processPhoneNumbers");
		boolean isNewEntry = false;
		
		if( res.getPhoneNumbers() == null ) { //entry does not exist
			isNewEntry = true;				
		} else { //some entries exist
			List<PhoneNumber> phoneNumberList = res.getPhoneNumbers();
			if( phoneNumberList!=null && phoneNumberList.size()>0 ) {
				boolean isEntryFound = false;
				for( int i=0; i<phoneNumberList.size(); i++ ) {
					PhoneNumber currentPhoneNumber = phoneNumberList.get(i);
					
					if( type.equalsIgnoreCase(currentPhoneNumber.getType()) ) {
						logger.debug("Found phone Number of existing type: {}",type);
						if( key.equalsIgnoreCase(Constants.DISPLAY) ) {
							currentPhoneNumber.setDisplay((String)value);
						} else if( key.equalsIgnoreCase(Constants.PRIMARY) ) {
							currentPhoneNumber.setPrimary((Boolean)value);
						} else if( key.equalsIgnoreCase(Constants.VALUE) ) {
							currentPhoneNumber.setValue((String)value);
						}
						logger.debug("Completed setting phoneNumber list values");
						isEntryFound=true;
						break;
					}
				}				
				if( !isEntryFound ) { //entry of listed email type was not found after iterating the list
					logger.debug("Add new phoneNumber entry to existing list");					
					PhoneNumber currentPhoneNumber = new PhoneNumber();
					currentPhoneNumber.setType(type);
					
					if( key.equalsIgnoreCase(Constants.DISPLAY) ) {
						currentPhoneNumber.setDisplay((String)value);
					} else if( key.equalsIgnoreCase(Constants.PRIMARY) ) {
						currentPhoneNumber.setPrimary((Boolean)value);
					} else if( key.equalsIgnoreCase(Constants.VALUE) ) {
						currentPhoneNumber.setValue((String)value);
					}
					logger.debug("Setting new Phone Number list to user resource");
					res.getPhoneNumbers().add(currentPhoneNumber);
				}
			} else { //Phone Number list attribute exists but is either null or empty list
				isNewEntry = true;				
			}			
		}
		
		if(isNewEntry == true) {
			logger.debug("New phoneNumber entry detected");
			ArrayList<PhoneNumber> phoneNumberList = new ArrayList<PhoneNumber>();
			PhoneNumber currentPhoneNumber = new PhoneNumber();
			currentPhoneNumber.setType(type);
			
			if( key.equalsIgnoreCase(Constants.DISPLAY) ) {
				currentPhoneNumber.setDisplay((String)value);
			} else if( key.equalsIgnoreCase(Constants.PRIMARY) ) {
				currentPhoneNumber.setPrimary((Boolean)value);
			} else if( key.equalsIgnoreCase(Constants.VALUE) ) {
				currentPhoneNumber.setValue((String)value);
			}
			logger.debug("Setting new phoneNumber list to user resource");
			phoneNumberList.add(currentPhoneNumber);
			res.setPhoneNumbers(phoneNumberList);
		}
		logger.info("Exiting processPhoneNumbers");
	}
	
	private void processAddresses(UserResource res, String key, Object value, String type) {
		logger.info("Entering processAddresses");
		boolean isNewEntry = false;
		if( res.getAddresses() == null ) { //entry does not exist
			isNewEntry = true;				
		} else { //some entries exist
			List<Address> addressList = res.getAddresses();
			if( addressList!=null && addressList.size()>0 ) {
				boolean isEntryFound = false;
				for( int i=0; i<addressList.size(); i++ ) {
					Address currentaddress = addressList.get(i);

					if( type.equalsIgnoreCase(currentaddress.getType()) ) {
						logger.debug("Found address of existing type: {}",type);
						if( key.equalsIgnoreCase(Constants.STREET_ADDRESS) ) {
							currentaddress.setStreetAddress((String)value);
						} else if( key.equalsIgnoreCase(Constants.LOCALITY) ) {
							currentaddress.setLocality((String)value);
						} else if( key.equalsIgnoreCase(Constants.REGION) ) {
							currentaddress.setRegion((String)value);
						} else if( key.equalsIgnoreCase(Constants.POSTAL_CODE) ) {
							currentaddress.setPostalCode((String)value);
						} else if( key.equalsIgnoreCase(Constants.COUNTRY) ) {
							currentaddress.setCountry((String)value);
						} else if( key.equalsIgnoreCase(Constants.PRIMARY) ) {
							currentaddress.setPrimary((Boolean)value);
						}
						
						logger.debug("Completed setting address list values");
						isEntryFound=true;
						break;
					}
				}				
				if( !isEntryFound ) { //entry of listed address type was not found after iterating the list
					logger.debug("Add new address entry to existing list");					
					Address currentaddress = new Address();
					currentaddress.setType(type);
					
					if( key.equalsIgnoreCase(Constants.STREET_ADDRESS) ) {
						currentaddress.setStreetAddress((String)value);
					} else if( key.equalsIgnoreCase(Constants.LOCALITY) ) {
						currentaddress.setLocality((String)value);
					} else if( key.equalsIgnoreCase(Constants.REGION) ) {
						currentaddress.setRegion((String)value);
					} else if( key.equalsIgnoreCase(Constants.POSTAL_CODE) ) {
						currentaddress.setPostalCode((String)value);
					} else if( key.equalsIgnoreCase(Constants.COUNTRY) ) {
						currentaddress.setCountry((String)value);
					} else if( key.equalsIgnoreCase(Constants.PRIMARY) ) {
						currentaddress.setPrimary((Boolean)value);
					}
					logger.debug("Setting new address list to user resource");
					res.getAddresses().add(currentaddress);
				}
			} else { //Address list attribute exists but is either null or empty list
				isNewEntry = true;				
			}
		}
		
		if(isNewEntry == true) {
			logger.debug("New email entry detected");
			ArrayList<Address> addresses = new ArrayList<Address>();
			Address currentaddress = new Address();
			currentaddress.setType(type);
			
			if( key.equalsIgnoreCase(Constants.STREET_ADDRESS) ) {
				currentaddress.setStreetAddress((String)value);
			} else if( key.equalsIgnoreCase(Constants.LOCALITY) ) {
				currentaddress.setLocality((String)value);
			} else if( key.equalsIgnoreCase(Constants.REGION) ) {
				currentaddress.setRegion((String)value);
			} else if( key.equalsIgnoreCase(Constants.POSTAL_CODE) ) {
				currentaddress.setPostalCode((String)value);
			} else if( key.equalsIgnoreCase(Constants.COUNTRY) ) {
				currentaddress.setCountry((String)value);
			} else if( key.equalsIgnoreCase(Constants.PRIMARY) ) {
				currentaddress.setPrimary((Boolean)value);
			}
			logger.debug("Setting new Address list to user resource");
			addresses.add(currentaddress);
			res.setAddresses(addresses);
		}
		logger.info("Exiting processAddresses");
	}
	
	private void processEmails(UserResource res, String key, Object value, String type) {
		logger.info("Entering processEmails");
		boolean isNewEntry = false;
		
		if( res.getEmails() == null ) { //entry does not exist
			isNewEntry = true;				
		} else { //some entries exist
			List<Email> emailList = res.getEmails();
			if( emailList!=null && emailList.size()>0 ) {
				boolean isEntryFound = false;
				for( int i=0; i<emailList.size(); i++ ) {
					Email currentEmail = emailList.get(i);
					
					if( type.equalsIgnoreCase(currentEmail.getType()) ) {
						logger.debug("Found email of existing type: {}",type);
						if( key.equalsIgnoreCase(Constants.DISPLAY) ) {
							currentEmail.setDisplay((String)value);
						} else if( key.equalsIgnoreCase(Constants.PRIMARY) ) {
							currentEmail.setPrimary((Boolean)value);
						} else if( key.equalsIgnoreCase(Constants.VALUE) ) {
							currentEmail.setValue((String)value);
						}
						logger.debug("Completed setting emails list values");
						isEntryFound=true;
						break;
					}
				}				
				if( !isEntryFound ) { //entry of listed email type was not found after iterating the list
					logger.debug("Add new email entry to existing list");					
					Email email = new Email();
					email.setType(type);
					
					if( key.equalsIgnoreCase(Constants.DISPLAY) ) {
						email.setDisplay((String)value);
					} else if( key.equalsIgnoreCase(Constants.PRIMARY) ) {
						email.setPrimary((Boolean)value);
					} else if( key.equalsIgnoreCase(Constants.VALUE) ) {
						email.setValue((String)value);
					}
					logger.debug("Setting new Emails list to user resource");
					res.getEmails().add(email);
				}
			} else { //Emails list attribute exists but is either null or empty list
				isNewEntry = true;				
			}			
		}
		
		if(isNewEntry == true) {
			logger.debug("New email entry detected");
			ArrayList<Email> emails = new ArrayList<Email>();
			Email email = new Email();
			email.setType(type);
			
			if( key.equalsIgnoreCase(Constants.DISPLAY) ) {
				email.setDisplay((String)value);
			} else if( key.equalsIgnoreCase(Constants.PRIMARY) ) {
				email.setPrimary((Boolean)value);
			} else if( key.equalsIgnoreCase(Constants.VALUE) ) {
				email.setValue((String)value);
			}
			logger.debug("Setting new Emails list to user resource");
			emails.add(email);
			res.setEmails(emails);
		}
		logger.info("Exiting processEmails");
	}

	private void invokeSetter(String attributeName, Object attributeValue, BeanWrapper wrapper) {
		logger.info("Entering invokeSetter");

		if( attributeName == null || attributeName.equals(Constants.BLANK_STRING) || attributeValue ==null) {
			logger.debug("Invalid attribute name or value");
		} else {
			logger.debug("Processing single valued attribute: {}",attributeName);

			//Setting property value
			wrapper.setPropertyValue(attributeName, attributeValue);
		}
		logger.info("Exiting invokeSetter");
	}
}
