package com.kpmg.advcyber.scim.mysql.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kpmg.advcyber.scim.core.domain.GroupResource;
import com.kpmg.advcyber.scim.core.domain.Member;
import com.kpmg.advcyber.scim.core.domain.PatchOperation;
import com.kpmg.advcyber.scim.core.domain.PatchRequest;
import com.kpmg.advcyber.scim.mysql.util.Constants;

public class PatchGroupUtils {
	Logger logger = LoggerFactory.getLogger(PatchGroupUtils.class);
	
	public Map<String,GroupResource> convertPatchToResource(PatchRequest patchRequest, GroupResource existingGroup) throws Exception {
		logger.info("Entering convertPatchToResource");
		List<PatchOperation> patchOpList = patchRequest.getOperations();
		if( patchOpList != null && patchOpList.size() > 0 ) {
			logger.debug("Number of operations: "+patchOpList.size());
			GroupResource addGroupOp = null;
			GroupResource removeGroupOp = null;
			boolean isAdd = false;
			boolean isRemove=false;
			for( int i=0; i<patchOpList.size(); i++ ) {
				PatchOperation patchOp = patchOpList.get(i);
				String currentOperation = patchOp.getOp();
				String currentPath = patchOp.getPath();
				Object currentValue = patchOp.getValue();

				logger.debug("Processing: currentOperation: "+currentOperation+" currentPath: "
						+currentPath+" currentValue: "+currentValue);				
				if(currentOperation.equalsIgnoreCase(Constants.ADD_OPERATION)) {
					if(addGroupOp == null) {
						logger.debug("Initializing add group resource");
						addGroupOp = new GroupResource();						
						List<Member> addMemberOpList = new ArrayList<Member>();
						addGroupOp.setMembers(addMemberOpList);
						isAdd=true;
					}
					
					processAddOperation(currentPath, currentValue, addGroupOp);
				} else if(currentOperation.equalsIgnoreCase(Constants.REMOVE_OPERATION)) {
					if(addGroupOp == null) {
						logger.debug("Initializing remove group resource");
						removeGroupOp = new GroupResource();						
						List<Member> removeMemberOpList = new ArrayList<Member>();
						removeGroupOp.setMembers(removeMemberOpList);
						isRemove=true;
					}
					
					processRemoveOperation(currentPath, currentValue, removeGroupOp);
				}
			}
			
			Map<String,GroupResource> returnMap = new HashMap<String,GroupResource>();
			if( isAdd ) {
				logger.info("Atleast one add operation detected");
				addGroupOp.setId(existingGroup.getId());
				logger.debug("Add group: "+addGroupOp.toString());
				returnMap.put(Constants.ADD_OPERATION, addGroupOp);
			} else {
				returnMap.put(Constants.ADD_OPERATION, null);
			}
			
			if( isRemove ) {
				logger.info("Atleast one remove operation detected");
				removeGroupOp.setId(existingGroup.getId());
				logger.debug("Remove group: "+removeGroupOp.toString());
				returnMap.put(Constants.REMOVE_OPERATION, removeGroupOp);
			} else {
				returnMap.put(Constants.REMOVE_OPERATION, null);
			}
						
			logger.info("Exiting convertPatchToResource");
			return returnMap;
		}
		
		logger.debug("No operations detected. Returning null.");
		logger.info("Exiting convertPatchToResource");
		return null;
	}
	
	private void processRemoveOperation(String currentPath, Object currentValue, GroupResource removeGroupObj) throws Exception {
		logger.info("Entering processRemoveOperation");
		if( currentPath != null && currentPath.equals(Constants.MEMBERS) && currentValue == null) {
			logger.debug("Remove all members detected");
			removeGroupObj.setMembers(null);
		} else if(currentPath != null && currentPath.contains(Constants.OPEN_SQ_BRACKET) ) { //checking for format "path": "members[value eq \"{{id4}}\"]"
			logger.debug("Condition [] detected in path");
			int openIndex = currentPath.indexOf(Constants.OPEN_SQ_BRACKET);
			int closeIndex = currentPath.indexOf(Constants.CLOSE_SQ_BRACKET);
			
			//key eq value
			String conditionString = currentPath.substring(openIndex+1, closeIndex);
			logger.debug("conditionString: {}",conditionString);
			
			//only eq operator supported
			String [] splitCondition = conditionString.split(Constants.EQUALS);
			if( splitCondition!=null && splitCondition.length == 2) {
				logger.debug("Expected format for eq operator");
				
				//only value attribute supported
				if( splitCondition[0].equalsIgnoreCase("value") ) {
					//Removing any single and double quotes
					String formattedMember = splitCondition[1].trim().
							replaceAll(Constants.ENCLOSING_DOUBLE_QUOTES, Constants.BLANK_STRING);
					formattedMember = formattedMember.replaceAll(Constants.ENCLOSING_SINGLE_QUOTES,
							Constants.BLANK_STRING);
					
					//checkMemberPresentAndRemove(formattedMember, removeGroupObj.getMembers());
					List<Member> removeMemberList = removeGroupObj.getMembers();
					Member member = new Member();
					member.setValue(formattedMember);
					removeMemberList.add(member);
				}
				
			} else {
				logger.debug("Unexpected format for eq operator. Exiting");
				logger.info("Exiting processRemoveOperation");
				throw new Exception("Unexpected format for equals operator");
			}
		} else if( currentPath != null && currentPath.equals("members") && currentValue != null) { // 
			logger.debug("Found remove operation with members mentioned as a JSON list");
			if( currentValue instanceof ArrayList ) {
				logger.debug("Value is instance of ArrayList");
				ArrayList currentValueList = (ArrayList)currentValue;
				
				if( currentValueList.size() > 0 ) {
					for( int i=0;i<currentValueList.size(); i++ ) {
						Object obj = currentValueList.get(i);
						
						if( obj instanceof Map ) {
							logger.debug("Obj is instance of map");
							Map memberMap = (Map)obj;
							
							if(memberMap.get("value")!=null) {
								String memberName = (String)memberMap.get(Constants.VALUE);
								logger.debug("Member to remove: {}",memberName);
								
								if(memberName!=null && !memberName.equals(Constants.BLANK_STRING)) {
									//checkMemberPresentAndRemove(memberName, removeGroupObj.getMembers());
									List<Member> removeMemberList = removeGroupObj.getMembers();
									Member member = new Member();
									member.setValue(memberName);
									removeMemberList.add(member);
								}
							}																					
						}
					}
				}
			}
		} 
		logger.info("Exiting processRemoveOperation");
	}
	
	private void processAddOperation(String currentPath, Object currentValue, GroupResource addGroupObj) 
			throws Exception {
		logger.info("Entering processAddOperation");		
		//Only adding members supported for group patch add operation
		if( currentPath != null && currentPath.equals(Constants.MEMBERS) && currentValue!=null) {
			if( currentValue instanceof ArrayList ) {
				logger.debug("Value is instance of ArrayList");
				ArrayList currentValueList = (ArrayList)currentValue;
				
				if( currentValueList.size() > 0 ) {
					for( int i=0; i<currentValueList.size(); i++ ) {
						Object obj = currentValueList.get(i);						
						if( obj instanceof Map ) {
							logger.debug("Obj is instance of map");
							Map memberMap = (Map)obj;
							
							if(memberMap.get("value")!=null) {
								String memberName = (String)memberMap.get(Constants.VALUE);
								logger.debug("Member to add: {}",memberName);
								
								if(memberName!=null && !memberName.equals("")) {
									logger.debug("Setting current member in add member list");
									List<Member> memberList = addGroupObj.getMembers();
									
									Member member = new Member();
									member.setValue(memberName);
									member.setDisplay((String)memberMap.get(Constants.DISPLAY_NAME));

									memberList.add(member);
								} else {
									logger.debug("Not able to retrieve valid member details to add");
									throw new Exception("Valid member details not found to add");
								}
							} else {
								logger.debug("Not able to retrieve valid member details to add");
								throw new Exception("Valid member details not found to add");
							}							
						} else {
							logger.debug("Not able to retrieve individual members to add");
							throw new Exception("No valid members found to add");
						}
					}
				} else {
					logger.debug("No valid members found to add");
					throw new Exception("No valid members found to add");
				}
			}								
		} else {
			logger.debug("Unsupported path in add operation: {}",currentPath);
			throw new Exception("Unsupported path in add operation: "+currentPath);
		}				
		logger.info("Exiting processAddOperation");
	}	
}
