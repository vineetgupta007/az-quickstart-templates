package com.kpmg.advcyber.scim.mysql.entity;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name="app_role")
public class Group {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "group_id", nullable=false)	
	private int groupid;
	
	@Column(name = "external_id", nullable=false)
	private String externalId;
	
	@Column(name = "group_name", nullable=false)
	private String groupname;
	
	@Column(name="created", nullable = false, updatable = false)
	@CreationTimestamp
	private Date created;
	
	@Column(name="updated")
	@UpdateTimestamp
	private Date updated;
	
	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getUpdated() {
		return updated;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}
		
	public int getGroupid() {
		return groupid;
	}

	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}

	public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupName) {
		this.groupname = groupName;
	}		

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	@Override
	public String toString() {
		String returnString = "Group{" + "groupname=" + groupname+" groupid="+groupid+" externalid="+externalId;
		returnString+="}";
		return returnString;
	}

	@Override
	public boolean equals( Object b ) {
		if (this == b) return true;
		if (!(b instanceof Group)) return false;
		Group group_b = (Group) b;
		return Objects.equals(getGroupname(), group_b.getGroupname());		
	}
	
	@Override
    public int hashCode() {
        return Objects.hash(getGroupname());
    }
}
