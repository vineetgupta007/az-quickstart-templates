package com.kpmg.advcyber.scim.mysql.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.kpmg.advcyber.scim.core.Repository;
import com.kpmg.advcyber.scim.core.domain.PatchRequest;
import com.kpmg.advcyber.scim.core.domain.SearchParameter;
import com.kpmg.advcyber.scim.core.domain.UserResource;
import com.kpmg.advcyber.scim.core.filter.Filter;
import com.kpmg.advcyber.scim.core.filter.FilterUtil;
import com.kpmg.advcyber.scim.mysql.dao.PatchUserUtils;
import com.kpmg.advcyber.scim.mysql.dao.UserDAO;
import com.kpmg.advcyber.scim.mysql.dao.UserSpecificationBuilder;
import com.kpmg.advcyber.scim.mysql.entity.User;
import com.kpmg.advcyber.scim.mysql.repository.UserRepository;
import com.kpmg.advcyber.scim.mysql.util.Constants;


/**
 * Repository MySQL implementation class that processes incoming requests for 
 * CRUD operations on users.
 * 
 *
 */
public class RepositoryMySQLUserImpl implements Repository<UserResource>{

	Logger logger = LoggerFactory.getLogger(RepositoryMySQLUserImpl.class);

	private ApplicationContext applicationContext;

	@Override
	public Optional get(String id) throws Exception {
		logger.info("Entering get");		
		try {
			//id being integer is specific to this repository implementation
			Integer userId = Integer.valueOf(id);
		} catch ( NumberFormatException ex ) {
			logger.debug("Invalid id not an integer: {}",id);
			throw new Exception("Invalid id not an integer");
		}
		
		UserRepository userRepository = applicationContext.getBean(UserRepository.class);
		Optional<User> dbOptionalUser = userRepository.findById(Integer.valueOf(id));

		if( dbOptionalUser.isPresent() ) {
			logger.debug("Found user: {}",id);
			UserDAO userDAO = applicationContext.getBean(UserDAO.class);
			
			UserResource returnUser = userDAO.transformDBUserToSCIM(dbOptionalUser.get());
			logger.info("Exiting get");
			return Optional.of(returnUser);
		} else {
			logger.debug("User not found: {}",id);
		}

		logger.info("Exiting get");
		return dbOptionalUser;
	}

	@Override
	public List getAll(SearchParameter params) {
		logger.info("Entering getAll");
		logger.debug("Fetching repository bean from application context");
		UserRepository userRepository = applicationContext.getBean(UserRepository.class);
		Specification<User> searchSpec = null;
		if( params.getSearchFilter() != null && !params.getSearchFilter().equals(Constants.BLANK_STRING) ) {
			logger.debug("Search filter detected: {}",params.getSearchFilter());
			
			//TO DO: move this to properties file and do replace by reading values from there
			String searchFilterString = params.getSearchFilter();
			if( searchFilterString.contains(Constants.DISPLAY_NAME) ) {
				searchFilterString = searchFilterString.replaceAll(Constants.DISPLAY_NAME, Constants.NAME);
			}
			
			FilterUtil filterUtil = new FilterUtil();
			Filter searchFilter = filterUtil.buildFilter(searchFilterString);
			
			UserSpecificationBuilder builder = new UserSpecificationBuilder();
			searchSpec = builder.build(searchFilter);
		}
		
		Page<User> userPage = null;
		
		if( searchSpec!=null ) {
			logger.debug("Searching using filter and pagination");
			userPage = userRepository.findAll(searchSpec, getPageableObject(params));
		} else {
			logger.debug("Searching using pagination");
			userPage = userRepository.findAll(getPageableObject(params));
		}
		

		if( userPage != null ) {
			logger.debug("Return page size: {}",userPage.getSize());
						
			List<User> userList = userPage.getContent();
			
			if(userList!=null) {
				UserDAO userDAO = applicationContext.getBean(UserDAO.class);
				logger.info("Exiting getAll");
				return userDAO.transformDBUserListToSCIMList(userList);		
			}
		} else {
			logger.debug("No users retrieved");
		}
		logger.info("Exiting getAll");
		return null;
	}

	@Override
	public UserResource save(UserResource userResource) {
		logger.info("Entering save");
		if( userResource != null ) {
			UserDAO userDAO = applicationContext.getBean(UserDAO.class);
			User user = userDAO.transformSCIMUserToDB(userResource);
			
			UserRepository userRepository = applicationContext.getBean(UserRepository.class);
			User savedUser = userRepository.save(user);
			logger.info("Exiting save");
			return userDAO.transformDBUserToSCIM(savedUser);
		} 

		logger.debug("User not saved!!");
		logger.info("Exiting save");
		return null;
	}

	@Override
	public UserResource update(UserResource user) throws Exception {
		logger.info("Entering update");
		String userId = user.getId();
		try {		
		logger.debug("ID read: {}",userId);		
			//id being integer is specific to this repository implementation
			Integer id = Integer.valueOf(userId);
		} catch ( NumberFormatException ex ) {
			logger.debug("Invalid id not an integer: {}",userId);
			throw new Exception("Invalid id not an integer");
		}
		
		UserDAO userDAO = applicationContext.getBean(UserDAO.class);
		User currentUser = userDAO.transformSCIMUserToDB(user);
		
		UserRepository userRepository = applicationContext.getBean(UserRepository.class);
		User savedUser = userRepository.save(currentUser);

		//Converting user object to scim format
		UserResource returnUser = userDAO.transformDBUserToSCIM(savedUser);		

		logger.info("Exiting update");
		return returnUser;
	}

	@Override
	public void delete(String id) throws Exception {
		logger.info("Entering delete");
		try {
			//id being integer is specific to this repository implementation
			Integer userId = Integer.valueOf(id);
		} catch ( NumberFormatException ex ) {
			logger.debug("Invalid id not an integer: {}",id);
			throw new Exception("Invalid id not an integer");
		}
		
		UserRepository userRepository = applicationContext.getBean(UserRepository.class);
		userRepository.deleteById(Integer.valueOf(id));
		logger.debug("Deleted user: {}",id);
		logger.info("Entering delete");		
	}

	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}
	
	private Pageable  getPageableObject(SearchParameter params) {
		logger.info("Entering getPageableObject");
		int count = params.getCount();
		int startIndex= params.getStartIndex();
		
		//SCIM start index starts with 1. MySQL start index starts with 0. Compensating the difference.
		if( startIndex>0 ) {			
			startIndex-=1;
			logger.debug("Reducing start index by 1: {}",startIndex);
		}
		
		int pageNumber = (int) (startIndex / count) + ( startIndex % count );
		logger.debug("Calculated Page number: {}",pageNumber);
		PageRequest returnRequest = PageRequest.of(pageNumber, count);

		logger.info("Exiting getPageableObject");
		return returnRequest;
	}

	@Override
	public UserResource updatePartial(PatchRequest patchRequest, String userId) throws Exception {
		logger.info("Entering updatePartial");
		try {
			//id being integer is specific to this repository implementation
			Integer id = Integer.valueOf(userId);
		} catch ( NumberFormatException ex ) {
			logger.debug("Invalid id not an integer: {}",userId);
			throw new Exception("Invalid id not an integer");
		}
		
		if( patchRequest!=null && patchRequest.getOperations()!=null && 
				patchRequest.getOperations().size()>0 ) {			
			Optional<UserResource> existingUser = get(userId);
			
			if(existingUser.isPresent()) {
				PatchUserUtils patchUtils = new PatchUserUtils();
				UserResource updatedResource = patchUtils.convertPatchToResource(
						patchRequest, existingUser.get());
				
				UserResource returnResource = update(updatedResource);
				logger.info("Exiting updatePartial");
				return returnResource;				
			}
			
		}
		logger.info("Exiting updatePartial");
		return null;
	}

}
