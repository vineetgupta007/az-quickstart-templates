package com.kpmg.advcyber.scim.mysql.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.kpmg.advcyber.scim.core.domain.GroupResource;
import com.kpmg.advcyber.scim.core.domain.Member;
import com.kpmg.advcyber.scim.core.domain.UserResource;
import com.kpmg.advcyber.scim.mysql.entity.Group;
import com.kpmg.advcyber.scim.mysql.entity.UserGroupMembership;
import com.kpmg.advcyber.scim.mysql.impl.RepositoryMySQLUserImpl;
import com.kpmg.advcyber.scim.mysql.repository.UserGroupMembershipRepository;
import com.kpmg.advcyber.scim.mysql.util.Constants;

/**
 * Class that transforms data from request format to backend repository format and vice versa.
 *
 */
@Component
public class GroupDAO {
	Logger logger = LoggerFactory.getLogger(GroupDAO.class);
	RepositoryMySQLUserImpl userRepo;
	UserGroupMembershipRepository memberRepository;
	
	public GroupDAO(ApplicationContext applicationContext) {
		userRepo = new RepositoryMySQLUserImpl();
		userRepo.setApplicationContext(applicationContext);
		
		memberRepository = applicationContext.getBean(UserGroupMembershipRepository.class);
	}
	
	private String convertDateToString(Date inputDate) {
		logger.info("Entering convertDateToString");
		
		DateFormat df = new SimpleDateFormat(Constants.DATE_PATTERN);
		String dateAsString = df.format(inputDate);
		
		logger.debug("String date format: {}",dateAsString);
		logger.info("Exiting convertDateToString");
		return dateAsString;
	}
	
	public GroupResource transformDBGroupToSCIM(Group group) {
		logger.info("Entering transformDBGroupToSCIM");
		GroupResource returnGroup = new GroupResource();		
		returnGroup.setDisplayName(group.getGroupname());
		returnGroup.setExternalId(group.getExternalId());
		returnGroup.setId(String.valueOf(group.getGroupid()));
		
		if(group.getCreated()!=null && group.getUpdated()!=null) {
			Date createDate = group.getCreated();						
			returnGroup.getMeta().setCreated(convertDateToString(createDate));
			
			Date updateDate = group.getUpdated();						
			returnGroup.getMeta().setLastModified((convertDateToString(updateDate)));
		}
				
		logger.debug("Return group scim object: {}",returnGroup);
		logger.info("Exiting transformDBGroupToSCIM");
		return returnGroup;
	}
	
	public List<UserGroupMembership> transformSCIMMembershiptoDB( GroupResource groupResource ) {
		logger.info("Entering transformSCIMMembershiptoDB");
		List<UserGroupMembership> returnMembershipList = new ArrayList<UserGroupMembership>();
		
		List<Member> memberResourceList = groupResource.getMembers();
		if( memberResourceList!=null && memberResourceList.size()>0 ) {			
			for( int i=0; i<memberResourceList.size(); i++ ) {
				Member currentMemberResource = memberResourceList.get(i);
				try {
					Optional<UserResource> scimUser = userRepo.get(currentMemberResource.getValue());
					
					if( scimUser.isPresent() ) {
						UserGroupMembership userGroupMembership = new UserGroupMembership();
						userGroupMembership.setGroupid(Integer.valueOf(groupResource.getId()));
						logger.debug("Group Name: {}",groupResource.getDisplayName());
						logger.debug("User name: {}",scimUser.get().getUserName());
						logger.debug("Display Name: {}",scimUser.get().getDisplayName());
						userGroupMembership.setUserid(Integer.valueOf(scimUser.get().getId()));
						returnMembershipList.add(userGroupMembership);
					}
				} catch (Exception ex) {
					logger.debug("Skipping user as not found: {}",currentMemberResource.getValue());
					//ex.printStackTrace();
				}
			}			
		}
		logger.info("Exiting transformSCIMMembershiptoDB");
		return returnMembershipList;
	}
	
	public List<Member> transformDBMembershipToSCIM( List<UserGroupMembership> dbMembershipList ) {
		logger.info("Entering transformDBMembershipToSCIM");
		
		if( dbMembershipList!=null && dbMembershipList.size()>0) {
			List<Member> resourceMemberList = new ArrayList<Member>();
			for(UserGroupMembership currentUserMember : dbMembershipList){
				
				if( currentUserMember.getUserid()!=0 ) { //making sure userid is initialized
					Member currentMember = new Member();
					currentMember.setValue(String.valueOf(currentUserMember.getUserid()));
					currentMember.setDisplay(String.valueOf(currentUserMember.getUserid()));
					resourceMemberList.add(currentMember);
				}												
			}
			logger.info("Exiting transformDBMembershipToSCIM");
			return resourceMemberList;
		}
		logger.info("Exiting transformDBMembershipToSCIM");
		return null;
	}
	
	public Group transformSCIMGroupToDB( GroupResource groupResource ) {
		logger.info("Entering transformSCIMGroupToDB");
		Group returnGroup = new Group();		
		returnGroup.setGroupname(groupResource.getDisplayName());
		returnGroup.setExternalId(groupResource.getExternalId());
		
		if( groupResource.getId()!=null && !groupResource.getId().equals("")) {
			returnGroup.setGroupid(Integer.valueOf(groupResource.getId()));
		}
		
		//List<Member> memberResourceList = groupResource.getMembers();				
		logger.debug("Return group object: {}",returnGroup.toString());		
		logger.info("Exiting transformSCIMGroupToDB");
		return returnGroup;
	}
	
	public List<GroupResource> transformDBGroupListToSCIMList( List<Group> groupList ) {
		logger.info("Entering transformDBGroupListToSCIMList");
		List <GroupResource> returnGroupList = new ArrayList<GroupResource>();
		
		for( int i=0; i<groupList.size(); i++ ) {
			GroupResource currentGroup = transformDBGroupToSCIM(groupList.get(i));
			logger.debug("Processing group: {}",currentGroup.getDisplayName());
			List<UserGroupMembership> currentGroupMembership = memberRepository.getMembershipsByGroupId(Integer.valueOf(currentGroup.getId()));
			
			if(currentGroupMembership != null && currentGroupMembership.size()>0) {
				logger.debug("Setting group memberships");
				currentGroup.setMembers(transformDBMembershipToSCIM(currentGroupMembership));
			}
			
			returnGroupList.add(currentGroup);
		}
				
		logger.info("Exiting transformDBGroupListToSCIMList");		
		return returnGroupList;		
	}
	
	
}
