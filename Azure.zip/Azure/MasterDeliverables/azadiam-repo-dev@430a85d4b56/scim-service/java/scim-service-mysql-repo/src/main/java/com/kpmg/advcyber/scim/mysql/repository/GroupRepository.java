package com.kpmg.advcyber.scim.mysql.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.kpmg.advcyber.scim.mysql.entity.Group;

public interface GroupRepository extends PagingAndSortingRepository<Group,Integer>, JpaSpecificationExecutor<Group> {

}
