package com.kpmg.advcyber.scim.mysql.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name="user_group_membership")
@IdClass(UserGroupMembershipId.class)
public class UserGroupMembership {
	@Id
	@Column(name="group_id", nullable=false)
	private int groupid;
	
	@Id
	@Column(name="user_id", nullable=false)
	private int userid;
	
	public UserGroupMembership() {
		
	}
	
	public UserGroupMembership(int userid, int groupid) {
		this.groupid=groupid;
		this.userid=userid;
	}
		
	public int getGroupid() {
		return groupid;
	}

	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String toString() {		
		return "Group ID: "+getGroupid()+" user_id: "+userid;		
	}
}
