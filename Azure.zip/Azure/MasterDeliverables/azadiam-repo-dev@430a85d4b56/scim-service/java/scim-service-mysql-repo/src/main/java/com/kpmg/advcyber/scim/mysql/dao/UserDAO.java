package com.kpmg.advcyber.scim.mysql.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.kpmg.advcyber.scim.core.domain.Address;
import com.kpmg.advcyber.scim.core.domain.Email;
import com.kpmg.advcyber.scim.core.domain.PhoneNumber;
import com.kpmg.advcyber.scim.core.domain.Role;
import com.kpmg.advcyber.scim.core.domain.UserResource;
import com.kpmg.advcyber.scim.mysql.entity.User;
import com.kpmg.advcyber.scim.mysql.util.Constants;

/**
 * Class that transforms data from request format to backend repository format and vice versa.
 *
 */
@Component
public class UserDAO {	
	Logger logger = LoggerFactory.getLogger(UserDAO.class);
		
	public UserDAO() {

	}

	/**
	 * Utility method to transform object that contains user details in scim format to 
	 * POJO that represents backend database
	 * @param userResource
	 * 
	 * @return
	 */
	public User transformSCIMUserToDB( UserResource userResource ) {
		logger.info("Entering transformSCIMUserToDB");
		User returnUser = new User();
		
		if(userResource.getId()!=null ) {
			returnUser.setUserid((Integer.valueOf(userResource.getId())));
		}
		String displayName = userResource.getDisplayName();
		String userName = userResource.getUserName();
		
		List<Email>emailList = userResource.getEmails();
		// Only storing work email
		if( emailList != null ) {
			for( int i=0; i<emailList.size(); i++ ) {
				Email currentEmail = emailList.get(i);
				if( currentEmail != null && currentEmail.getType().equalsIgnoreCase(Constants.WORK) ) {
					returnUser.setEmail(currentEmail.getValue());
					break;
				}
			}					
		}						
				
		returnUser.setName(displayName);
		returnUser.setUsername(userName);
		returnUser.setExternalId(userResource.getExternalId());		
		boolean isActive = userResource.getActive();
		returnUser.setStatus(String.valueOf(isActive));
		returnUser.setTitle(userResource.getTitle());
		
		//process only work address
		if( userResource.getAddresses()!=null && userResource.getAddresses().size()>0 ) {
			logger.debug("found valid addresses");
			List<Address> addressList = userResource.getAddresses();
			
			for( int i=0; i<addressList.size(); i++ ) {
				Address currentAddress = addressList.get(i);				
				if(currentAddress.getType()!=null && currentAddress.getType().equalsIgnoreCase(Constants.WORK)) {
					returnUser.setCity(currentAddress.getLocality());
					returnUser.setCountry(currentAddress.getCountry());
					returnUser.setStateName(currentAddress.getRegion());
					returnUser.setPostalCode(currentAddress.getPostalCode());
				}
			}			
		}
		
		//process only work phone
		if( userResource.getPhoneNumbers()!=null && userResource.getPhoneNumbers().size()>0 ) {
			logger.debug("found valid phone numbers");
			List<PhoneNumber> phoneList = userResource.getPhoneNumbers();
			
			for( int i=0; i<phoneList.size(); i++ ) {
				PhoneNumber currentPhone = phoneList.get(i);				
				if(currentPhone.getType()!=null && currentPhone.getType().equalsIgnoreCase(Constants.WORK)) {
					returnUser.setTelephoneNumber(currentPhone.getValue());					
				}
			}			
		}

		//process only primary role
		if( userResource.getRoles()!=null && userResource.getRoles().size()>0 ) {
			logger.debug("found valid roles");
			List<Role> roleList = userResource.getRoles();

			for( int i=0; i<roleList.size(); i++ ) {
				Role currentRole = roleList.get(i);				
				if(currentRole.getPrimary()!=null && currentRole.getPrimary() == true) {
					logger.debug("Current role detected as primary role: {}",currentRole.getValue());
					returnUser.setRole(currentRole.getValue());					
				}
			}			
		}
		
		//Processing enterprise user extension and custom attributes
		if( userResource.getCustomAttributes()!=null && userResource.getCustomAttributes().size() >0 ) {
			logger.debug("Processing custom atributes");
			for (Map.Entry<String, Object> entry : userResource.getCustomAttributes().entrySet()) {
				logger.debug(" key: "+entry.getKey()+"Value: "+entry.getValue().toString()+" ");
				
				if( entry.getValue() instanceof Map ) {
					logger.debug("Current entry instance of Map");
					if( entry.getKey().equalsIgnoreCase("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User") ) {
						Map enterpriseAttrs = (Map)entry.getValue();
						if( enterpriseAttrs!= null && enterpriseAttrs.get("employeeNumber")!=null ) {
							returnUser.setEmployeeNumber((String)enterpriseAttrs.get("employeeNumber"));
						}
					} else if(entry.getKey().equalsIgnoreCase("urn:ietf:params:scim:schemas:extension:CustomExtensionName:2.0:User")) {
						Map enterpriseAttrs = (Map)entry.getValue();
						if( enterpriseAttrs!= null && enterpriseAttrs.get("department")!=null ) {
							returnUser.setDepartment((String)enterpriseAttrs.get("department"));
						}
						
						if( enterpriseAttrs!= null && enterpriseAttrs.get("office")!=null ) {
							returnUser.setOffice((String)enterpriseAttrs.get("office"));
						}
					}
				}
				
			}
		}

		logger.debug("Return user object: {}",returnUser.toString());
		logger.info("Exiting transformSCIMUserToDB");
		return returnUser;
	}
	private String convertDateToString(Date inputDate) {
		logger.info("Entering convertDateToString");
		DateFormat df = new SimpleDateFormat(Constants.DATE_PATTERN);
		String dateAsString = df.format(inputDate);
		
		logger.debug("String date format: {}",dateAsString);
		logger.info("Exiting convertDateToString");
		return dateAsString;
	}
	
	public UserResource transformDBUserToSCIM (User user) {
		logger.info("Entering transformDBUserToSCIM");
		UserResource returnUser = new UserResource();
		
		if(user.getCreated()!=null && user.getUpdated()!=null) {
			Date createDate = user.getCreated();						
			returnUser.getMeta().setCreated(convertDateToString(createDate));
			
			Date updateDate = user.getUpdated();						
			returnUser.getMeta().setLastModified((convertDateToString(updateDate)));
		}
		
		returnUser.setUserName(user.getUsername());
		returnUser.setExternalId(user.getExternalId());
		String status = user.getStatus();
		
		if( status!=null && !status.equals(Constants.BLANK_STRING) && 
				(status.equalsIgnoreCase(Constants.TRUE) || status.equalsIgnoreCase(Constants.FALSE))) {
			returnUser.setActive(Boolean.valueOf(status));
		}
		
		returnUser.setTitle(user.getTitle());
		
		if(user.getUserid()!=null ) {
			returnUser.setId(String.valueOf(user.getUserid()));
		}
		returnUser.setDisplayName(user.getName());
		
		// Only set email type work
		String emailValue = user.getEmail();
		if(emailValue!=null && !emailValue.equals("")) {
			List<Email>emailList = new ArrayList<Email>();
			Email email = new Email();
			email.setType(Constants.WORK);
			email.setValue(emailValue);		
			emailList.add(email);
			returnUser.setEmails(emailList);
		}
		
		//Process address only if one of the below values is set in DB. Only set address type as work.
		if( (user.getCountry()!=null && !user.getCountry().equals(Constants.BLANK_STRING)) || 
				(user.getStateName()!=null && !user.getStateName().equals(Constants.BLANK_STRING)) ||
				(user.getCity()!=null && !user.getCity().equals(Constants.BLANK_STRING)) ||
				(user.getPostalCode()!=null && !user.getPostalCode().equals(Constants.BLANK_STRING)) 
				) {
			Address address = new Address();
			address.setCountry(user.getCountry());
			address.setPostalCode(user.getPostalCode());
			address.setLocality(user.getCity());
			address.setRegion(user.getStateName());
			address.setType(Constants.WORK);
			List<Address> addressList = new ArrayList<Address>();
			addressList.add(address);
			returnUser.setAddresses(addressList);
		}
		
		//Only set telephone number as work
		if( user.getTelephoneNumber()!=null && !user.getTelephoneNumber().equals(Constants.BLANK_STRING) ) {
			PhoneNumber phone = new PhoneNumber();
			phone.setType(Constants.WORK);
			phone.setValue(user.getTelephoneNumber());
			List<PhoneNumber> phoneList = new ArrayList<PhoneNumber>();
			phoneList.add(phone);
			returnUser.setPhoneNumbers(phoneList);
		}
		
		//Only set primary role
		if( user.getRole()!=null && !user.getRole().equals(Constants.BLANK_STRING) ) {
			Role role = new Role();
			role.setPrimary(true);
			role.setValue(user.getRole());
			List<Role> roleList = new ArrayList<Role>();
			roleList.add(role);
			returnUser.setRoles(roleList);
		}
		
		//Processing Enterprise User attributes
		if( user.getEmployeeNumber()!=null && !user.getEmployeeNumber().equals("") ) {
			Map<String,Object> customAttributesMap = returnUser.getCustomAttributes();
			if( customAttributesMap == null ) {
				customAttributesMap = new HashMap<String,Object>();
			}
			
			HashMap<String,String> enterpriseMap = new HashMap<String,String>();
			enterpriseMap.put("employeeNumber", user.getEmployeeNumber());			
			customAttributesMap.put("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User", enterpriseMap);			
		}
		
		//Processing Custom attributes
		if( user.getOffice()!=null && !user.getOffice().equals("") ) {
			Map<String,Object> customAttributesMap = returnUser.getCustomAttributes();
			if( customAttributesMap == null ) {
				customAttributesMap = new HashMap<String,Object>();
			}
			
			//Instantiate entry for custom attributes if required
			if( customAttributesMap.get("urn:ietf:params:scim:schemas:extension:CustomExtensionName:2.0:User") == null ) {
				HashMap<String,String> customAttrMap = new HashMap<String,String>();
				customAttributesMap.put("urn:ietf:params:scim:schemas:extension:CustomExtensionName:2.0:User", customAttrMap);
			}
			
			HashMap<String,String> customAttrMap = (HashMap<String,String>)customAttributesMap.get("urn:ietf:params:scim:schemas:extension:CustomExtensionName:2.0:User");
			customAttrMap.put("office", user.getOffice());					
		}
		
		//Processing Custom attributes
		if( user.getDepartment()!=null && !user.getDepartment().equals("") ) {
			Map<String,Object> customAttributesMap = returnUser.getCustomAttributes();
			if( customAttributesMap == null ) {
				customAttributesMap = new HashMap<String,Object>();
			}
			
			//Instantiate entry for custom attributes if required
			if( customAttributesMap.get("urn:ietf:params:scim:schemas:extension:CustomExtensionName:2.0:User") == null ) {
				HashMap<String,String> customAttrMap = new HashMap<String,String>();
				customAttributesMap.put("urn:ietf:params:scim:schemas:extension:CustomExtensionName:2.0:User", customAttrMap);
			}
			
			HashMap<String,String> customAttrMap = (HashMap<String,String>)customAttributesMap.get("urn:ietf:params:scim:schemas:extension:CustomExtensionName:2.0:User");
			customAttrMap.put("department", user.getDepartment());					
		}						
		
		logger.debug("User resource: {}",returnUser.toString());
		logger.info("Exiting transformDBUserToSCIM");
		return returnUser;
	}
	
	public List<UserResource> transformDBUserListToSCIMList (List<User> userList) {
		logger.info("Entering transformDBUserListToSCIMList");
		List <UserResource> returnUserList = new ArrayList<UserResource>();
		
		for( int i=0; i<userList.size(); i++ ) {
			UserResource currentUser = transformDBUserToSCIM(userList.get(i));
			returnUserList.add(currentUser);
		}
				
		logger.info("Exiting transformDBUserListToSCIMList");
		return returnUserList;
	}
}
