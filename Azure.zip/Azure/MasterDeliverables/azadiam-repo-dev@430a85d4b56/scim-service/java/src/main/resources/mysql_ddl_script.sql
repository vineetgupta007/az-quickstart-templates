create database IF NOT EXISTS scim_application_db;

use scim_application_db;

CREATE TABLE IF NOT EXISTS `scim_application_db`.user (
user_id int NOT NULL AUTO_INCREMENT,
username VARCHAR(255) NOT NULL,
external_id VARCHAR(255) NOT NULL,
name VARCHAR(255),
email VARCHAR(255),
department VARCHAR(255),
status VARCHAR(255),
title VARCHAR(255),
employee_number VARCHAR(255),
office VARCHAR(255),
city VARCHAR(255),
state_name VARCHAR(255),
postal_code VARCHAR(255),
country VARCHAR(255),
telephone_number VARCHAR(255),
role VARCHAR(255),
created TIMESTAMP,
updated TIMESTAMP,
PRIMARY KEY (user_id)
);

CREATE TABLE IF NOT EXISTS `scim_application_db`.`app_role`(
group_id INT NOT NULL AUTO_INCREMENT,
group_name VARCHAR(255) NOT NULL,
external_id VARCHAR(255) NOT NULL,
created TIMESTAMP,
updated TIMESTAMP,
PRIMARY KEY (group_id)
);

CREATE TABLE IF NOT EXISTS `scim_application_db`.`user_group_membership`(
user_id int NOT NULL,
group_id int NOT NULL,
PRIMARY KEY (user_id, group_id),
FOREIGN KEY (user_id) REFERENCES user(user_id),
FOREIGN KEY (group_id) REFERENCES app_role(group_id)
);
