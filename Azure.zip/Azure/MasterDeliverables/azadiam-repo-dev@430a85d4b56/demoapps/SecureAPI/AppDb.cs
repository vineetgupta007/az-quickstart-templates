﻿using System;
using MySql.Data.MySqlClient;

namespace SecureAPI
{
    public class AppDb
    {
        /// <summary>
        /// 
        /// </summary>
        public MySqlConnection Connection { get; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        public AppDb(string connectionString)
        {
            Connection = new MySqlConnection(connectionString);
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose() => Connection.Dispose();
    }
}
