﻿using Microsoft.AspNetCore.Authorization;

namespace SecureAPI.Services
{
    public class AdminRequirement : IAuthorizationRequirement
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="group"></param>
        public AdminRequirement(string group)
        {
            AllowedGroup = group;
        }

        /// <summary>
        /// 
        /// </summary>
        protected string AllowedGroup { get; set; }
    }

}