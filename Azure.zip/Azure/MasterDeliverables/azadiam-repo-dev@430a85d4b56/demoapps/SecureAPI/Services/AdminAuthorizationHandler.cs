﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SecureAPI.Services
{
    public class AdminAuthorizationHandler : AuthorizationHandler<AdminRequirement>
    {
        /// <summary>
        /// 
        /// </summary>
        IHttpContextAccessor _httpContextAccessor = null;
        public IConfiguration Configuration { get; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <param name="iConfig"></param>
        public AdminAuthorizationHandler(IHttpContextAccessor httpContextAccessor, IConfiguration iConfig)
        {
            _httpContextAccessor = httpContextAccessor;
            Configuration = iConfig;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="requirement"></param>
        /// <returns></returns>
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, AdminRequirement requirement)
        {
            string adminGroup = Configuration.GetValue<string>("Group:AdminAccess");
            HttpContext httpContext = _httpContextAccessor.HttpContext;
            StringValues adminRole = "";

            httpContext.Request.Headers.TryGetValue("meroles", out adminRole);
            if (!String.IsNullOrEmpty(adminRole) && adminRole == "AdminAccessValue")               
                context.Succeed(requirement);

            return Task.FromResult(0);
        }
    }
}

