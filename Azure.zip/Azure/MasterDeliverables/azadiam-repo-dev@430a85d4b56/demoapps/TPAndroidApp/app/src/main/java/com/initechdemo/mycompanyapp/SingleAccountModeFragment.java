package com.initechdemo.mycompanyapp;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import androidx.fragment.app.FragmentTransaction;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.microsoft.identity.client.AuthenticationCallback;
import com.microsoft.identity.client.IAccount;
import com.microsoft.identity.client.IAuthenticationResult;
import com.microsoft.identity.client.IPublicClientApplication;
import com.microsoft.identity.client.ISingleAccountPublicClientApplication;
import com.microsoft.identity.client.PublicClientApplication;
import com.microsoft.identity.client.SilentAuthenticationCallback;
import com.microsoft.identity.client.exception.MsalClientException;
import com.microsoft.identity.client.exception.MsalException;
import com.microsoft.identity.client.exception.MsalServiceException;
import com.microsoft.identity.client.exception.MsalUiRequiredException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
/**
 * Implementation sample for 'Single account' mode.
 * <p>
 * If your app only supports one account being signed-in at a time, this is for you.
 * This requires "account_mode" to be set as "SINGLE" in the configuration file.
 * (Please see res/raw/auth_config_single_account.json for more info).
 * <p>
 * Please note that switching mode (between 'single' and 'multiple' might cause a loss of data.
 */
public class SingleAccountModeFragment extends Fragment {
    private static final String TAG = SingleAccountModeFragment.class.getSimpleName();

    /* UI & Debugging Variables */
    TextView scopeTextView;
    TextView graphResourceTextView;
    TextView currentUserTextView;
    ScrollView medScrollerView;
    TableLayout productTBLView;
    Button createProductView;
    Button deleteProductView;
    TextView WelcomeBanner;
    private ISingleAccountPublicClientApplication mSingleAccountApp;
    private IAccount mAccount;
    private String accessToken=null;
    boolean isLoggedIn = false;
    boolean isRefresh = false;
    String displayNameCurrentView = "";
    ArrayList<Integer> deleteProducts = null;
    JSONObject userProfileGraphResponse;
    /**
     *This method is called to have the fragment instantiate its TPAndroid Porter user interface view
     * @param inflater  object that can be used to inflate any views in the fragment
     * @param container if non-null, this is the parent view that the fragement's UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed from a previous saved state as given here.
     * @return returns a TPortal View
     */
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_single_account_mode, container, false); // using fragment_single_account_mode.xml
        //Initialize default view
        initializeUI(view);
        setHasOptionsMenu(true);
        isLoggedIn=true;
        // Creates a PublicClientApplication object with res/raw/auth_config_single_account.json
        PublicClientApplication.createSingleAccountPublicClientApplication(getContext(),
                R.raw.auth_config_single_account,
                new IPublicClientApplication.ISingleAccountApplicationCreatedListener() {
                    @Override
                    public void onCreated(ISingleAccountPublicClientApplication application) {
                        /**
                         * This test app assumes that the app is only going to support one account.
                         * This requires "account_mode" : "SINGLE" in the config json file.
                         **/
                        mSingleAccountApp = application;
                        loadAccount();
                    }
                    @Override
                    public void onError(MsalException exception) {
                        Log.e(TAG,"MsalException",exception);
                    }
                });

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_main, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_logout:
                /**
                 * Removes the signed-in account and cached tokens from this app (or device, if the device is in shared mode).
                 */
                mSingleAccountApp.signOut(new ISingleAccountPublicClientApplication.SignOutCallback() {
                    @Override
                    public void onSignOut() {
                        mAccount = null;
                        updateUI();
                        showToastOnSignOut();
                    }
                    @Override
                    public void onError(@NonNull MsalException exception) {
                        Log.e(TAG,"MsalException",exception);
                    }
                });
                isLoggedIn=false;
                getActivity().invalidateOptionsMenu();
                return true;

            case R.id.action_myprofile:
                if(userProfileGraphResponse!=null){
                  //  Bundle bundle = new Bundle();
                    try {
                 AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                    View mView = getLayoutInflater().inflate(R.layout.user_profile, null);
                    LinearLayout nameLinearLayout = (LinearLayout) mView.findViewById(R.id.layout_name);
                    LinearLayout userIdLinearLayout = (LinearLayout) mView.findViewById(R.id.layout_username);
                    LinearLayout fNameLinearLayout = (LinearLayout) mView.findViewById(R.id.layout_fname);
                    LinearLayout lNameLinearLayout = (LinearLayout) mView.findViewById(R.id.layout_lname);
                    LinearLayout emailLinearLayout = (LinearLayout) mView.findViewById(R.id.layout_mail);
                    LinearLayout titleLinearLayout = (LinearLayout) mView.findViewById(R.id.layout_jobtitle);
                    LinearLayout offLocLinearLayout = (LinearLayout) mView.findViewById(R.id.layout_offloc);
                    LinearLayout BPNLinearLayout = (LinearLayout) mView.findViewById(R.id.layout_bussphone);
                    LinearLayout CPNLinearLayout = (LinearLayout) mView.findViewById(R.id.layout_cellphone);

                    /* Display Info Variables */
                    TextView displayName = (TextView) mView.findViewById(R.id.display_name);
                    TextView userId = (TextView) mView.findViewById(R.id.user_name);
                    TextView fName = (TextView) mView.findViewById(R.id.fname);
                    TextView lName = (TextView) mView.findViewById(R.id.lname);
                    TextView email = (TextView) mView.findViewById(R.id.mail);
                    TextView title = (TextView) mView.findViewById(R.id.job_title);
                    TextView offLoc = (TextView) mView.findViewById(R.id.office_location);
                    TextView businessPhone = (TextView) mView.findViewById(R.id.business_phone);
                    TextView cellPhone = (TextView) mView.findViewById(R.id.cell_phone);
                    final Button mCloseDialog = (Button) mView.findViewById(R.id.btnCloseAlertDialog);
                    mBuilder.setView(mView);
                    final AlertDialog dialog = mBuilder.create();
                    dialog.show();
                    if(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_DISPNAME)!=null && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_DISPNAME).equalsIgnoreCase("null")) && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_DISPNAME)).isEmpty()){
                        displayName.setText(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_DISPNAME));
                    }
                    if(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_UPN)!=null && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_UPN).equalsIgnoreCase("null")) && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_UPN)).isEmpty()){
                        userId.setText(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_UPN));
                    }
                    if(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_GIVENNAME)!=null && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_GIVENNAME).equalsIgnoreCase("null")) && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_GIVENNAME)).isEmpty()){
                            fName.setText(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_GIVENNAME));
                    }
                    if(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_SURNAME)!=null && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_SURNAME).equalsIgnoreCase("null")) && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_SURNAME)).isEmpty()){
                        lName.setText(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_SURNAME));
                    }
                    if(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_MAIL)!=null && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_MAIL).equalsIgnoreCase("null")) && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_MAIL)).isEmpty()){
                        email.setText(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_MAIL));
                    }
                    if(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_JOBTITLE)!=null && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_JOBTITLE).equalsIgnoreCase("null")) && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_JOBTITLE)).isEmpty()){
                        title.setText(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_JOBTITLE));
                    }
                    if(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_OFFLOC)!=null && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_OFFLOC).equalsIgnoreCase("null")) && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_OFFLOC)).isEmpty()){
                        offLoc.setText(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_OFFLOC));
                    }
                    if(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_BUSINESSPHONE)!=null && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_BUSINESSPHONE).equalsIgnoreCase("null")) && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_BUSINESSPHONE)).isEmpty()){
                        businessPhone.setText(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_BUSINESSPHONE));
                    }
                    if(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_CELLPHONE)!=null && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_CELLPHONE).equalsIgnoreCase("null")) && !(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_CELLPHONE)).isEmpty()){
                        cellPhone.setText(userProfileGraphResponse.getString(TPAndroidConstants.USERPROFILE_CELLPHONE));
                    }
                    mCloseDialog.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View view) {
                            dialog.dismiss();
                        }
                    });
                    } catch (JSONException e) {
                        Log.e(TAG,"JSONException",e);
                    } catch (Exception e){
                        Log.e(TAG,"Exception",e);
                    }
                }
            default:
                return false;
        }
    }

    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        super.onPrepareOptionsMenu(menu);
    }

    /**
     * This method Initialized UI variabls and callbacks
     * @param view requires the view thats in the /layout directory.
     */
    private void initializeUI(@NonNull final View view) {
        Log.i(TAG,"Entering initializeUI");
        try{
            scopeTextView = view.findViewById(R.id.scope);
            graphResourceTextView = view.findViewById(R.id.msgraph_url);
            currentUserTextView = view.findViewById(R.id.current_user);
            WelcomeBanner = view.findViewById(R.id.welcome_banner);
            productTBLView = view.findViewById(R.id.productTBL);
            createProductView = view.findViewById(R.id.btnCreateProduct);
            deleteProductView = view.findViewById(R.id.btnDeleteProducts);
            medScrollerView = view.findViewById(R.id.medScroller);

            final String defaultGraphResourceUrl = MSGraphRequestWrapper.MS_GRAPH_ROOT_ENDPOINT + "v1.0/me";
            graphResourceTextView.setText(defaultGraphResourceUrl);
            createProductView.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view) {
                    AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                    View mView = getLayoutInflater().inflate(R.layout.create_product, null);
                    final EditText mProductName = (EditText) mView.findViewById(R.id.editTextProductName);
                    final EditText mProductPrice = (EditText) mView.findViewById(R.id.editTextProductPrice);
                    Button mCreateProduct = (Button) mView.findViewById(R.id.btnCreateProduct);
                    final Button mCloseDialog = (Button) mView.findViewById(R.id.btnCloseAlertDialog);
                    mBuilder.setView(mView);
                    final AlertDialog dialog = mBuilder.create();
                    dialog.show();

                    mCreateProduct.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View view) {
                            if(!(mProductName.getText().toString().isEmpty()) && !(mProductPrice.getText().toString().isEmpty())){
                                String prdName = mProductName.getText().toString();
                                double prdPrice = Double.valueOf(mProductPrice.getText().toString().replaceAll(",",""));
                                createProduct(prdName,prdPrice);
                                /* Refresh the fragment*/
                                FragmentTransaction fr = getFragmentManager().beginTransaction();
                                Fragment frg = getFragmentManager().findFragmentByTag(TPAndroidConstants.MAIN_FRG_TAG);
                                fr.detach(frg).attach(frg).commit();
                                isRefresh = true;
                                dialog.dismiss();
                            }else{
                                Toast.makeText(getContext(), TPAndroidConstants.PRODUCT_OPS_ERR_MSG, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                    mCloseDialog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialog.dismiss();
                        }
                    });
                }
            });

            deleteProductView.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view) {
                    if(deleteProducts!=null && deleteProducts.size()>0){
                        for(Integer prdId : deleteProducts){
                            deleteProducts(prdId.intValue());
                        }
                    }
                    /* Refresh the fragment*/
                    FragmentTransaction fr = getFragmentManager().beginTransaction();
                    Fragment frg = getFragmentManager().findFragmentByTag(TPAndroidConstants.MAIN_FRG_TAG);
                    fr.detach(frg).attach(frg).commit();
                    isRefresh = true;
                }
            });
            if(isRefresh){
                if (mSingleAccountApp == null) {
                    return ;
                }
                currentUserTextView.setText(TPAndroidConstants.WELCOME_STR + displayNameCurrentView);
                currentUserTextView.setTextColor(Color.BLACK);
                currentUserTextView.setTextSize(TypedValue.COMPLEX_UNIT_PX,getResources().getDimension(R.dimen.font_size_small));
                String[]apiPermission={TPAndroidConstants.SCOPE_USER_IMPERSONATION};
                mSingleAccountApp.acquireTokenSilentAsync(apiPermission,TPAndroidConstants.OAUTH_URL, getAuthSilentCallback());
                isRefresh=false;
            }
        }catch(Exception e){
           Log.e(TAG,"Error in initializeUI",e);
        }
        Log.i(TAG,"Exiting initializeUI");
    }

    @Override
    public void onResume() {
        super.onResume();
        loadAccount();
    }


    /**
     * Extracts a scope array from a text field,
     *   i.e. from "User.Read User.ReadWrite" to ["user.read", "user.readwrite"]
     * @return a list of scopes in an array
     */
    String[] getScopes() {
        return scopeTextView.getText().toString().toLowerCase().split(" ");
    }


    /**
     * When app comes to the foreground, this methhod load existing account to determine if user is signed in.
     */
    private void loadAccount() {
        Log.i(TAG,"Entering loadAccount");
        try{
            if (mSingleAccountApp == null) {
                return;
            }

            mSingleAccountApp.getCurrentAccountAsync(new ISingleAccountPublicClientApplication.CurrentAccountCallback() {
                @Override
                public void onAccountLoaded(@Nullable IAccount activeAccount) {
                    // You can use the account data to update your UI or your app database.
                    mAccount = activeAccount;
                    updateUI();
                }

                @Override
                public void onAccountChanged(@Nullable IAccount priorAccount, @Nullable IAccount currentAccount) {
                    if (currentAccount == null) {
                        // Perform a cleanup task as the signed-in account changed.
                        showToastOnSignOut();
                    }
                }

                @Override
                public void onError(@NonNull MsalException exception) {
                    Log.e(TAG,"MsalException",exception);
                }
            });
        }catch(Exception e){
            Log.e(TAG,"Error in initializeUI",e);
        }
        Log.i(TAG,"Exiting loadAccount");
    }

    /**
     * Callback used for silent acquireToken calls to Graph Api
     * @return returns a token if successful
     */
    private SilentAuthenticationCallback getAuthSilentCallback() {
        return new SilentAuthenticationCallback() {
            @Override
            public void onSuccess(IAuthenticationResult authenticationResult) {
                Log.d(TAG, "Successfully authenticated");
                /* Successfully got a token, use it to call a protected resource - MSGraph */
                /* Set global variable accessToken to use in other functions*/
                accessToken = authenticationResult.getAccessToken();
                /* Calling getProducts TPAPI to display the list of products when user logs in*/
                getProducts();
            }

            @Override
            public void onError(MsalException exception) {
                /* Failed to acquireToken */
                Log.d(TAG, "Authentication failed: " + exception.toString());
                Log.e(TAG,"MsalException",exception);
                if (exception instanceof MsalClientException) {
                    /* Exception inside MSAL, more info inside MsalError.java */
                } else if (exception instanceof MsalServiceException) {
                    /* Exception when communicating with the STS, likely config issue */
                } else if (exception instanceof MsalUiRequiredException) {
                    /* Tokens expired or no session, retry with interactive */
                }
            }
        };
    }

    /**
     * Constructs and calls GET Request for TPAPI webservice call. Populates the UI with product details in tabular format.
     */
    private void getProducts() {
        Log.d(TAG, "Entering getProducts");
        try{
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            JsonArrayRequest objectRequest = new JsonArrayRequest(
                    Request.Method.GET, TPAndroidConstants.WEB_SERVICE_URL, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    populateProductTableHeader();
                    populateProductTableData(response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if(error.networkResponse!=null){
                        WelcomeBanner.setVisibility(View.VISIBLE);
                        WelcomeBanner.setText(TPAndroidConstants.UNAUTH_WEBSERVICE_ACCESS_ERROR);
                    }
                }
            }
            ){
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String,String> headerParams=new HashMap<String,String>();
                    headerParams = setHeaders(accessToken);
                    return headerParams;
                }
            };
            requestQueue.add(objectRequest);
        }catch(Exception e){
            Log.e(TAG, "Error in getProducts",e);
        }
        Log.i(TAG, "Exiting getProducts");
    }

    /**
     * Constructs and calls POST Request for TPAPI webservice call.
     */
    private void createProduct(final String productName, final double productPrice) {
        Log.i(TAG, "Entering createProduct");
        try{
            RequestQueue requestQueue = Volley.newRequestQueue( getContext());
            JsonObjectRequest objectRequest = new JsonObjectRequest(
                    Request.Method.POST, TPAndroidConstants.WEB_SERVICE_URL, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if(error.networkResponse!=null){
                        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                        View mView = getLayoutInflater().inflate(R.layout.error_message, null);
                        final Button mCloseDialog = (Button) mView.findViewById(R.id.btnCloseAlertDialog);
                        mBuilder.setView(mView);
                        final AlertDialog dialog = mBuilder.create();
                        dialog.show();
                        mCloseDialog.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                            }
                        });
                    }
                }
            }
            ){
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String,String> headerParams=new HashMap<String,String>();
                    headerParams = setHeaders(accessToken);
                    return headerParams;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put(TPAndroidConstants.PRODUCT_NAME,productName);
                        jsonObject.put(TPAndroidConstants.PRODUCT_PRICE,productPrice);
                        String body = jsonObject.toString();
                        return body.getBytes("utf-8");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }catch (UnsupportedEncodingException e)
                    {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    return null;
                }
            };
            requestQueue.add(objectRequest);
        }catch(Exception e){
            Log.e(TAG, "Error in createProduct",e);
        }
        Log.i(TAG, "Exiting createProduct");
    }


    /**
     * Constructs and calls PUT Request for TPAPI webservice call.
     */
    private void updateProduct(int productId, final String productName, final double productPrice) {
        Log.i(TAG, "Entering updateProduct");
        try{
            RequestQueue requestQueue = Volley.newRequestQueue( getContext());
            String url = TPAndroidConstants.WEB_SERVICE_URL+"/"+productId;
            JsonObjectRequest objectRequest = new JsonObjectRequest(
                    Request.Method.PUT, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if(error.networkResponse!=null){
                        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                        View mView = getLayoutInflater().inflate(R.layout.error_message, null);
                        final Button mCloseDialog = (Button) mView.findViewById(R.id.btnCloseAlertDialog);
                        mBuilder.setView(mView);
                        final AlertDialog dialog = mBuilder.create();
                        dialog.show();
                        mCloseDialog.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                            }
                        });
                    }
                }
            }
            ){
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String,String> headerParams=new HashMap<String,String>();
                    headerParams = setHeaders(accessToken);
                    return headerParams;
                }
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put(TPAndroidConstants.PRODUCT_NAME,productName);
                        jsonObject.put(TPAndroidConstants.PRODUCT_PRICE,productPrice);
                        String body = jsonObject.toString();
                        return body.getBytes("utf-8");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }catch (UnsupportedEncodingException e)
                    {
                        e.printStackTrace();
                    }
                    return null;
                }
            };
            requestQueue.add(objectRequest);
        }catch(Exception e){
            Log.e(TAG, "Error in updateProduct",e);
        }
        Log.i(TAG, "Exiting updateProduct");
    }

    /**
     * Constructs and calls DELETE Request for TPAPI webservice call.
     */
    private void deleteProducts(int productId) {
        Log.i(TAG, "In deletProducts");
        try{
            RequestQueue requestQueue = Volley.newRequestQueue( getContext());
            String url = TPAndroidConstants.WEB_SERVICE_URL+"/"+productId;
            JsonObjectRequest objectRequest = new JsonObjectRequest(
                    Request.Method.DELETE, url, null, null,new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if(error.networkResponse!=null){
                        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                        View mView = getLayoutInflater().inflate(R.layout.error_message, null);
                        final Button mCloseDialog = (Button) mView.findViewById(R.id.btnCloseAlertDialog);
                        mBuilder.setView(mView);
                        final AlertDialog dialog = mBuilder.create();
                        dialog.show();
                        mCloseDialog.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                dialog.dismiss();
                            }
                        });
                    }
                }
            }
            ){
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String,String> headerParams=new HashMap<String,String>();
                    headerParams = setHeaders(accessToken);
                    return headerParams;
                }
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }
            };
            requestQueue.add(objectRequest);
        }catch(Exception e){
            Log.e(TAG, "Error in deleteProducts",e);
        }
        Log.i(TAG, "Exiting deleteProducts");
    }


    private void populateProductTableHeader(){
        Log.i(TAG, "Entering populateProductTableHeader");
        try{
            TableRow tr_head = new TableRow(getContext());
            tr_head.setBackgroundColor(Color.rgb(0,121,214));
            tr_head.setLayoutParams(new TableLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT));

            TextView label_isSelected = new TextView(getContext());
            tr_head.addView(label_isSelected);// add the column to the table row here

            TextView label_productName = new TextView(getContext());
            label_productName.setText("Product Name");
            label_productName.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                    getResources().getDimension(R.dimen.font_size_medium));
            label_productName.setTextColor(Color.BLACK);
            label_productName.setPadding(5, 5, 5, 5);
            label_productName.setGravity(View.TEXT_ALIGNMENT_CENTER);
            tr_head.addView(label_productName);// add the column to the table row here

            TextView label_productPrice = new TextView(getContext());
            label_productPrice.setText("Product Price");
            label_productPrice.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                    getResources().getDimension(R.dimen.font_size_medium));
            label_productPrice.setTextColor(Color.BLACK);
            label_productPrice.setPadding(5, 5, 5, 5);
            label_productPrice.setGravity(View.TEXT_ALIGNMENT_CENTER);
            tr_head.addView(label_productPrice);// add the column to the table row here

            productTBLView.addView(tr_head, new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.FILL_PARENT,                    //part4
                    TableLayout.LayoutParams.MATCH_PARENT));
        }catch(Exception e){
            Log.e(TAG, "Error in deleteProducts",e);
        }
        Log.i(TAG, "Exiting populateProductTableHeader");
    }


    private void populateProductTableData(JSONArray response) {
        Log.i(TAG, "Entering populateProductTableHeader");
        try{
            if(response!=null){
                deleteProducts = new ArrayList<Integer>();
                for(int i=0;i<response.length();i++){
                    TableRow tr_data = new TableRow(getContext());
                    tr_data.setBackgroundColor(Color.rgb(218,232,252));
                    tr_data.setGravity(View.TEXT_ALIGNMENT_CENTER);
                    tr_data.setLayoutParams(new TableLayout.LayoutParams(
                            RelativeLayout.LayoutParams.MATCH_PARENT,
                            RelativeLayout.LayoutParams.WRAP_CONTENT));

                    JSONObject hsMap = (JSONObject) response.get(i);
                    if(hsMap!=null){
                        final String productId = hsMap.getString(TPAndroidConstants.PRODUCT_ID);
                  //      if(isUserInAdminGrp){
                            final CheckBox checkBox = new CheckBox(getContext());
                            checkBox.setId(Integer.valueOf(productId));
                            checkBox.setOnClickListener(new View.OnClickListener(){

                                @Override
                                public void onClick(View view) {
                                    if(checkBox.isChecked()){
                                        deleteProducts.add(Integer.valueOf(productId));
                                        if(deleteProducts!=null && deleteProducts.size()>0){
                                            deleteProductView.setClickable(true);
                                        }
                                    }else{
                                        deleteProducts.remove(Integer.valueOf(productId));
                                        if(deleteProducts!=null && deleteProducts.isEmpty()){
                                            deleteProductView.setClickable(false);
                                        }
                                    }
                                }
                            });
                            tr_data.addView(checkBox);
                      //  }
                        final String productName = hsMap.getString(TPAndroidConstants.PRODUCT_NAME);
                        double productPrice = hsMap.getDouble(TPAndroidConstants.PRODUCT_PRICE);
                        NumberFormat formatter = new DecimalFormat("#,###");
                        final String formattedNumber = formatter.format(productPrice);
                        final TextView val_productName = new TextView(getContext());

                        SpannableString prdt = new SpannableString(productName);
                        ClickableSpan clickableSpan = new ClickableSpan() {
                            @Override
                            public void onClick(@NonNull View view) {
                                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getContext());
                                View mView = getLayoutInflater().inflate(R.layout.update_product, null);
                                final EditText mProductName = (EditText) mView.findViewById(R.id.editTextProductName);
                                mProductName.setText(productName);
                                final EditText mProductPrice = (EditText) mView.findViewById(R.id.editTextProductPrice);
                                mProductPrice.setText(formattedNumber);
                                Button mUpdateProduct = (Button) mView.findViewById(R.id.btnUpdateProduct);
                                final Button mCloseDialog = (Button) mView.findViewById(R.id.btnCloseAlertDialog);
                                mBuilder.setView(mView);
                                final AlertDialog dialog = mBuilder.create();
                                dialog.show();
                                mUpdateProduct.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        if(!(mProductName.getText().toString().isEmpty() && !(mProductPrice.getText().toString().isEmpty()))){
                                            /* Call UpdateProduct API*/
                                            String prdName = mProductName.getText().toString();
                                            double prdPrice = Double.valueOf(mProductPrice.getText().toString().replaceAll(",",""));
                                            updateProduct(Integer.valueOf(productId),prdName,prdPrice);
                                            isRefresh = true;
                                            /* Refresh the fragment*/
                                            FragmentTransaction fr = getFragmentManager().beginTransaction();
                                            Fragment frg = getFragmentManager().findFragmentByTag(TPAndroidConstants.MAIN_FRG_TAG);
                                            fr.detach(frg).attach(frg).commit();
                                            dialog.dismiss();
                                        }else{
                                            Toast.makeText(getContext(), TPAndroidConstants.PRODUCT_OPS_ERR_MSG, Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                                mCloseDialog.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        dialog.dismiss();
                                    }
                                });
                            }

                            @Override
                            public void updateDrawState(@NonNull TextPaint ds) {
                                super.updateDrawState(ds);
                                ds.setColor(Color.BLACK);
                            }
                        };
                        prdt.setSpan(clickableSpan,0,productName.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        val_productName.setText(prdt);
                        val_productName.setMovementMethod(LinkMovementMethod.getInstance());
                        val_productName.setTextColor(Color.BLACK);
                        val_productName.setPadding(5, 5, 5, 5);
                        val_productName.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                                getResources().getDimension(R.dimen.font_size_medium));
                        tr_data.addView(val_productName);
                        TextView val_productPrice = new TextView(getContext());
                        val_productPrice.setText(formattedNumber);
                        val_productPrice.setTextColor(Color.BLACK);
                        val_productPrice.setPadding(5, 5, 5, 5);
                        val_productPrice.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                                getResources().getDimension(R.dimen.font_size_medium));
                        tr_data.addView(val_productPrice);
                    }
                    productTBLView.addView(tr_data, new TableLayout.LayoutParams(
                            TableLayout.LayoutParams.FILL_PARENT,
                            TableLayout.LayoutParams.MATCH_PARENT));
                }
            }
        }catch(JSONException e){
            Log.e(TAG,"JSONException in populateProductTableData",e);
        }catch(Exception e){
            Log.e(TAG,"Exception in populateProductTableData",e);
        }
        Log.i(TAG,"Exiting populateProductTableData");
    }

    /**
     * Callback used for interactive request.
     * If succeeds we use the access token to call the Microsoft Graph.
     * Does not check cache.
     * @return a token for interactive requests
     */
    AuthenticationCallback getAuthInteractiveCallback() {
        return new AuthenticationCallback() {

            @Override
            public void onSuccess(IAuthenticationResult authenticationResult) {
                /* Successfully got a token, use it to call a protected resource - MSGraph */
                Log.d(TAG, "Successfully authenticated");
                Log.d(TAG, "ID Token: " + authenticationResult.getAccount().getClaims().get("id_token"));
                /* Update account */
                mAccount = authenticationResult.getAccount();
                updateUI();
                /* call graph */
                callGraphAPI(authenticationResult);
            }

            @Override
            public void onError(MsalException exception) {
                /* Failed to acquireToken */
                Log.e(TAG,"MsalException",exception);

                if (exception instanceof MsalClientException) {
                    /* Exception inside MSAL, more info inside MsalError.java */
                } else if (exception instanceof MsalServiceException) {
                    /* Exception when communicating with the STS, likely config issue */
                }
            }

            @Override
            public void onCancel() {
                /* User canceled the authentication */
                Log.d(TAG, "User cancelled login.");
            }
        };
    }

    /**
     * Make an HTTP request to obtain MSGraph data
     * @param authenticationResult result of the authentication for the user
     */
    private void callGraphAPI(final IAuthenticationResult authenticationResult) {
        Log.i(TAG,"Entering callGraphAPI");
        MSGraphRequestWrapper.callGraphAPIUsingVolley(
                getContext(),
                graphResourceTextView.getText().toString(),
                authenticationResult.getAccessToken(),
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        /* Successfully called graph, process data and send to UI */
                        Log.d(TAG, "Response: " + response.toString());
                        try {
                            /* Set Welcome message for the user on UI*/
                            if(response.getString(TPAndroidConstants.RESP_DISPLAY_NAME)!=null){
                                displayNameCurrentView = response.getString(TPAndroidConstants.RESP_DISPLAY_NAME);
                                currentUserTextView.setText("Welcome  " + displayNameCurrentView);
                                currentUserTextView.setTextColor(Color.BLACK);
                                currentUserTextView.setTextSize(TypedValue.COMPLEX_UNIT_PX,getResources().getDimension(R.dimen.font_size_small));
                                userProfileGraphResponse = response;
                            }
                            /* Get auth bearer token for user_impersonation scope to access thw webservice*/
                            String[]apiPermission={TPAndroidConstants.SCOPE_USER_IMPERSONATION};
                           mSingleAccountApp.acquireTokenSilentAsync(apiPermission,TPAndroidConstants.OAUTH_URL, getAuthSilentCallback());
                       } catch (JSONException e) {
                            Log.e(TAG, "JSONException in callGraphAPI",e);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error in callGraphAPI",error);
                    }
                });
        Log.i(TAG,"Exiting callGraphAPI");
    }


    /**
     * Generates headers for webservice call
     */
    /**
     * @param accessToken
     */
    private Map<String,String> setHeaders(String accessToken) {
        Log.i(TAG,"Entering setHeaders");
        Map<String,String> params=new HashMap<String,String>();
        params.put("Content-Type", "application/json");
        params.put("Authorization","Bearer "+accessToken);
        Log.i(TAG,"Exiting setHeaders");
        return params;
    }

    /**
     * Updates on UI based on the current account.
     * if mAccount is null then the user is not logged in
     * if mAccount is not null then user is logged in
     */
    private void updateUI() {
        Log.i(TAG,"Entering updateUI");
        if (mAccount != null) {
            //invisible
            WelcomeBanner.setVisibility(View.INVISIBLE);
            //visible
            createProductView.setVisibility(View.VISIBLE);
            deleteProductView.setVisibility(View.VISIBLE);
            deleteProductView.setClickable(false);
            productTBLView.setVisibility(View.VISIBLE);
            medScrollerView.setVisibility(View.VISIBLE);
            currentUserTextView.setVisibility(View.VISIBLE);
        } else {
            //invisible
            productTBLView.setVisibility(View.INVISIBLE);
            medScrollerView.setVisibility(View.INVISIBLE);
            createProductView.setVisibility(View.INVISIBLE);
            deleteProductView.setVisibility(View.INVISIBLE);
            currentUserTextView.setVisibility(View.INVISIBLE);
            //visible
            WelcomeBanner.setVisibility(View.VISIBLE);
            String welcomeText = TPAndroidConstants.WELCOME_APP_MSG;
            SpannableString welcomeTxt = new SpannableString(welcomeText);
            ClickableSpan clickableSpanWelcome = new ClickableSpan() {
                @Override
                public void onClick(@NonNull View view) {
                    mSingleAccountApp.signIn(getActivity(), null, getScopes(), getAuthInteractiveCallback());
                }

                @Override
                public void updateDrawState(@NonNull TextPaint ds) {
                    super.updateDrawState(ds);
                    ds.setColor(Color.BLACK);
                }
            };

            welcomeTxt.setSpan(clickableSpanWelcome,46,50, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            WelcomeBanner.setText(welcomeTxt);
            WelcomeBanner.setMovementMethod(LinkMovementMethod.getInstance());
        }
        Log.i(TAG,"Exiting updateUI");
    }

    /**
     * This method Updates UI when app sign out succeeds
     */
    private void showToastOnSignOut() {
        Log.i(TAG,"Entering showToastOnSignOut");
        currentUserTextView.setText("");
        Toast.makeText(getContext(), TPAndroidConstants.SIGN_OUT_MSG, Toast.LENGTH_SHORT).show();
        Log.i(TAG,"Exiting showToastOnSignOut");
    }
}
