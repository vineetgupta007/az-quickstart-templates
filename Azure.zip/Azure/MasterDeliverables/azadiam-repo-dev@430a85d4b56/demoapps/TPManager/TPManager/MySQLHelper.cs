﻿
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TPManager
{
    /// <summary>
    /// The main MySQLHelper class
    /// Contains all methods for performing MySQL functions
    /// </summary>
    public class MySQLHelper
    {
        /// <summary>
        /// Gets all the products details from MYSQL and returns the result
        /// </summary>
        /// <param name="constr"></param>
        /// <returns></returns>
        public List<ProductEntity> GetProductList(string constr)
        {
            //Create a list to store the result
            var list = new List<ProductEntity>();
            MySqlConnection myConnection = new MySqlConnection(constr);

            try
            {
                string query = "SELECT * FROM products";
                myConnection.Open();
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, myConnection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();

                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    list.Add(new ProductEntity
                    {
                        product_id = int.Parse(dataReader["product_Id"].ToString()),
                        product_name = dataReader["product_name"].ToString(),

                        product_price = decimal.Parse(dataReader["product_price"].ToString())
                    });
                }
                //close Data Reader
                dataReader.Close();

                //close Connection
                myConnection.Close();

                //return list to be displayed
                return list;
            }
            catch (MySqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (myConnection.State == System.Data.ConnectionState.Open)
                    myConnection.Close();
            }
        }

        /// <summary>
        /// Get the product detail based on the product id and returns the result
        /// </summary>
        /// <param name="constr"></param>
        /// <param name="product_id"></param>
        /// <returns></returns>
        public ProductEntity GetProductByID(string constr, int product_id)
        {
            //Create a list to store the result
            var product = new ProductEntity();

            MySqlConnection myConnection = new MySqlConnection(constr);
            try
            {
                string query = "SELECT * FROM products where product_id = " + product_id;
                myConnection.Open();

                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, myConnection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();

                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    product.product_id = int.Parse(dataReader["product_Id"].ToString());
                    product.product_name = dataReader["product_name"].ToString();

                    product.product_price = decimal.Parse(dataReader["product_price"].ToString());

                }
                //close Data Reader
                dataReader.Close();

                //close Connection
                myConnection.Close();

                //return list to be displayed
                return product;
            }
            catch (MySqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (myConnection.State == System.Data.ConnectionState.Open)
                    myConnection.Close();
            }
        }

        /// <summary>
        /// Insert new product information to MySQL
        /// </summary>
        /// <param name="constr"></param>
        /// <param name="productEntity"></param>
        public void RegisterProduct(string constr, ProductEntity productEntity)
        {
            MySqlConnection myConnection = new MySqlConnection(constr);
            myConnection.Open();
            try
            {
                string sql = "INSERT INTO products (product_id, product_name, product_price) " +
                    "VALUES (" + productEntity.product_id + ",'" + productEntity.product_name + "'," + productEntity.product_price + ")";
                MySqlCommand cmd = new MySqlCommand(sql, myConnection);
                cmd.ExecuteNonQuery();

                //close Connection
                myConnection.Close();
            }
            catch (MySqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (myConnection.State == System.Data.ConnectionState.Open)
                    myConnection.Close();
            }
        }

        /// <summary>
        /// Method to update product details in MySQL
        /// </summary>
        /// <param name="constr"></param>
        /// <param name="productEntity"></param>
        public void UpdateProduct(string constr, ProductEntity productEntity)
        {
            MySqlConnection myConnection = new MySqlConnection(constr);
            try
            {
                myConnection.Open();
                string sql = "UPDATE products " +
                    "SET product_name='" + productEntity.product_name + "', product_price =" + productEntity.product_price + " " +
                    "WHERE product_id =" + Convert.ToInt16(productEntity.product_id);

                MySqlCommand cmd = new MySqlCommand(sql, myConnection);
                cmd.ExecuteNonQuery();

                //close Connection
                myConnection.Close();
            }
            catch (MySqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (myConnection.State == System.Data.ConnectionState.Open)
                    myConnection.Close();
            }
        }

        /// <summary>
        /// Method to delete product from MySQL
        /// </summary>
        /// <param name="constr"></param>
        /// <param name="product_id"></param>
        public void DeleteProduct(string constr, int product_id)
        {
            MySqlConnection myConnection = new MySqlConnection(constr);
            try { 
            myConnection.Open();
            string sql = "DELETE FROM products WHERE product_id = " + product_id;

            MySqlCommand cmd = new MySqlCommand(sql, myConnection);
            cmd.ExecuteNonQuery();

            //close Connection
            myConnection.Close();
            }
            catch (MySqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (myConnection.State == System.Data.ConnectionState.Open)
                    myConnection.Close();
            }
        }
    }
}