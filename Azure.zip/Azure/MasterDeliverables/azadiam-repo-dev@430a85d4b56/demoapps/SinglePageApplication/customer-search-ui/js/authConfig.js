 
// Config object to be passed to Msal on creation.
// For a full list of msal.js configuration parameters, 
// visit https://azuread.github.io/microsoft-authentication-library-for-js/docs/msal/modules/_authenticationparameters_.html
const msalConfig = {
  auth: {   
    clientId: "30176a50-2c51-4048-9853-cfbadc571bfe",
    authority: "https://login.microsoftonline.com/bfda942f-a624-4636-9b1b-c4c13e93dfee",   
	redirectUri: "https://frontlinemsal1-azureadidmdev.msappproxy.net/spa/"
  },
  cache: {
    cacheLocation: "sessionStorage", // This configures where your cache will be stored
    storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
  }
};  
  
// Add here scopes for id token to be used at MS Identity Platform endpoints.
const loginRequest = {
  scopes: ["openid", "profile", "User.Read"]
};

const loginRequestSilent = {
  scopes: ["https://frontlinetest-azureadidmdev.msappproxy.net//user_impersonation"]
};
