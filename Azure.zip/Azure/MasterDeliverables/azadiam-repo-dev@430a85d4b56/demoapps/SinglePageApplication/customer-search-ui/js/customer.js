const apiUrl = "https://frontlinetest-azureadidmdev.msappproxy.net/frontline/";

const searchCustomerUrl = apiUrl + "customer/.search?customerName=";
const authorizeUserUrl = apiUrl + "customer/authorize";

function authorizeUser() {
	$.ajax({
		url: authorizeUserUrl,
        type: 'GET',
		success: function (result) {
                console.log("Authorized user");                
				showSearchBox();
		},
		error: function (xhr, textStatus, error) {
                console.log(xhr.status);
                console.log(textStatus);
                console.log(error);
				showErrorMessage();
            }
	});
}

//Function is called when search button is clicked on page
//Commented out the MSAL library code. Keep in case required in future
function searchCustomer(/*token*/) {

    //const authHeaders = new Headers();
  //  const bearer = `Bearer ${token}`;

    //console.log("Bearer: "+bearer);

   // authHeaders.append("Authorization", bearer);
 //  console.log("token: "+token);
  // console.log("Bearer token header: "+authHeaders);
    // e.preventDefault();
    $("#resultTable").remove();
    $("#commentTable").remove();
    var searchString = $("#searchInputText").val();
    console.log("SearchString: " + searchString);
    if (searchString) {
        $.ajax({
            url: searchCustomerUrl + searchString,
            type: 'GET',
            dataType: 'json',
           /* headers: {
				'Authorization': bearer				
			},*/
            success: function (result) {
                console.log(result);
                console.log("length: " + result.data.length);

                if (result.data.length == 0) {
                    console.log("Search returned 0 results");
                    var trHTML = "<span id='resultTable'><strong>No results found</strong></span>";
                    $("#result").append(trHTML);
                } else {
                    var trHTML = "<table id='resultTable' class='table table-hover'>" +
                        "<tbody>" +
                        "<tr>" +
                        "<td><strong>Name</strong></td>" +
                        "<td><strong>Email</strong></td>" +
                        "<td><strong>Address</strong></td>" +
                        "<td><strong>Tier</strong></td>" +
                        "<td><strong>Comments</strong></td>" +
                        "</tr>";
                    for (var i = 0; i < result.data.length; ++i) {
                        console.log("iterating data: " + i);
                        console.log("First Name: " + result.data[i].firstName);
                        trHTML += '<tr id="' + result.data[i].customerId + '"><td id="fullName">' + result.data[i].firstName + ' ' + result.data[i].lastName
                            + '</td><td id="email">'
                            + result.data[i].email + '</td> <td id="address">'
                            + result.data[i].city + ', <br/>' + result.data[i].stateName + ' - ' +
                            + result.data[i].postalCode + ', <br/>' + result.data[i].country + ' <br/>' +
                            '</td><td id="tier">'
                            + result.data[i].tier + '</td>'
                            + '<td id="comment"><button class="btn btn-secondary" type="button" onClick="searchComments(this)" id="commentsBtn"><i class="fa fa-comments" aria-hidden="true"></i></button></td>'
                            + '</tr>';
                    }

                    trHTML += "</tbody></table>";
                    $("#customer").append(trHTML);
                }
            },
            error: function (xhr, textStatus, error) {
                console.log(xhr.statusText);
                console.log(textStatus);
                console.log(error);
            }
        });
    }
}