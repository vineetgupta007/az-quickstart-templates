const welcomeDiv = document.getElementById("welcomeMessage");
const signInButton = document.getElementById("signIn");
const signOutButton = document.getElementById('signOut');
const searchInput = document.getElementById('searchInput');

function showSearchBox(/*account*/) {
    // Reconfiguring DOM elements    
    signInButton.classList.add('d-none');
    signOutButton.classList.remove('d-none');
    searchInput.classList.remove('d-none');
    welcomeDiv.classList.add('d-none');
}

function showErrorMessage() {
	welcomeDiv.innerHTML = 'Unauthorized User!!'
}