const searchCommentsUrl = apiUrl+"comment/.search?customerId=";

//Function is called when comments button is clicked on page
function searchComments(element) {
    console.log("Comments button clicked!");
    var row = $(element).parent().parent()
    var currentRowId = $(row).attr("id");             
    console.log("Current row id/customer id: " + currentRowId);

    var fullName = $(row).find("#fullName").text();
    console.log("Full Name: " + fullName);

    var trHTML = "<table id='resultTable' class='table table-hover'>" +
        "<tbody>" +
        "<tr>" +
        "<td><strong>Name</strong></td>" +
        "<td><strong>Email</strong></td>" +
        "<td><strong>Address</strong></td>" +
        "<td><strong>Tier</strong></td>" +
        "<td><strong>Comments</strong></td>" +
        "</tr>";

    trHTML += '<tr id="' + $(row).attr("id") + '"><td id="fullName">' + $(row).find("#fullName").text()
        + '</td><td id="email">'
        + $(row).find("#email").text() + '</td> <td id="address">'
        + $(row).find("#address").text() +
        '</td><td id="tier">'
        + $(row).find("#tier").text() + '</td>'
        + '<td id="comment"><button class="btn btn-secondary" type="button" id="commentsBtn"><i class="fa fa-comments" aria-hidden="true"></i></button></td>'
        + '</tr>';

    trHTML += "</tbody></table>";
    //Removing old customer search table        
    $("#resultTable").remove();
    //Remove all previous comments
    $("#commentTable").remove();
    //Adding customer search table with only details of customer whose comments button was clicked
    $("#customer").append(trHTML);

    $.ajax({
        url: searchCommentsUrl + $(row).attr("id"),
        type: 'GET',
        dataType: 'json',
        success: function (result) {
            var commentHTML = "<table id='commentTable' class='table table-hover'>" +
                "<tbody>" +
                "<tr>" +
                "<td><strong>Comment</strong></td>" +
                "<td><strong>Added By</strong></td>" +
                "<td><strong>Date</strong></td>" +
                "</tr>";
            for (var i = 0; i < result.data.length; ++i) {
                commentHTML += '<tr id="' + result.data[i].commentId + '">' +
                    '<td id="comment">' + result.data[i].comment + '</td>' +
                    '<td id="addedBy" >' + result.data[i].workerId + '</td>' +
                    '<td id="addedOn" >' + result.data[i].created + '</td></tr>';
            }
            commentHTML += "</tbody></table>";
            $("#comments").append(commentHTML);
        },
        error: function (xhr, textStatus, error) {
            console.log(xhr.statusText);
            console.log(textStatus);
            console.log(error);
        }
    });

}