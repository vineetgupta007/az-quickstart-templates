package com.kpmg.advcyber.frontline.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.kpmg.advcyber.frontline.entity.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Integer> {
	
	@Query("select cust from Customer cust where UPPER(cust.firstName) LIKE CONCAT('%',UPPER(:name),'%') "
			+ "OR UPPER(cust.lastName) LIKE CONCAT('%',UPPER(:name),'%') ")
	public List<Customer> customfindQuery( @Param("name") String name ); 
}
