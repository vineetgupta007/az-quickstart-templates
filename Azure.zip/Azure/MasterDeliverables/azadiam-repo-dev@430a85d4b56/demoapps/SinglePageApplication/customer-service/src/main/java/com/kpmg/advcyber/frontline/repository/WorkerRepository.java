package com.kpmg.advcyber.frontline.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.kpmg.advcyber.frontline.entity.Worker;

@Repository
public interface WorkerRepository extends CrudRepository<Worker, Integer>{
	

}
