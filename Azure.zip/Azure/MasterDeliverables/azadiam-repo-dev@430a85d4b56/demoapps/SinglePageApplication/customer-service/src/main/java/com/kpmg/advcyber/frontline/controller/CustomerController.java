package com.kpmg.advcyber.frontline.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kpmg.advcyber.frontline.entity.Customer;
import com.kpmg.advcyber.frontline.entity.Data;
import com.kpmg.advcyber.frontline.repository.CustomerRepository;

@RestController
@RequestMapping(value = "/customer")
public class CustomerController {
	Logger logger = LoggerFactory.getLogger(CustomerController.class);

	//private final UserRepository userRepository;
	private final CustomerRepository customerRepository;

	@Autowired
	public CustomerController(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}

	// Dummy method. Spring security will return 403 if unauthorized user.
	@GetMapping("/authorize")
	public ResponseEntity isValidUser() {
		logger.info("Entering isValidUser");

		logger.info("Exiting isValidUser");
		return new ResponseEntity<>("",HttpStatus.OK);

	}

	@GetMapping
	//@CrossOrigin(origins = "https://frontlinemsal1-azureadidmdev.msappproxy.net")
	public ResponseEntity findAllCustomers( ) {
		logger.info("Entering findCustomer");
		try {
			Iterable<Customer> customerIterator = customerRepository.findAll();

			List<Customer> customerList = new ArrayList<Customer>();

			for (Customer currentCustomer : customerIterator) {
				customerList.add(currentCustomer);
			}

			Data data = new Data();        
			data.setData(customerList);

			logger.info("Exiting findCustomer");
			return new ResponseEntity<Data>(data, HttpStatus.OK);
		} catch ( Exception ex ) {
			logger.error("Exception occurred: "+ex.getMessage(),ex);
			return new ResponseEntity(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	@GetMapping(value="/.search",
			produces = { "application/json"})
	// @CrossOrigin(origins = "https://frontlinemsal1-azureadidmdev.msappproxy.net")
	public ResponseEntity findCustomer(@RequestParam(value="customerName") String customerName ) {
		logger.info("Entering findCustomer");    	
		try {
			List<Customer> customerList = customerRepository.customfindQuery(customerName);

			Data data = new Data();        
			data.setData(customerList);

			logger.info("Exiting findCustomer");
			return new ResponseEntity<Data>(data, HttpStatus.OK);
		} catch ( Exception ex ) {
			logger.error("Exception occurred: "+ex.getMessage(),ex);
			return new ResponseEntity(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping
	//  @CrossOrigin(origins = "https://frontlinemsal1-azureadidmdev.msappproxy.net")
	public ResponseEntity createCustomer( @RequestBody Customer customer ) {
		logger.info("Entering createCustomer");
		try {
			Customer createdCustomer = customerRepository.save(customer);

			Data data = new Data();        
			data.setData(createdCustomer);
			logger.debug("Successfully created customer");    	
			logger.info("Exiting findCustomer");
			return new ResponseEntity<Data>(data, HttpStatus.OK);
		} catch ( Exception ex ) {
			logger.error("Exception occurred: "+ex.getMessage(),ex);
			return new ResponseEntity(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
