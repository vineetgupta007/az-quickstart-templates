package com.kpmg.advcyber.frontline.utils;

public class Constants {
	public static final String USERROLE = "userrole";
	public static final String ROLE_PREFIX = "ROLE_";
	
}
