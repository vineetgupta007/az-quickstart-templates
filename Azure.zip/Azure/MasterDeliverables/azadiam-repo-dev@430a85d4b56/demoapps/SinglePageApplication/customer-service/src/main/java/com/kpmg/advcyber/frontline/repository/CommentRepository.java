package com.kpmg.advcyber.frontline.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.kpmg.advcyber.frontline.entity.Comment;

public interface CommentRepository extends CrudRepository<Comment, Integer> {
	
	//@Query("select comment from Comment comment where comment.customerId =: customerId")			
	public List<Comment> findByCustomerId( @Param("customerId") Integer customerId ); 
}
