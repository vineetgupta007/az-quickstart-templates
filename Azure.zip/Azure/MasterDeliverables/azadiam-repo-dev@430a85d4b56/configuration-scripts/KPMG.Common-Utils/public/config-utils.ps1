<#
    .SYNOPSIS
        Loads a JSON property file.
    .DESCRIPTION
        Loads a JSON property file.
    .PARAMETER ConfigFile
        String. Full config file path, including file name.
    .PARAMETER ConfigToLoad
        String. Key for data to be retrieved from JSON. For nested objects, use comma separated string.
    .PARAMETER MergeConfig
        String[]. Keys for data blocks/attributes to be retrieved from JSON. The last part of every key will also be included in the response.
    .OUTPUTS
        PSCustomObject. JSON Object on success. Null on failure.
#>
Function Get-JSONFileData {
    [CmdletBinding()]
    [OutputType([PSCustomObject])] 

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [String]
        $ConfigFile,

        [Parameter(Mandatory = $True, Position = 1)]
        [string] $ConfigToLoad,

        [Parameter(Mandatory = $False, Position = 2)]
        [string[]] $MergeConfig
    )

    Process {

        Write-LogInfo "Inside function Get-JSONFileData."
        Write-LogDebug "Input ConfigFile :: $ConfigFile"
        Write-LogDebug "Input ConfigToLoad :: $ConfigToLoad"
        Write-LogDebug "Input MergeConfig :: $MergeConfig"

        Try {

            If (StringNullOrEmpty $ConfigFile) {
                Throw "File path is null/empty."
            }

            $fileExists = [System.IO.File]::Exists($ConfigFile)
            Write-LogDebug "File exists :: $fileExists"
            If (!($fileExists)) {
                Throw "No file doesn't exist at: $ConfigFile"
            }
            
            #declare ConfigData object
            $ConfigData = New-Object -TypeName PSCustomObject

            #Load config file
            $ConfigFileData = New-Object -TypeName PSCustomObject -argumentlist (Get-Content -Raw -Path $ConfigFile | ConvertFrom-Json)
            If ($null -eq $ConfigFileData) {
                Throw "No configuration data found in config file: $ConfigFile"
            }
            
            #Handle ConfigToLoad key
            $ConfigToLoadProps = $ConfigFileData
            $splitAttr = ($ConfigToLoad -split ',')
            if (!($null -eq $splitAttr)) {
                foreach ($row in $splitAttr) {
                    $ConfigToLoadProps = $ConfigToLoadProps.$row
                }
            }

            #Add ConfigToLoadProps object to return variable. Using reassignment as we don't need Key for ConfigToLoad data
            $ConfigData = $ConfigToLoadProps

            #Handle MergeConfig Keys
            If (($null -ne $MergeConfig) -and ($MergeConfig.Count -gt 0)) {
                foreach ($ConfigKey in $MergeConfig) {
                    $MergeConfigProps = $ConfigFileData
                    $splitAttr = ($ConfigKey -split ',')
                    if (!($null -eq $splitAttr)) {
                        foreach ($row in $splitAttr) {
                            $MergeConfigProps = $MergeConfigProps.$row
                        }
                    }
                    #Add MergeConfigProps object in return variable. Using Add-Member as we need Key for MergeConfig related data
                    $ConfigData | Add-Member NoteProperty -Name (($ConfigKey -split ',')[-1]) -Value $MergeConfigProps
                }
            }

        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            $ConfigData = $null
        }
        Write-LogInfo "Exiting function Get-JSONFileData."
        return $ConfigData
    }
}


<#
    .SYNOPSIS
        Loads JSON and reads the json file for specific configuration passed.
    .DESCRIPTION
        Loads JSON and reads the json file for specific configuration passed. This function will return a PSCustomObject with the attributes from the selected configuration.
    .PARAMETER ConfigFile
        Full file name, including path, of the configuration to be read
    .PARAMETER ConfigToLoad
        Attribute to be retrieved from JSON. This parameter can be a comma seperated string.
    .OUTPUTS
        PSCustomObject json. Null on failure.
#>
Function Get-ConfigfromJSON {
    [CmdletBinding()]
    [OutputType([PSCustomObject])] 
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string] $ConfigFile,
        [Parameter(Mandatory = $True, Position = 1)]
        [string] $ConfigToLoad
    )
    process {
        try {
            Write-LogInfo "Inside function Get-ConfigfromJSON :: $ConfigToLoad"
            $ConfigProps = $null
            If (StringNullOrEmpty $ConfigFile) {
                Write-LogError "File path is null/empty."
                Write-LogInfo "Exiting Function Get-JSONFileData."
                return $FileAsJson 
            }
            $fileExists = [System.IO.File]::Exists($ConfigFile)
            Write-LogDebug "File exists :: $fileExists"
            $splitAttr = ($ConfigToLoad -split ',')
            if (!($null -eq $splitAttr)) {
                foreach ($row in $splitAttr) {
                    if (!($null -eq $ConfigProps)) {
                        $ConfigProps = $ConfigProps.$row
                    }
                    else {
                        $ConfigProps = New-Object -TypeName PSCustomObject -argumentlist (Get-Content -Raw -Path $ConfigFile | ConvertFrom-Json).$row
                    }
                }
            }
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            $ConfigProps = $null
        }
        Write-LogInfo "Exiting function Get-ConfigfromJSON."
        return $ConfigProps
    }
}

<#
    .SYNOPSIS
        This function validates row in CSV file
    .DESCRIPTION
        This function validates row in CSV file. It will take the csv row, headers in the csv and mandatory attributes for the operation as input. The function then iterates over the headers in the csv and checks if the header is a mandatory attribute for the operation. If the header is a mandatory attibute, the function will check whether the value in the row for the header is null or empty. If not, isValidRecord is set to true or else it is set to false the function exits from the loop.
    .PARAMETER Row
        CSV Row
    .PARAMETER Headers
        Headers in the CSV. This is an array
    .PARAMETER Mandatoryattr
        Mandatory attributes for the operation to be performed
    .OUTPUTS
        bool isValidRow
#>
Function validateDataInCSV{
    [CmdletBinding()]
    [OutputType([bool])] 
    Param(
    [Parameter(Mandatory=$True,Position=0)]
    [PSCustomObject] $Row,
    [Parameter(Mandatory=$True,Position=1)]
    [array] $Headers,
    [Parameter(Mandatory=$True,Position=2)]
    [array] $Mandatoryattr
    )
    process{
        try{
            Write-LogInfo "Inside function validateDataInCSVRow, row is >$Row<, header is >$Headers<, mandatory attributes >$Mandatoryattr<"
            $isValidRow=$false
            foreach ($header in $Headers) {
                if($mandatoryattr.Contains($header)){
                    #check for null or empty, if null or empty, skip the value
                    $rowVal = $Row | Select-Object -ExpandProperty $header
                    Write-LogInfo "Value for >$header< in row is >$rowVal<"
                    If(!(StringNullOrEmpty $rowVal)){
                        $isValidRow=$true
                    }else{
                        Write-LogInfo "Breaking Loop"
                        $isValidRow=$false
                        break
                    }
                }else{
                    $isValidRow=$true
                    Write-LogInfo ">$header< is not in mandatory attributes list"
                }
            } 
            return $isValidRow
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
    }
}

<#
.SYNOPSIS
    This function counts the number of headers in CSV
.DESCRIPTION
    This function counts the number of headers in CSV
.PARAMETER Row
    CSV Row
.PARAMETER Headers
    Headers in the CSV. This is an array
.PARAMETER Mandatoryattr
    Mandatory attributes for the operation to be performed
.OUTPUTS
    String count
#>
Function Get-HeaderColumnCount{
[CmdletBinding()]
[OutputType([string])] 
Param(
[Parameter(Mandatory=$True,Position=0)]
[string] $CSVFILEPATH
)
process{
    try{
        Write-LogInfo "Inside function Get-HeaderColumnCount"
        $headerCol=(Get-Content $CSVFILEPATH | Select-Object  -First 1).Split(",")
        $headerColumnCount=$headerCol.count
        Write-LogInfo "Exiting function Get-HeaderColumnCount"
        return $headerColumnCount
    }catch{
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
        Write-LogError $ErrorMessage
        Write-LogError $FailedItem
        break
    }
}
}
<#
    .SYNOPSIS
        Loads specific configuration from JSON.
    .DESCRIPTION
        Loads specific configuration from JSON.    
    .PARAMETER ConfigDataJSON
        PSCustomObject
    .PARAMETER KeyName
        Parent Attribute to be retrieved from JSON.
     .PARAMETER ChildKeyName
        Child Attribute to be retrieved from JSON. This parameter can be a comma seperated string. This is an optional attribute
    .OUTPUTS
        PSCustomObject json. Null on failure.
#>
Function Get-ConfigfromKey {
    [CmdletBinding()]
    [OutputType([PSCustomObject])] 
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [PSCustomObject] $ConfigDataJSON,
        [Parameter(Mandatory = $True, Position = 1)]
        [string] $KeyName,
        [Parameter(Mandatory = $False, Position = 2)]
        [string] $ChildKeyName
    )
    process {
        Write-LogInfo "Inside function Get-ConfigfromKey"
        $KeyConfig=$null
        try {
            $KeyNames = $ConfigDataJSON | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
            if($null -ne $KeyNames){
                if($KeyNames -contains $KeyName){
                    if(!(StringNullOrEmpty $ChildKeyName )){
                        $splitAttr = ($ChildKeyName -split ',')
                        if (!($null -eq $splitAttr)) {
                            foreach ($row in $splitAttr) {
                                if (!($null -eq $KeyConfig)) {
                                    $KeyConfig = $KeyConfig.$row
                                }else{
                                    $KeyConfig=$ConfigDataJSON.$KeyName.$row
                                }
                            }
                        }
                     }else{
                        $KeyConfig=$ConfigDataJSON.$KeyName
                    }
                }
            }else{
                Write-LogInfo "Problems occured while getting KeyNames from JSON"
            }
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
        }
        Write-LogInfo "Exiting function Get-ConfigfromKey"
        return $KeyConfig
    }
}

