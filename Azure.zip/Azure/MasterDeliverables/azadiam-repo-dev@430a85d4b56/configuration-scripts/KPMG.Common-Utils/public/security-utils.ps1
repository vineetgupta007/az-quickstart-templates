<#
    .SYNOPSIS
        Converts the password to a SecureString.
    .DESCRIPTION
        Converts the password to a SecureString.
    .PARAMETER Password
        Clear text password string. Allows empty string.
    .OUTPUTS
        SecureString SecurePassword
#>
Function Convert-PasswordToSecureString {
    [CmdletBinding()]
    [OutputType([SecureString])] 

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [AllowEmptyString()]
        [string]
        $Password
    )

    process {

        $SecurePassword = new-object System.Security.SecureString

        Write-LogInfo "Inside Function Convert-PasswordToSecureString."
        
        If ((StringNullOrEmpty $Password)) {
            Write-LogWarning "Password value is null/empty."
        } 
        Else {
            $SecurePassword = ConvertTo-SecureString -String (Convert-Password $Password) -AsPlainText -Force
            Write-LogInfo "Returning secure password." 
        }  
        Write-LogInfo "Exiting Function Convert-PasswordToSecureString." 
        return $SecurePassword    
    }
}

<#
    .SYNOPSIS
        Return password in <placeholder> format. WIP.
    .DESCRIPTION
        Return password in <placeholder> format. WIP.
    .PARAMETER Password
        Clear text password string. Allows empty string.
    .OUTPUTS
        String password in cleartext string. WIP.
#>
Function Convert-Password {
    [CmdletBinding()]
    [OutputType([String])] 

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [AllowEmptyString()]
        [string]
        $Password
    )

    process {

        Write-LogInfo "Inside Function Convert-Password."
        
        If ((StringNullOrEmpty $Password)) {
            Write-LogWarning "Password value is null/empty."
        }  
        Write-LogInfo "Exiting Function Convert-Password." 
        return $Password    
    }

}

<#
    .SYNOPSIS
        Creates a PSCredential object.
    .DESCRIPTION
        Get-PSCredentials function creates a PSCredential object with supplied username and password.
    .PARAMETER Username
        Username of the user 
    .PARAMETER Password
        SecureString password of the user
    .OUTPUTS
        PSCredential. Credential object with Username and SecurePassword
#>
Function Get-PSCredentials {
    [CmdletBinding()]
    [OutputType([PSCredential])]
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $Username,

        [Parameter(Mandatory = $True, Position = 1)]
        [SecureString]
        $Password
    )

    Process {

        $CredentialObj = $null

        Write-LogInfo "Inside Function Get-PSCredentials."

        Write-LogDebug "Input username is:: $Username"
        Write-LogDebug "Input password is:: $Password"
    
        If ((!(StringNullOrEmpty $Username)) -and ($Password -ne $null)) {
            $CredentialObj = new-object -typename System.Management.Automation.PSCredential -argumentlist $Username, $Password;
            Write-LogDebug "Returning PSCredential object." 
        }
        Else {
            Write-LogWarning "Input username or/and password is null/empty." 
        }
        Write-LogInfo "Exiting Function Get-PSCredentials."
        return $CredentialObj
    }
}