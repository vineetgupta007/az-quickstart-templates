<#
    .SYNOPSIS
        Adds windows features for Domain Controller setup.
    .DESCRIPTION
        Function Add-ADDCFeatures installs DNS,AD DS, and GPMC windows features
    .PARAMETER ComputerName
        Computer name or ip if running remotely.
    .PARAMETER LAdminCredentials
        Admin credential object.
    .OUTPUTS
        int 
            0 - successfully completed
            1 - when credentials are NULL
            2 - when features are not installed
            3 - when partially installed
            4 - when unknown error
#>
Function Add-ADDCFeatures {
    [CmdletBinding()]
    [OutputType([int])]
    Param(
   
        [Parameter(Mandatory = $False, Position = 0)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $False, Position = 1)]
        [pscredential]
        $LAdminCredentials
    )

    Process {

        $respCode = 5

        Write-LogInfo "Inside Function Add-ADDCFeatures."
        Write-LogDebug "Input ComputerName :: $ComputerName"       

        try {
            
            If ($ComputerName) {
                If ($LAdminCredentials -eq $null) {
                    $respCode = 1
                    Throw "Input credentials are NULL."
                }
                Write-LogDebug "Starting addFeatures job to install DNS, AD DS, GPMC"
                
                Invoke-Command -ComputerName $ComputerName -ScriptBlock { start-job -Name addFeatures -ScriptBlock { 
                        Add-WindowsFeature -Name "dns" -IncludeAllSubFeature -IncludeManagementTools
                        Add-WindowsFeature -Name "ad-domain-services" -IncludeAllSubFeature -IncludeManagementTools
                        Add-WindowsFeature -Name "gpmc" -IncludeAllSubFeature -IncludeManagementTools
                    } 
                    Wait-Job -Name addFeatures } -credential $LAdminCredentials | Out-Null
                Write-LogDebug "addFeatures job completed. Checking output."
                $WinFet = Invoke-Command -ComputerName $ComputerName -ScriptBlock { Get-WindowsFeature -Name DNS, GPMC, AD-Domain-Services } -Credential $LAdminCredentials                         
            }
            Else {
                start-job -Name addFeatures -ScriptBlock { 
                    Add-WindowsFeature -Name "dns" -IncludeAllSubFeature -IncludeManagementTools
                    Add-WindowsFeature -Name "ad-domain-services" -IncludeAllSubFeature -IncludeManagementTools
                    Add-WindowsFeature -Name "gpmc" -IncludeAllSubFeature -IncludeManagementTools
                } 
                Wait-Job -Name addFeatures | Out-Null
                Write-LogDebug "addFeatures job completed. Checking output."

                $WinFet = Get-WindowsFeature -Name DNS, GPMC, AD-Domain-Services
            }
            Write-LogDebug "Searched for installed features."
            If ($null -eq $WinFet) {
                $respCode = 2  
                Throw "Required features didn't install successfully."
            }
            ElseIf ((!($null -eq $WinFet)) -and (!($WinFet.Count -eq 3))) {
                $respCode = 3
                Throw "All required features didn't install successfully. Expected features 3. But Installed features :: $WinFet.Name"
            }
            ElseIf ((!($null -eq $WinFet)) -and ($WinFet.Count -eq 3)) {
                Write-LogDebug "All required features installed successfully." 
                Write-LogDebug "Expected features 3. Installed features :: $WinFet.Name"
                $respCode = 0
            }
                    
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage" 
            If (($null -eq $respCode) -or ($respCode = 0)) {
                $respCode = 4
            }
        }
        Write-LogInfo "Exiting Function Add-ADDCFeatures with response :: $respCode"
        return $respCode
    }
}

<#
    .SYNOPSIS
        Gets users from AD.
    .DESCRIPTION
        Gets users from AD based on AD Filter OR Group Membership OR All.
    .PARAMETER DAdminCreds
        Domain admin credentials.
    .PARAMETER GroupName
        Specifies group name to get members data.
    .PARAMETER Attributes
        Specifies AD attributes array. i.e. "sn","st","samaccountname"
    .PARAMETER Filter
        Specifies valid AD filter.
    .OUTPUTS
        System.Array | AD users object[] 
#>
Function Get-UsersFromAD {
    [CmdletBinding()]
    [OutputType([System.Array])]
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [pscredential]$DAdminCreds,

        [Parameter(Mandatory = $False, Position = 1)]
        [string]$GroupName,

        [Parameter(Mandatory = $False, Position = 2)]
        [string[]]$Attributes = "sn",

        [Parameter(Mandatory = $False, Position = 3)]
        [string]$Filter
    )

    Process {
        Write-LogInfo "Inside Function Get-UsersFromAD."
        $ADUsersData = $null

        Write-LogDebug "Input group name :: $GroupName"
        Write-LogDebug "Input attributes :: $Attributes"
        Write-LogDebug "Input AD filter :: $Filter"
        
     
        Try {
            
            If (!(StringNullOrEmpty $GroupName)) {
                $ADUsersData = Get-ADGroupMember -Identity $GroupName -Credential $DAdminCreds | Foreach-Object ( { Get-ADUser -Filter { (samaccountname -eq $_.SamAccountName) -and (objectclass -eq "user") } -Properties $Attributes -Credential $DAdminCreds }) 
            }
            ElseIf (!(StringNullOrEmpty $Filter)) {
                $ADUsersData = Get-ADUser -Filter $Filter -Properties $Attributes -Credential $DAdminCreds
            }
            Else {
                $ADUsersData = Get-ADUser -Filter { objectclass -eq "user" } -Properties $Attributes -Credential $DAdminCreds
            }
        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            $ADUsersData = $null
        } 
        Write-LogInfo "Exiting Function Get-UsersFromAD."  
        return $ADUsersData
    }

}

<#
    .SYNOPSIS
        This function creates OU in Active Directory 
    .DESCRIPTION
        This function creates OU in Active Directory. This function takes CSV input. The template of CSV should be OrgUnit,OUPath
    .PARAMETER csvFile
        CSV File Path.       
    .PARAMETER SessionObj
        Session Object   
    .PARAMETER MandatoryAttr
        Mandatory attributes for the script  
#>
function AD_CreateOU {
    [CmdletBinding()]
    [OutputType([int])] 
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [string] $CSVFilePath,
        [Parameter(Mandatory=$True,Position=1)]
        [System.Management.Automation.Runspaces.PSSession] $SessionObj,
        [Parameter(Mandatory=$True,Position=2)]
        [array] $MandatoryAttr
    )
    Process{
         try{
            $respCode=1
            Write-LogInfo "Inside Function AD_CreateOU"
            #Test if CSV file is present
            if ((Test-path ($CSVFILEPATH)) -eq $false){
                throw "CSV FILE $CSVFILEPATH not found!"
            }

            #Get number of columns in the header
            $headerColumnCount=Get-HeaderColumnCount -CSVFILEPATH $CSVFilePath
            Write-LogInfo "Number of header columns is >$headerColumnCount<"

            #Import CSV
            $csvdata = Import-Csv -Path $CSVFILEPATH
            if(!($null -eq $csvdata)){
                #Get all headers
                $headers = ($csvdata | Get-Member -MemberType NoteProperty).Name 
                foreach ($row in $csvdata) {
                    #Check for number of columns in the row
                    $noOfColumnsinRow = ($row -split ';').count
                    Write-LogInfo "Number of columns in the row is >$noOfColumnsinRow<"
                    if($headerColumnCount -eq $noOfColumnsinRow){
                        #Checking whether header is in mandatorylist
                        $isValidRow=validateDataInCSV -Row $row -Headers $headers -Mandatoryattr $mandatoryattr
                        #If validation of the data in the row is successful, process the record
                        Write-LogInfo "IsValidRow is set to >$isValidRow<"
                        if($isValidRow){
                            $orgName=$row.OrgUnit    
                            Write-LogInfo "orgName:>$orgName<"
                            $orgPath=$row.OUPath 
                            Write-LogInfo "orgPath:$orgPath"
                            #Execute command to create OU
                            $ScriptBlock="New-ADOrganizationalUnit -Name '$orgName' -Path '$orgPath'"
                            $respCode=Submit-WinCommand -ScriptBlock $ScriptBlock -Session $SessionObj
                            if($respCode -eq 0){
                                Write-LogInfo "OU created successfully:$orgName"   
                            }else{
                                Write-LogInfo "Error occured while creating OU"
                             }
                        }else{
                            Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                        }
                    }else{
                        Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                    }
                }
            }
            Write-LogInfo "Exiting Function AD_CreateOU, with return code::$respCode"
            return $respCode
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
        }
    }
}

<#
    .SYNOPSIS
        This function creates group in Active Directory 
    .DESCRIPTION
        This function creates group in Active Directory. This function takes CSV input. The template of CSV should be GroupName,GroupPath,GroupCategory,GroupScope
    .PARAMETER CSVFilePath
        CSV File Path.       
    .PARAMETER SessionObj
        PSSession Object    
    .PARAMETER MandatoryAttr
        List of mandatory attributes for execution of the command    
#>
function AD_CreateGroup {
    [CmdletBinding()]
    [OutputType([int])] 
    Param(
        [Parameter(Mandatory=$True,Position=1)]
        [string] $CSVFilePath,
        [Parameter(Mandatory=$True,Position=1)]
        [System.Management.Automation.Runspaces.PSSession] $SessionObj,
        [Parameter(Mandatory=$True,Position=2)]
        [array] $MandatoryAttr
    )
    Process{
        try{
            Write-LogInfo "Inside Function AD_CreateGroup"
            $respCode=1
            #Test if CSV file is present
            if ((Test-path ($CSVFILEPATH)) -eq $false){
                throw "CSV FILE $CSVFILEPATH not found!"
            }

            #Get number of columns in the header
            $headerColumnCount=Get-HeaderColumnCount -CSVFILEPATH $CSVFilePath
            Write-LogInfo "Number of header columns is >$headerColumnCount<"

            #Import CSV
            $csvdata = Import-Csv -Path $CSVFILEPATH
            if(!($null -eq $csvdata)){
                #Get all headers
                $headers = ($csvdata | Get-Member -MemberType NoteProperty).Name 
                foreach ($row in $csvdata) {
                    #Check for number of columns in the row
                    $noOfColumnsinRow = ($row -split ';').count
                    Write-LogInfo "Number of columns in the row is >$noOfColumnsinRow<"
                    if($headerColumnCount -eq $noOfColumnsinRow){
                        #Checking whether header is in mandatorylist
                        $isValidRow=validateDataInCSV -Row $row -Headers $headers -Mandatoryattr $Mandatoryattr
                        #If validation of the data in the row is successful, process the record
                        Write-LogInfo "IsValidRow is set to >$isValidRow<"
                        if($isValidRow){
                            $GroupName=$row.GroupName
                            $GroupPath=$row.GroupPath
                            $GroupCategory=$row.GroupCategory
                            $GroupScope=$row.GroupScope
                            Write-LogInfo "GroupName is>$GroupName< , GroupPath is >$GroupPath< , GroupCategory is >$GroupCategory< , GroupScope is >$GroupScope<" 
                            #Execute command to create group
                            $ScriptBlock="New-ADGroup -Name '$GroupName' -Path '$GroupPath' -GroupCategory '$GroupCategory' -GroupScope '$GroupScope'"
                            $respCode=Submit-WinCommand -ScriptBlock $ScriptBlock -Session $SessionObj
                            if($respCode -eq 0){
                                Write-LogInfo "Group created successfully >$GroupName<"   
                            }else{
                                Write-LogInfo "Error occured while creating group"
                             }
                         }else{
                            Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                        }
                    }else{
                        Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                    }
                }
            }
            Write-LogInfo "Exiting Function AD_CreateGroup, with return code::$respCode"
            return $respCode
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
        }
     }
}

<#
    .SYNOPSIS
        This function add users to group in Active Directory 
    .DESCRIPTION
        This function add users to group in Active Directory. This function takes CSV input. The template of CSV should be GroupName,UserSAMAccountName. UserSAMAccountName can be a comma seperated list of users to be added to group
    .PARAMETER CSVFilePath
        CSV File Path.       
    .PARAMETER SessionObj
        PSSession Object    
    .PARAMETER MandatoryAttr
        List of mandatory attributes for execution of the command    
#>
function AD_AddUsertoGroup {
    [CmdletBinding()]
    [OutputType([int])] 
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [string] $CSVFilePath,
        [Parameter(Mandatory=$True,Position=1)]
        [System.Management.Automation.Runspaces.PSSession] $SessionObj,
        [Parameter(Mandatory=$True,Position=2)]
        [PSCredential] $CredentialObj,
        [Parameter(Mandatory=$True,Position=4)]
        [array] $MandatoryAttr
    )
    Process{
        try{
            Write-LogInfo "Inside Function AD_AddUsertoGroup"
            $respCode=1

            #Test if CSV file is present
            if ((Test-path ($CSVFILEPATH)) -eq $false){
                throw "CSV FILE $CSVFILEPATH not found!"
            }

            #Get number of columns in the header
            $headerColumnCount=Get-HeaderColumnCount -CSVFILEPATH $CSVFilePath
            Write-LogInfo "Number of header columns is >$headerColumnCount<"

            #Import CSV
            $csvdata = Import-Csv -Path $CSVFILEPATH
            if(!($null -eq $csvdata)){
                #Get all headers
                $headers = ($csvdata | Get-Member -MemberType NoteProperty).Name 
                foreach ($row in $csvdata) {
                    #Check for number of columns in the row
                    $noOfColumnsinRow = ($row -split ';').count
                    Write-LogInfo "Number of columns in the row is >$noOfColumnsinRow<"
                    if($headerColumnCount -eq $noOfColumnsinRow){
                        #Checking whether header is in mandatorylist
                        $isValidRow=validateDataInCSV -Row $row -Headers $headers -Mandatoryattr $Mandatoryattr
                        #If validation of the data in the row is successful, process the record
                        Write-LogInfo "IsValidRow is set to >$isValidRow<"
                        if($isValidRow){
                            $GroupName=$row.GroupName
                            $UserDomain=$row.UserDomain
                            $GroupDN=$row.GroupDN
                            $GroupDomain=$row.GroupDomain
                            $User=$row.UserSAMAccountName
                            $UserDN=$row.UserDN
                            #Check whether group exists
                            $isGrpExists=Invoke-Command -Session $SessionObj -ScriptBlock { Get-ADGroup -Identity $using:GroupDN -Server $using:GroupDomain }
                            if($isGrpExists){
                                #Iterate over list of users to be added to the group
                                 $isUserExists=Invoke-Command -Session $SessionObj -ScriptBlock { Get-ADUser -Identity $using:UserDN -Server $using:UserDomain -Credential $using:CredentialObj }
                                if($isUserExists){
                                     Invoke-Command -Session $SessionObj -ScriptBlock { Set-AdObject -Identity "$using:GroupDN" -Add @{member="$using:UserDN"} -Credential $using:CredentialObj }
                                     $respCode=0
                                     Write-LogInfo "User added to group"
                                }else{
                                    Write-LogInfo "User >$user< does not exist, skipping this user"
                                }
                            }else{
                                Write-LogInfo "$GroupName does not exist"
                                break
                            }
                        }else{
                            Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                        }
                    }else{
                        Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                    }
                }
            }
            Write-LogInfo "Exiting Function AD_AddUsertoGroup, with return code::$respCode"
            return $respCode
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
        }
    }
}

<#
    .SYNOPSIS
        This function creates password policy in Active Directory 
    .DESCRIPTION
        This function creates password policy in Active Directory. This function takes CSV input. The template of CSV should be PasswordPolicyName,Precedence,MinPasswordLength,MaxPasswordAge,MinPasswordAge,PasswordHistoryCount,LockoutDuration,LockoutObservationWindow,LockoutThreshold
    .PARAMETER CSVFilePath
        CSV File Path.       
    .PARAMETER SessionObj
        PSSession Object    
    .PARAMETER MandatoryAttr
        List of mandatory attributes for execution of the command    
#>
function AD_CreatePasswordPolicy {
    [CmdletBinding()]
    [OutputType([int])] 
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [string] $CSVFilePath,
        [Parameter(Mandatory=$True,Position=1)]
        [System.Management.Automation.Runspaces.PSSession] $SessionObj,
        [Parameter(Mandatory=$True,Position=2)]
        [array] $MandatoryAttr
    )
    Process{
        try{
            Write-LogInfo "Inside Function AD_CreatePasswordPolicy"
            $respCode=1
            #Test if CSV file is present
            if ((Test-path ($CSVFILEPATH)) -eq $false){
                throw "CSV FILE $CSVFILEPATH not found!"
            }

            #Get number of columns in the header
            $headerColumnCount=Get-HeaderColumnCount -CSVFILEPATH $CSVFilePath
            Write-LogInfo "Number of header columns is >$headerColumnCount<"

            #Import CSV
            $csvdata = Import-Csv -Path $CSVFILEPATH
            if(!($null -eq $csvdata)){
                #Get all headers
                $headers = ($csvdata | Get-Member -MemberType NoteProperty).Name
                foreach ($row in $csvdata) {
                    #Check for number of columns in the row
                    $noOfColumnsinRow = ($row -split ';').count
                    Write-LogInfo "Number of columns in the row is >$noOfColumnsinRow<"
                    if($headerColumnCount -eq $noOfColumnsinRow){
                        #Checking whether header is in mandatorylist
                        $isValidRow=validateDataInCSV -Row $row -Headers $headers -Mandatoryattr $MandatoryAttr
                        #If validation of the data in the row is successful, process the record
                        Write-LogInfo "IsValidRow is set to >$isValidRow<"
                        if($isValidRow){
                            $PasswordPolicyName=$row.PasswordPolicyName
                            $Precedence=$row.Precedence
                            $MinPasswordLength=$row.MinPasswordLength
                            $MaxPasswordAge=$row.MaxPasswordAge
                            $MinPasswordAge=$row.MinPasswordAge
                            $PasswordHistoryCount=$row.PasswordHistoryCount
                            $LockoutDuration=$row.LockoutDuration
                            $LockoutObservationWindow=$row.LockoutObservationWindow
                            $LockoutThreshold=$row.LockoutThreshold
                            $ScriptBlock="New-ADFineGrainedPasswordPolicy -Name '$PasswordPolicyName' -Precedence $Precedence -MinPasswordLength $MinPasswordLength -MaxPasswordAge $MaxPasswordAge -MinPasswordAge $MinPasswordAge -PasswordHistoryCount $PasswordHistoryCount -ComplexityEnabled:$true -LockoutDuration $LockoutDuration -LockoutObservationWindow $LockoutObservationWindow -LockoutThreshold $LockoutThreshold -ReversibleEncryptionEnabled:$false"
                            $respCode=Submit-WinCommand -ScriptBlock $ScriptBlock -Session $SessionObj
                            if($respCode -eq 0){
                                Write-LogInfo "Password Policy created successfully >$PasswordPolicyName<"
                            }else{
                                Write-LogInfo "Error occured while creating password policy"
                            }
                        }else{
                            Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                        }
                    }else{
                        Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                    }
                }
            }
            Write-LogInfo "Exiting Function AD_CreatePasswordPolicy, with return code::$respCode"
            return $respCode
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
        }
     }
}

<#
    .SYNOPSIS
        This function adds password policy to a group in Active Directory 
    .DESCRIPTION
        This function adds password policy to a group in Active Directory. This function takes CSV input. The template of CSV should be PasswordPolicyName,GroupName
    .PARAMETER CSVFilePath
        CSV File Path.       
    .PARAMETER SessionObj
        PSSession Object    
    .PARAMETER MandatoryAttr
        List of mandatory attributes for execution of the command    
#>
function AD_ApplyPasswordPolicytoGroup {
    [CmdletBinding()]
    [OutputType([int])] 
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [string] $CSVFilePath,
        [Parameter(Mandatory=$True,Position=1)]
        [System.Management.Automation.Runspaces.PSSession] $SessionObj,
        [Parameter(Mandatory=$True,Position=2)]
        [array] $MandatoryAttr
    )
    Process{
        try{
            Write-LogInfo "Inside Function AD_ApplyPasswordPolicytoGroup"
            $respCode=1

            #Test if CSV file is present
            if ((Test-path ($CSVFILEPATH)) -eq $false){
                throw "CSV FILE $CSVFILEPATH not found!"
            }

            #Get number of columns in the header
            $headerColumnCount=Get-HeaderColumnCount -CSVFILEPATH $CSVFilePath
            Write-LogInfo "Number of header columns is >$headerColumnCount<"

            #Import CSV
            $csvdata = Import-Csv -Path $CSVFILEPATH
            if(!($null -eq $csvdata)){
                #Get all headers
                $headers = ($csvdata | Get-Member -MemberType NoteProperty).Name
                foreach ($row in $csvdata) {
                    #Check for number of columns in the row
                    $noOfColumnsinRow = ($row -split ';').count
                    Write-LogInfo "Number of columns in the row is >$noOfColumnsinRow<"
                    if($headerColumnCount -eq $noOfColumnsinRow){
                        #Checking whether header is in mandatorylist
                        $isValidRow=validateDataInCSV -Row $row -Headers $headers -Mandatoryattr $MandatoryAttr
                        #If validation of the data in the row is successful, process the record
                        Write-LogInfo "IsValidRow is set to >$isValidRow<"
                        if($isValidRow){
                            $PasswordPolicyName=$row.PasswordPolicyName
                            $GroupName=$row.GroupName
                            $ScriptBlock="Add-ADFineGrainedPasswordPolicySubject '$PasswordPolicyName' -Subjects '$GroupName'"
                            $respCode=Submit-WinCommand -ScriptBlock $ScriptBlock -Session $SessionObj
                            if($respCode -eq 0){
                                Write-LogInfo "Password Policy >$PasswordPolicyName< applied to the group >$GroupName<"
                            }else{
                                Write-LogInfo "Error occured while applying password policy to the group"
                            }
                        }else{
                            Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                        }
                    }else{
                        Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                    }
                }
            }
            Write-LogInfo "Exiting Function AD_ApplyPasswordPolicytoGroup, with return code::$respCode"
            return $respCode
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
        }
       
    }
}

<#
    .SYNOPSIS
        This function creates a user in Active Directory 
    .DESCRIPTION
        This function creates a user in Active Directory. This function takes CSV input. The template of CSV should be FirstName,LastName,Email,Path,StreetAddress,City,PostcalCode,PhoneAreaCode,State,Country,CountryCode,Department,Title,Company,initials
    .PARAMETER CSVFilePath
        CSV File Path. 
    .PARAMETER dnsDomain
        Domain name under which the user is created     
    .PARAMETER isPartner
        Yes/No: If yes is set, this function will execute the script and create the user in Partner domain. 
    .PARAMETER SessionObj
        PSSession Object    
    .PARAMETER MandatoryAttr
        List of mandatory attributes for execution of the command    
#>
function AD_CreateUser {
    [CmdletBinding()]
    [OutputType([int])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [string] $CSVFilePath,
        [Parameter(Mandatory=$True,Position=1)]
        [string] $dnsDomain,
        [Parameter(Mandatory=$True,Position=2)]
        [string] $IsPartner,
        [Parameter(Mandatory=$True,Position=3)]
        [System.Management.Automation.Runspaces.PSSession] $SessionObj,
        [Parameter(Mandatory=$True,Position=4)]
        [array] $MandatoryAttr
    )
    Process{
        try{
            Write-LogInfo "Inside Function AD_CreateUser" 
            $respCode=1
            #Test if CSV file is present
            if ((Test-path ($CSVFILEPATH)) -eq $false){
                throw "CSV FILE $CSVFILEPATH not found!"
            }

            #Get number of columns in the header
            $headerColumnCount=Get-HeaderColumnCount -CSVFILEPATH $CSVFilePath
            Write-LogInfo "Number of header columns is >$headerColumnCount<"

            #Import CSV
            $csvdata = Import-Csv -Path $CSVFILEPATH

            if(!($null -eq $csvdata)){
                #Get all headers
                $headers = ($csvdata | Get-Member -MemberType NoteProperty).Name
                foreach ($row in $csvdata) {
                    #Check for number of columns in the row
                    $noOfColumnsinRow = ($row -split ';').count
                    Write-LogInfo "Number of columns in the row is >$noOfColumnsinRow<"
                    if($headerColumnCount -eq $noOfColumnsinRow){
                        #Checking whether header is in mandatorylist
                        $isValidRow=validateDataInCSV -Row $row -Headers $headers -Mandatoryattr $MandatoryAttr
                        #If validation of the data in the row is successful, process the record
                        Write-LogInfo "IsValidRow is set to >$isValidRow<"
                        if($isValidRow){
                            $employeeNumber = Get-Random -Minimum 100000 -Maximum 1000000
                            $userExists = $false
                            $firstName=$row.FirstName
                            $lastName=$row.LastName
                            $userName=$firstName+" "+$lastName
                            $sAMAccountName = $firstName + "." + $lastName
                            $initialPassword = "StrongPassworld!23" 
                            $securePassword = ConvertTo-SecureString -AsPlainText $initialPassword -Force
                            $DisplayName=$lastName + "," + $firstName
                            $UserCreatePath=$row.Path
                            $EmailAddress=$row.Email
                            $StreetAddress=$row.StreetAddress
                            $City=$row.City
                            $CountryCode=$row.CountryCode
                            $PostalCode=$row.PostalCode
                            $State=$row.State
                            $Country=$row.Country
                            $UserPrincipalName=$null
                            if($IsPartner -eq "Yes"){
                                $UserPrincipalName=$row.Email
                            }else{
                                $UserPrincipalName=$sAMAccountName+"@"+$dnsDomain
                            }
                            $Company=$row.Company
                            $Department=$row.Department
                            $Title=$row.Title
                            $officePhone = $CountryCode + "-" + $row.PhoneAreaCode + "-" + (Get-Random -Minimum 100000 -Maximum 1000000)
                            $initials=$row.initials
                            $userExists = Invoke-Command -Session $SessionObj -ScriptBlock { Get-ADUser -LDAPFilter "(sAMAccountName=$using:sAMAccountName)" }
                            Write-LogInfo "Is userExists >$userExists<"
                            $userCreated=$null
                            if(!($userExists)){
                                #Create User
                                Invoke-Command -Session $SessionObj -ScriptBlock { New-ADUser -SamAccountName $using:sAMAccountName -Name $using:userName -Path $using:UserCreatePath -AccountPassword $using:securePassword -Enabled $true -GivenName $using:firstName -Surname $using:lastName -DisplayName $using:DisplayName -EmailAddress $using:EmailAddress -StreetAddress $using:StreetAddress -City $using:City -PostalCode $using:PostalCode -State $using:State -Country $using:Country -UserPrincipalName $using:UserPrincipalName -Company $using:Company -Department $using:Department -EmployeeNumber $using:employeeNumber -Title $using:Title -OfficePhone $using:officePhone -initials $using:initials }
                                Write-LogInfo "Created user is >$sAMAccountName<"
                                $userCreated=$true
                            }
                            #Check if user is created and update custom attributes
                            if($userCreated){
                                $Co=$row.Co
                                $thumbnailPhoto=[byte[]](Get-Content $row.Thumbnail -Encoding byte)
                                 #Check if Partner user is created and update attributes in Partner domain
                                if($IsPartner -eq "Yes"){
                                    $PartnerCode=$row.PartnerCode
                                    Invoke-Command -Session $SessionObj -ScriptBlock { Set-ADUser -Identity $using:sAMAccountName -Replace @{countryCode=$using:CountryCode;co=$using:Co;partnerCode=$using:PartnerCode;thumbnailPhoto=$using:thumbnailPhoto} }
                                    Write-LogInfo "User >$sAMAccountName< updated with custom attribute value"
                                }else{
                                    #custom attributes for initechdemo domain
                                    $physicalDeliveryOfficeName=$row.physicalDeliveryOfficeName
                                    $costCenter=$row.costCenter
                                    $managementLevel=$row.managementLevel
                                    $hireDate=Get-Date
                                    $hrOrgCode=$row.hrOrgCode
                                    $hrUserId=$row.hrUserId
                                    $corporateMobile = $CountryCode + "-" + $row.PhoneAreaCode + "-" + (Get-Random -Minimum 100000 -Maximum 1000000)
                                    Invoke-Command -Session $SessionObj -ScriptBlock { Set-ADUser -Identity $using:sAMAccountName -Replace @{countryCode=$using:CountryCode;co=$using:Co;physicalDeliveryOfficeName=$using:physicalDeliveryOfficeName;costCenter=$using:costCenter;managementLevel=$using:managementLevel;hireDate=$using:hireDate;hrOrgCode=$using:hrOrgCode;hrUserId=$using:hrUserId;corporateMobile=$using:corporateMobile;thumbnailPhoto=$using:thumbnailPhoto} }
                                    Write-LogInfo "User >$sAMAccountName< updated with custom attribute value"
                                }
                                $respCode=0
                            }else{
                                Write-LogInfo "User not created"
                            }
                        }else{
                            Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                        }
                    }else{
                        Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                    }
                }
            }
            Write-LogInfo "Exiting Function AD_CreateUser, with return code::$respCode"
            return $respCode
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
        }
    }
}

<#
    .SYNOPSIS
        This function updates user's manager in Active Directory 
    .DESCRIPTION
        This function updates user's manager in Active Directory. This function takes CSV input. The template of CSV should be UserSAMAccountName,MgrSAMAccountName
    .PARAMETER CSVFilePath
        CSV File Path.       
    .PARAMETER SessionObj
        PSSession Object    
    .PARAMETER MandatoryAttr
        List of mandatory attributes for execution of the command    
#>
function AD_UpdateManager {
    [CmdletBinding()]
    [OutputType([int])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [string] $CSVFilePath,
        [Parameter(Mandatory=$True,Position=1)]
        [System.Management.Automation.Runspaces.PSSession] $SessionObj,
        [Parameter(Mandatory=$True,Position=2)]
        [array] $MandatoryAttr
    )
    Process{
        try{
            Write-LogInfo "Inside Function AD_UpdateManager"
            $respCode=1
            #Test if CSV file is present
            if ((Test-path ($CSVFILEPATH)) -eq $false){
                throw "CSV FILE $CSVFILEPATH not found!"
            }

            #Get number of columns in the header
            $headerColumnCount=Get-HeaderColumnCount -CSVFILEPATH $CSVFilePath
            Write-LogInfo "Number of header columns is >$headerColumnCount<"

            #Import CSV
            $csvdata = Import-Csv -Path $CSVFILEPATH
            if(!($null -eq $csvdata)){
                #Get all headers
                $headers = ($csvdata | Get-Member -MemberType NoteProperty).Name
                foreach ($row in $csvdata) {
                    #Check for number of columns in the row
                    $noOfColumnsinRow = ($row -split ';').count
                    Write-LogInfo "Number of columns in the row is >$noOfColumnsinRow<"
                    if($headerColumnCount -eq $noOfColumnsinRow){
                        #Checking whether header is in mandatorylist
                        $isValidRow=validateDataInCSV -Row $row -Headers $headers -Mandatoryattr $MandatoryAttr
                        #If validation of the data in the row is successful, process the record
                        Write-LogInfo "IsValidRow is set to >$isValidRow<"
                        if($isValidRow){
                            $userExists = $false
                            $sAMAccountName=$row.UserSAMAccountName
                            $MgrSAMAccountName=$row.MgrSAMAccountName
                            Write-LogInfo "sAMAccountName:$sAMAccountName , MgrSAMAccountName:$MgrSAMAccountName"
                            $userExists = Invoke-Command -Session $SessionObj -ScriptBlock { Get-ADUser -Identity $using:sAMAccountName -Properties * }
                            Write-LogInfo "Is userExists >$userExists<" 
                            if($userExists){
                                # Update the user's manager
                                $ScriptBlock="Set-ADUser -Identity '$sAMAccountName' -Manager '$MgrSAMAccountName'"
                                $respCode=Submit-WinCommand -ScriptBlock $ScriptBlock -Session $SessionObj
                                if($respCode -eq 0){
                                    Write-LogInfo "User's >$sAMAccountName< manager updated >$MgrSAMAccountName<"
                                }else{
                                    Write-LogInfo "Error occured while updating manager"
                                }
                             }else{
                                Write-LogInfo "User does not exist >$sAMAccountName<"
                            }
                        }else{
                            Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                        }
                    }else{
                        Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                    }
                }
            }
            Write-LogInfo "Exiting Function AD_UpdateManager, with return code::$respCode"
            return $respCode
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
        }
     }
}

<#
    .SYNOPSIS
        This function imports custom attributes in Active Directory 
    .DESCRIPTION
        This Functions imports custom attributes in Active Directory. This function takes CSV input. The template of CSV should be UserSaMAccountName,ManagerSAMAccountName
    .PARAMETER csvFile
        CSV File Path.       
    .PARAMETER SessionObj
        PSSession object    
    .PARAMETER SourceLdifFilePath
        Location of Ldif on source machine
    .PARAMETER DestLdifFilePath
        Location of Ldif on the destination host  
#>
function AD_ImportLdif {
    [CmdletBinding()]
    [OutputType([int])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [string] $LdifFileName,
        [Parameter(Mandatory=$True,Position=1)]
        [string] $SourceLdifFilePath,
        [Parameter(Mandatory=$True,Position=2)]
        [string] $DestLdifFilePath,
        [Parameter(Mandatory=$True,Position=3)]
        [System.Management.Automation.Runspaces.PSSession] $SessionObj
    )
    Process{
        try{
            Write-LogInfo "Inside Function AD_ImportLdif"
            $respCode=1
            $sourceFile=$SourceLdifFilePath+"\"+$LdifFileName
            $destFile=$DestLdifFilePath+"\"+$LdifFileName
            Write-LogInfo "sourceFile >$sourceFile< , destFile>$destFile<"
            #Copy the ldif file on DC. If the file exists, it will overwrite
            Copy-Item -Path $sourceFile -ToSession $SessionObj -Destination $destFile
            #Test whether file is copied on DC
            Invoke-Command -Session $SessionObj -ScriptBlock { Test-Path -Path "$Using:destFile" }
            Write-LogInfo "Copied Ldif file and now starting import"
            Invoke-Command -Session $SessionObj -ScriptBlock { ldifde -i -f "$Using:destFile" }
            $respCode=0
            Write-LogInfo "Ldif import is successful, now removing the session"
            Write-LogInfo "Exiting Function AD_ImportLdif, with return code::$respCode"
            return $respCode
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
    }
}
