For this module to be available in PowerShell environment, you'll need to install and import the module first.

Installation:
-------------

    To install the module, you can either copy it the existing Module home or add the module path to the PSModulePath.
        1. Add module path to PSModulePath
            Following command can be used to add the module to PSModulePath:
            PS C:\Users\username> $env:PSModulePath = $env:PSModulePath + "$([System.IO.Path]::PathSeparator)<Path to module directory>"
    
            For example: When module folder is located under "C:\Users\jniberiya\projects\azuread\azadiam-repo\configuration-scripts" path.
            PS C:\Users\jniberiya> $env:PSModulePath = $env:PSModulePath + "$([System.IO.Path]::PathSeparator)C:\Users\jniberiya\projects\azuread\azadiam-repo\configuration-scripts"
    
        2. Add to existing module home
            PowerShell module home can be found at $USER_HOME\Documents\WindowsPowerShell\Modules
            For example: C:\Users\jniberiya\Documents\WindowsPowerShell\Modules
            You can directly copy the module folder to the module home. This will install the module.

Import:
-------

    To import the module, you can use following command:
    PS C:\Users\username> Import-Module KPMG.AD-Utils

---------------------------------------------------------------------------------------------------------------------------------------------------

Once the module is installed and imported, the module functions shall be available for use.

This module requires following pre-requisite modules to be imported beforehand:
    1. KPMG.Common-Utils  