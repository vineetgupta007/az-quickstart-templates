#Import pre-requisite modules
Import-Module KPMG.Common-Utils

#Get public and private function definition files.
$Public = @( Get-ChildItem -Path $PSScriptRoot\public\*.ps1 -ErrorAction SilentlyContinue )
$Private = @( Get-ChildItem -Path $PSScriptRoot\private\*.ps1 -ErrorAction SilentlyContinue )

#Load module source files
Foreach ($import in @($Public + $Private)) {
    try {
        . $import.fullname
    }
    catch {
        Write-Error -Message "Failed to import function $($import.fullname): $_"
    }
}

Set-Variable -Name SCRIPT_PATH -Value (Split-Path (Resolve-Path $myInvocation.MyCommand.Path)) -Scope local
Set-Variable -Name FULL_SCRIPT_PATH -Value (Resolve-Path $myInvocation.MyCommand.Path) -Scope local
Set-Variable -Name CURRENT_PATH -Value ((Get-Location).Path) -Scope local

#Export AD util functions
Export-ModuleMember -Function Add-ADDCFeatures
Export-ModuleMember -Function Get-UsersFromAD
Export-ModuleMember -Function Install-DomainController
Export-ModuleMember -Function AD_CreateOU
Export-ModuleMember -Function AD_CreateGroup
Export-ModuleMember -Function AD_AddUsertoGroup
Export-ModuleMember -Function AD_CreatePasswordPolicy
Export-ModuleMember -Function AD_ApplyPasswordPolicytoGroup
Export-ModuleMember -Function AD_CreateUser
Export-ModuleMember -Function AD_UpdateManager
Export-ModuleMember -Function AD_ImportLdif