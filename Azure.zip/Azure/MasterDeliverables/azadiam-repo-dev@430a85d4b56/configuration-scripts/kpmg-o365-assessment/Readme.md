Module: kpmg-o365-assessment
This module contains scripts associated with office365 IP assessments

# O365 Assessment Setup
The following scripts are available to orchestrate the generation of reports and uploading them to Azure Blob Storage and Azure Log Analytics Workspace

|     Script                |     Description                                                                                        |
|---------------------------|--------------------------------------------------------------------------------------------------------|
| o365-security.ps1         | An orchestration script to run all the functions in order to get data from azure, generate CSV reports and upload them to Azure Blob Storage and Azure Log Analytics Workspace |
| o365-security-utils.ps1 | An one stop script containing all the functions for running pre check, getting all data for assessment and uploading them to Azure Log Analytics Workspace |

## Before you begin

## Configuration file

The script use a common configuration file available in `$SCRIPTHOME\configuration-scripts\kpmg-o365-assessment\config\config.json`.
The configuration file must be updated with appropriate configuration before running the script.

The configuration file consists of different configuration sets corresponding to each component of AzureAD, Log Analytics Workspace, Blob Storage and Assessment Criteria.

---
------------------------------------------------------------
# O365 Assessment Configuration Setup
------------------------------------------------------------

***NOTE***

- DO NOT change the value below config key in config.json's config key 'azure-ad-assessment-config'

---

|     Parameter             |    Description    											|
|---------------------------|-------------------------------------------------------------|
| workbookTemplateName      |	Name of the Workbook ARM template file										|
| failedStatus              |	Failure status symbol used in workbook to show results									    |
| successStatus             |	Success status symbol used in workbook to show results										|
---

The configuration contains the following parameters for the O365 IP Security Assessment setup:

|     Parameter          |Mandatory/Optional (Default Value) |    Description    											 |
|------------------------|---------------------------------------|------------------------------------------------------------------|
| username		            | Mandatory                   		 |   User name of the user being used for this assessment                                              |
| password		            | Mandatory                   		 |   password of the user being used for this assessment 											  |
| AADLicense        	    | Mandatory (AAD_PREMIUM_P2)  		 |   Azure AD License 																                 |
| subscriptionName          | Mandatory 				 		 | 	 Azure Subscription Name where resources are placed										            |
| storageAccountRG          | Mandatory 				  		 | 	 Azure Resource Group where resources are placed												   |
| storageAccountName        | Mandatory 				  		 | 	 Azure Storage Account Name															             |
| storageContainerName      | Mandatory 				  		 | 	 Azure Blob Container Name															             |
| tenantId      	        | Mandatory 				  		 | 	 Azure AD Tenant ID															                     |
| workbookName         	    | Mandatory     			         | 	 Name of the Azure Workbook where assessment results will be displayed															                 |
| workbookTemplateName         	    | Mandatory     			         | 	 Name of the Azure Workbook template name															                 |
| workbookNameARM         	    | Mandatory     			         | 	 Name of the Azure Workbook ARM Name 															                 |
| createResource         	    | Mandatory     			         | 	  Flag for creating new resourec group and workspace e.g. value should be true or false|															                 |
| resourceGroupLocation | Mandatory						 | Location to create resource groups     |
| workspaceLocation | Mandatory						 | Location to create log analytics workspace     |
| mcastoken         	    | Mandatory     			         | 	 Create Cloud App Security API token and update it here (Refer: https://docs.microsoft.com/en-us/cloud-app-security/api-authentication) for token creation															                 |
| baseurl         	    | Mandatory     			         | 	 Capture Cloud App Security URL														                 |

| report_SensitivityLabelSummary		    | Mandatory                          |	Report name for Sensitivity Label Summary in Blob Storage														| 
| report_DLPCompliancePolicySummary        | Mandatory                          |	Report name for Data Loss Prevention Summary in Blob Storage													|
| report_RetentionCompliancePolicySummary       | Mandatory                          |	Report name for Data Retention Summary in Blob Storage															|
| laws_SensitivityLabelSummary	| Mandatory                          |	Log Table name for Sensitivity Label Summary in LAWS																|
| laws_DLPCompliancePolicySummary		    | Mandatory                          |   Log Table name for Data Loss Prevention Summary	in LAWS														| 
| laws_RetentionCompliancePolicySummary          | Mandatory                          |	Log Table name for Data Retention Summary in LAWS															|
| mcas_app          | Mandatory                          |	Cloud App Security Application IDs															|
| resourceGroupLocation | Mandatory						 | Location to create resource groups     |
| workspaceLocation | Mandatory						 | Location to create log analytics workspace     |
---
**NOTE**

Remove all the comments, if present, from the configuration file. These are indicated by `//` at the start of the line.


---

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The Azure AD Assessment script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-o365-assessment\bin` folder
3. Run script
    ```powershell
    $ .\o365-security.ps1 -ConfigToLoad "o365-security-config"
    ```
    This will generate reports and place them in Azure Blob Storage and Log analytics workspace. Also, this will deploy Workbook as per "workbookName" parameter in configuration file if workbook already doesn't exists. This workbook can be used to view the assessment result each time assessment script is being executed.

### Examples
1. To setup application-proxy with Debug logs on console
    ```powershell
    $ .\o365-security.ps1 -ConfigToLoad "o365-security-config" -LogLevel "Debug"
	```
2. To setup application-proxy with Debug logs in file
    ```powershell
    $ .\o365-security.ps1 -ConfigFile "config.json" -ConfigToLoad "o365-security-config" -LogLevel "Debug" -Type "File" -FileName "O365IPLogger" 
    ```
	