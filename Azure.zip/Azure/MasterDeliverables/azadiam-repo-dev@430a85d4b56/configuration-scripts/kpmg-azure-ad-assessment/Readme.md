Module: kpmg-azure-ad-assessment
This module contains scripts associated with Azure Active Directory security assessments

# Azure Active Directory Setup
The following scripts are available to orchestrate the generation of reports and uploading them to Azure Blob Storage and Azure Log Analytics Workspace

|     Script                |     Description                                                                                        |
|---------------------------|--------------------------------------------------------------------------------------------------------|
| AzADAssessment.ps1         | An orchestration script to run all the functions in order to get data from azure, generate CSV reports and upload them to Azure Blob Storage and Azure Log Analytics Workspace |
| AzADAssessmentUtil.ps1 | An one stop script containing all the functions for running pre check, getting all data for assessment and uploading them to Azure Log Analytics Workspace |

## Before you begin

## Configuration file

The script use a common configuration file available in `$SCRIPTHOME\configuration-scripts\kpmg-azure-ad-assessment\config\config.json`.
The configuration file must be updated with appropriate configuration before running the script.

The configuration file consists of different configuration sets corresponding to each component of AzureAD, Log Analytics Workspace, Blob Storage and Assessment Criteria.

---
------------------------------------------------------------
# Azure Active Directory Assessment Setup
------------------------------------------------------------

***NOTE***

- DO NOT change the value below config key in config.json's config key 'azure-ad-assessment-config'

---

|     Parameter             |    Description    											|
|---------------------------|-------------------------------------------------------------|
| workbookTemplateName      |	Name of the Workbook ARM template file										|
| failedStatus              |	Assessment Failure status symbol used in workbook to show results									    |
| successStatus             |	Assessment Success status symbol used in workbook to show results										|
---

The configuration contains the following parameters for the Azure AD Security Assessment setup:

|     Parameter          |Mandatory/Optional (Default Value) |    Description    											 |
|------------------------|---------------------------------------|------------------------------------------------------------------|
| username		            | Mandatory                   		 |   User name of the user being used for this assessment                                              |
| password		            | Mandatory                   		 |   password of the user being used for this assessment 											  |
| AADLicense        	    | Mandatory (AAD_PREMIUM_P2)  		 |   Azure AD License 																                 |
| subscriptionName          | Mandatory 				 		 | 	 Azure Subscription Name where resources are placed										            |
| storageAccountRG          | Mandatory 				  		 | 	 Azure Resource Group where resources are placed												   |
| storageAccountName        | Mandatory 				  		 | 	 Azure Storage Account Name (must be lowercase letters and numbers)															             |
| storageContainerName      | Mandatory 				  		 | 	 Azure Blob Container Name (must be lowercase letters, numbers and hyphens)																             |
| tenantId      	        | Mandatory 				  		 | 	 Azure AD Tenant ID															                     |
| clientId       	        | Mandatory 				  		 | 	 Registered App ID														                         |
| clientSecret         	    | Mandatory     				     | 	 Registered App Secret															                 |
| workbookName         	    | Mandatory     			         | 	 Name of the Azure Workbook where assessment results will be displayed															                 |
| report_AssessmentCriteria	| Mandatory                          |	File Name (without format name) containing all assessment criteria, criticality and impact scores															|
| report_MFAEnabled		    | Mandatory                          |	Report name for MFA Enabled User in Blob Storage														| 
| report_MFADisabled        | Mandatory                          |	Report name for MFA Disabled User in Blob Storage													|
| report_ClassicAdmin       | Mandatory                          |	Report name for Classic Admins MFA in Blob Storage															|
| report_AzureADAdmin	    | Mandatory                          |	Report name for Azure AD Admins	in Blob Storage														|
| report_RBACAdmin		    | Mandatory                          |	Report name for RBAC Role assignment in Blob Storage															|
| report_CompanyInformation | Mandatory                          |	Report name for Azure Tenant information in Blob Storage															|
| report_GuestUsers         | Mandatory                          |	Report name for Guest User in Blob Storage															|
| report_EmptyGroups        | Mandatory                          |	Report name for Empty Group	in Blob Storage														|
| report_PasswordExpiry     | Mandatory                          |	Report name for Password Expiration	in Blob Storage														|
| report_LastLoginActivity  | Mandatory                          |	Report name for Last Login Activity	in Blob Storage														|
| laws_AssessmentCriteria	| Mandatory                          |	Log Table name for Assessment criteria in LAWS																|
| laws_MFAEnabled		    | Mandatory                          |   Log Table name for MFA Enabled User	in LAWS														| 
| laws_MFADisabled          | Mandatory                          |	Log Table name for MFA Disabled User in LAWS															|
| laws_ClassicAdmin         | Mandatory                          |	Log Table name for Classic Admins MFA in LAWS														|
| laws_AzureADAdmin	        | Mandatory                          |	Log Table name for Azure AD Admins in LAWS															|
| laws_RBACAdmin		    | Mandatory                          |	Log Table name for RBAC Role assignment in LAWS															|
| laws_CompanyInformation   | Mandatory                          |	Log Table name for Azure Tenant information	in LAWS														|
| laws_GuestUsers           | Mandatory                          |	Log Table name for Guest User in LAWS															|
| laws_EmptyGroups          | Mandatory                          |	Log Table name for Empty Group in LAWS														|
| laws_PasswordExpiry       | Mandatory                          |	Log Table name for Password Expiration in LAWS															|
| laws_LastLoginActivity    | Mandatory                          |	Log Table name for Last Login Activity in LAWS															|   
| laws_companyDomain        | Mandatory                          |	Domain name of the company active directory connected to Azure AD															| 
| laws_techDL               | Mandatory                          |	Starting of DL name assigned as technical contact															| 
| createResource		 |	Mandatory       				 | Flag for creating new resourec group and workspace e.g. value should be true or false|
| resourceGroupLocation | Mandatory						 | Location to create resource groups     |
| workspaceLocation | Mandatory						 | Location to create log analytics workspace     |
---
**NOTE**

Remove all the comments, if present, from the configuration file. These are indicated by `//` at the start of the line.

---

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The Azure AD Assessment script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad-assessment\bin` folder
3. Run script
    ```powershell
    $ .\AzADAssessment.ps1 -ConfigToLoad "azure-ad-assessment-config"
    ```
    This will generate reports and place them in Azure Blob Storage and Log analytics workspace. Also, this will deploy Workbook as per "workbookName" parameter in configuration file if workbook already doesn't exists. This workbook can be used to view the assessment result each time assessment script is being executed.

### Examples
1. To setup application-proxy with Debug logs on console
    ```powershell
    $ .\AzADAssessment.ps1 -ConfigToLoad "azure-ad-assessment-config" -LogLevel "Debug"
	```
2. To setup application-proxy with Debug logs in file
    ```powershell
    $ .\AzADAssessment.ps1 -ConfigFile "config.json" -ConfigToLoad "azure-ad-assessment-config" -LogLevel "Debug" -Type "File" -FileName "AzADAssessmentLogger" 
    ```

