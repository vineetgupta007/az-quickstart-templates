<#
    .SYNOPSIS
        Deploy logic apps to Azure AD
    .DESCRIPTION
        This is the script to deploy logic apps in Azure AD using ARM template.
    .PARAMETER alertConfig
        JSON containing configuration of alert that is to be created. This element exists in the config.json 
        file as azure-alerts-management array.
    .EXAMPLE
        1. To Execute the script in main-forest, DC1
			.\CreateAzAlerts.ps1 -alertConfig $alertConfigJson
#>
function Create-AzAlert {
    [CmdletBinding()]
Param(
    [Parameter(Mandatory = $False, HelpMessage = "Enter the configuration file that has relevant configuration.", Position = 0)]
    [PSCustomObject]$alertConfig   
    )
    try {
        #Default exit code
        $LASTEXITCODE = 1

        # Processing alert configurations array
        foreach($i in 0..($alertConfig.Count-1)) {
            $incremented_count=($i+1)
            Write-LogInfo "Alert Config Iteration: $incremented_count"

            #Read config types
            $alertKeyNames = $alertConfig[$i] | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
            if($null -ne $alertKeyNames) {
                Write-LogInfo "Validating Azure Alerts configurations"

                ##########################################################################
                # Validate top level configurations
                ##########################################################################
                Write-LogInfo "Validating top level configurations"

                $alertNameConfig="alertName"
                if($alertKeyNames -contains $alertNameConfig) {
                    $alertName=$alertConfig[$i].$alertNameConfig
                }
                If($null -eq $alertName){
                    $LASTEXITCODE = 2
                    Throw "Selected $alertNameConfig is not configured in JSON properties file"
                }
                Write-LogDebug "Alert Name: $alertName"            

                $alertDescriptionConfig="alertDescription"
                if($alertKeyNames -contains $alertDescriptionConfig) {
                    $alertDescription=$alertConfig[$i].$alertDescriptionConfig
                }
                If($null -eq $alertDescription){
                    $LASTEXITCODE = 3
                    Throw "Selected $alertDescriptionConfig is not configured in JSON properties file"
                }
                Write-LogDebug "Alert description: $alertDescription"

                $alertResourceGroupConfig="alertResourceGroup"
                if($alertKeyNames -contains $alertResourceGroupConfig) {
                    $alertResourceGroup=$alertConfig[$i].$alertResourceGroupConfig
                }
                If($null -eq $alertResourceGroup){
                    $LASTEXITCODE = 4
                    Throw "Selected $alertResourceGroupConfig is not configured in JSON properties file"
                }
                Write-LogDebug "Alert Resource Group Name: $alertResourceGroup"

                $isEnabledConfig="isEnabled"
                if($alertKeyNames -contains $isEnabledConfig) {
                    $isEnabled=$alertConfig[$i].$isEnabledConfig
                }
                If($null -eq $isEnabled){
                    $LASTEXITCODE = 5
                    Throw "Selected $isEnabledConfig is not configured in JSON properties file"
                }
                Write-LogDebug "isEnabled: $isEnabled"
                
                $workspaceNameConfig="workspaceName"
                if($alertKeyNames -contains $workspaceNameConfig) {
                    $workspaceName=$alertConfig[$i].$workspaceNameConfig
                }
                If($null -eq $workspaceName){
                    $LASTEXITCODE = 6
                    Throw "Selected $workspaceNameConfig is not configured in JSON properties file"
                }
                Write-LogDebug "Workspace Name: $workspaceName"

                $workspaceResourceGroupConfig="workspaceResourceGroup"
                if($alertKeyNames -contains $workspaceResourceGroupConfig) {
                    $workspaceResourceGroup=$alertConfig[$i].$workspaceResourceGroupConfig
                }
                If($null -eq $workspaceResourceGroup){
                    $LASTEXITCODE = 7
                    Throw "Selected $workspaceResourceGroupConfig is not configured in JSON properties file"
                }
                Write-LogDebug "Workspace Location: $workspaceResourceGroup"

                $AZActionGroupConfig="action-group-config"
                if($alertKeyNames -contains $AZActionGroupConfig) {
                    $AZActionGroupProps=$alertConfig[$i].$AZActionGroupConfig
                }
                If($null -eq $AZActionGroupProps){
                    $LASTEXITCODE = 8
                    Throw "Selected $AZActionGroupConfig is not configured in JSON properties file"
                }

                $ScheduledQueryRulesConfig="scheduled-query-rules-config"
                if($alertKeyNames -contains $ScheduledQueryRulesConfig) {
                    $ScheduledQueryRulesProps=$alertConfig[$i].$ScheduledQueryRulesConfig
                }
                If($null -eq $ScheduledQueryRulesProps){
                    $LASTEXITCODE = 9
                    Throw "Selected $ScheduledQueryRulesConfig is not configured in JSON properties file"
                }

                $AlertingActionConfig="alerting-action-config"
                if($alertKeyNames -contains $AlertingActionConfig) {
                    $AlertingActionProps=$alertConfig[$i].$AlertingActionConfig
                }
                If($null -eq $AlertingActionProps){
                    $LASTEXITCODE = 10
                    Throw "Selected $AlertingActionConfig is not configured in JSON properties file"
                }
                
                ##########################################################################
                # Validate Action Group Configurations
                ##########################################################################   
                Write-LogInfo "Validating Action Group configurations"
                If($null -eq $AZActionGroupProps.resourceGroupName){
                    $LASTEXITCODE = 11
                    Throw "ResourceGroupName is not configured in JSON properties file"
                }
                $log_var=$AZActionGroupProps.resourceGroupName
                Write-LogDebug "Resource Group Name: $log_var"
                
                If($null -eq $AZActionGroupProps.logicAppName){
                    $LASTEXITCODE = 12
                    Throw "logicAppName is not configured in JSON properties file"
                }
                $log_var=$AZActionGroupProps.logicAppName
                Write-LogDebug "logic App Name: $log_var"            
                
                If($null -eq $AZActionGroupProps.actionGroupName){
                    $LASTEXITCODE = 13
                    Throw "actionGroupName is not configured in JSON properties file"
                }
                $log_var=$AZActionGroupProps.actionGroupName
                Write-LogDebug "action Group Name: $log_var"
                
                If($null -eq $AZActionGroupProps.actionGroupShortName){
                    $LASTEXITCODE = 14
                    Throw "actionGroupShortName is not configured in JSON properties file"
                }
                $log_var=$AZActionGroupProps.actionGroupShortName
                Write-LogDebug "action Group Short Name: $log_var"
                
                If($null -eq $AZActionGroupProps.useCommonAlertSchema){
                    $LASTEXITCODE = 15
                    Throw "useCommonAlertSchema is not configured in JSON properties file"
                }
                $log_var=$AZActionGroupProps.useCommonAlertSchema
                Write-LogDebug "use Common Alert Schema: $log_var"
                
                If($null -eq $AZActionGroupProps.receiverName){
                    $LASTEXITCODE = 16
                    Throw "receiverName is not configured in JSON properties file"
                }
                $log_var=$AZActionGroupProps.receiverName
                Write-LogDebug "receiver Name: $log_var"

                ##########################################################################
                # Validate Scheduled Query Rules Configurations
                ##########################################################################
                Write-LogInfo "Validating Action Group configurations"        
                If($null -eq $ScheduledQueryRulesProps.query) {
                    $LASTEXITCODE = 17
                    Throw "query is not configured in JSON properties file"
                }
                $log_var=$ScheduledQueryRulesProps.query
                Write-LogDebug "query: $log_var"
                
                If($null -eq $ScheduledQueryRulesProps.queryType){
                    $LASTEXITCODE = 18
                    Throw "queryType is not configured in JSON properties file"
                }
                $log_var=$ScheduledQueryRulesProps.queryType
                Write-LogDebug "queryType: $log_var"
                
                If($null -eq $ScheduledQueryRulesProps.frequencyInMinutes){
                    $LASTEXITCODE = 19
                    Throw "frequencyInMinutes is not configured in JSON properties file"
                }
                $log_var=$ScheduledQueryRulesProps.frequencyInMinutes
                Write-LogDebug "frequencyInMinutes: $log_var"
                
                If($null -eq $ScheduledQueryRulesProps.queryWindow){
                    $LASTEXITCODE = 20
                    Throw "queryWindow is not configured in JSON properties file"
                }
                $log_var=$ScheduledQueryRulesProps.queryWindow
                Write-LogDebug "queryWindow: $log_var"

                ##########################################################################
                # Validate Alerting Action Configurations
                ##########################################################################
                Write-LogInfo "Validating Alerting Action configurations"        
                If($null -eq $AlertingActionProps.thresholdOperator) {
                    $LASTEXITCODE = 21
                    Throw "thresholdOperator is not configured in JSON properties file"
                }
                $log_var=$AlertingActionProps.thresholdOperator
                Write-LogDebug "thresholdOperator: $log_var"
                
                If($null -eq $AlertingActionProps.thresholdValue) {
                    $LASTEXITCODE = 22
                    Throw "thresholdValue is not configured in JSON properties file"
                }
                $log_var=$AlertingActionProps.thresholdValue
                Write-LogDebug "thresholdValue: $log_var"
                
                If($null -eq $AlertingActionProps.severity){
                    $LASTEXITCODE = 23
                    Throw "severity is not configured in JSON properties file"
                }
                $log_var=$AlertingActionProps.severity
                Write-LogDebug "severity: $log_var"

                ##########################################################################
                # Execute Create Action Group Stage
                ##########################################################################            
                #Calling module to create action group
                Write-LogInfo "Calling module to create Action Group"
                Create-ActionGroup -logicAppName $AZActionGroupProps.logicAppName -resourceGroupName $AZActionGroupProps.resourceGroupName -actionGroupName $AZActionGroupProps.actionGroupName -actionGroupShortName $AZActionGroupProps.actionGroupShortName -useCommonAlertSchema $AZActionGroupProps.useCommonAlertSchema -receiverName $AZActionGroupProps.receiverName               
                
                ##########################################################################
                # Execute Alert creation pre-requisites
                ##########################################################################
                Write-LogInfo "Creating/Fetching pre-requisite objects required for final Alert Rule creation"
                #Get workspace details
                $workspace = Get-AzOperationalInsightsWorkspace -Name $workspaceName -ResourceGroupName $workspaceResourceGroup            
                Write-LogDebug "Workspace information: $workspace"

                ##########################################################################
                # Execute Alert creation
                ##########################################################################
                #Calling module to create Alert Rule
                Write-LogInfo "Calling module to create Alert Rule"
                Create-AlertRule -workspaceResourceId $workspace.ResourceId -workspaceLocation $workspace.Location -query $ScheduledQueryRulesProps.query -queryType $ScheduledQueryRulesProps.queryType -frequencyInMinutes $ScheduledQueryRulesProps.frequencyInMinutes -queryWindow $ScheduledQueryRulesProps.queryWindow -thresholdOperator $AlertingActionProps.thresholdOperator -thresholdValue $AlertingActionProps.thresholdValue -alertSeverity $AlertingActionProps.severity -alertResourceGroup $alertResourceGroup -isEnabled $true -alertDescription $alertDescription -alertName $alertName 
            } else {
                $LASTEXITCODE = 24
                Throw "Azure Alerts deployment configuration not found"
            }
        } 
    } catch [System.Exception] {
        Write-LogInfo "Inside catch block."
        If (($LASTEXITCODE -eq $null) -or ($LASTEXITCODE -eq 0)) {
            $LASTEXITCODE = 1
        }
        $ErrorMessage = $_.Exception.Message
        Write-Error "Exit Code :: $LASTEXITCODE | Message :: $ErrorMessage"
    } finally {
        Write-LogInfo "Inside finally block."
        Write-LogInfo "Script finished with exit code :: $LASTEXITCODE"
    }
}



<#
    .SYNOPSIS
        Create Action group that is a pre-requisite for Azure Alert creation
    .DESCRIPTION
        This is the function to create Action group that triggers a logic app which is required while creating an Azure alert.
    .PARAMETER logicAppName
        Specifies the logic app name that will be invoked by this action group.
    .PARAMETER resourceGroupName
        Specifies the logic app resource group name
    .PARAMETER actionGroupName
        Specifies the action group name
    .PARAMETER actionGroupShortName
        Specifies the action group short name
    .PARAMETER useCommonAlertSchema
        Flag whether the common alert schema is enabled/disabled
    .PARAMETER receiverName
        Specifies the receiver that will be used while creating the action group
#>
function Create-ActionGroup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string] $logicAppName,

        [Parameter(Mandatory=$True)]
        [string] $resourceGroupName,

        [Parameter(Mandatory=$true)]
        [string] $actionGroupName,

        [Parameter(Mandatory=$True)]
        [string] $actionGroupShortName,

        [Parameter(Mandatory=$true)]
        [bool] $useCommonAlertSchema,

        [Parameter(Mandatory=$True)]
        [string] $receiverName
    )
    process {
       
            Write-Host "Inside Function Create-ActionGroup"

            # Get logic app resource ID
            $logicAppSearch = Get-AzResource -ResourceGroupName $resourceGroupName -Name $logicAppName -ExpandProperties
            if( $null -eq $logicAppSearch) {
                $LASTEXITCODE = 5
                Throw "Could not find Logic App $logicAppName while creating Action group"
            }
            Write-Host "Logic App Resource ID: "$logicAppSearch.ResourceId
            Write-Host "Logic App callback URL: "$logicAppSearch.Properties.accessEndpoint
            
            # get receivable object        
            $logicAppReceiver = New-AzActionGroupReceiver -Name $receiverName -LogicAppReceiver -ResourceId $logicAppSearch.ResourceId -CallbackUrl $logicAppSearch.Properties.accessEndpoint            
            if( $null -eq $logicAppReceiver) {
                $LASTEXITCODE = 5
                Throw "Error while creating receivable object"
            }
            Write-Host "Receivable object created: "$logicAppReceiver

            #Create Action Group
            $newActionGroup = Set-AzActionGroup -Name $actionGroupName -ResourceGroup $resourceGroupName -ShortName $actionGroupShortName -Receiver $logicAppReceiver 3> $null
            Write-Host "Set Action group command completed: $newActionGroup"                    
    }
}

<#
    .SYNOPSIS
        Create Azure Alert Rule
    .DESCRIPTION
        This is the function to create Azure Alert rule.
    .PARAMETER workspaceResourceId
        Specifies resourceId of the workspace.
    .PARAMETER workspaceLocation
        Specifies location of the workspace
    .PARAMETER query
        Specifies the query that will be executed against the workspace to trigger alert
    .PARAMETER queryType
        Specifies the query type
    .PARAMETER frequencyInMinutes
        Specifies how often the query will be executed
    .PARAMETER queryWindow
        Specifies the time window that the query will look back into
    .PARAMETER thresholdOperator
        Specifies the operator of the threshold of the count of query results that will trigger the alert
    .PARAMETER thresholdValue
        Specifies the threshold of the count of query results that will trigger the alert
    .PARAMETER alertSeverity
        Specifies the severity level of the alert
    .PARAMETER alertResourceGroup
        Specifies the resource group within which the alert will be created.
    .PARAMETER isEnabled
        Specifies whether the alert will be enabled/disabled.
    .PARAMETER alertDescription
        Specifies the description of the alert rule
    .PARAMETER alertName
        Specifies the name of the alert rule
#>
function Create-AlertRule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string] $workspaceResourceId,

        [Parameter(Mandatory=$True)]
        [string] $workspaceLocation,

        [Parameter(Mandatory=$true)]
        [string] $query,

        [Parameter(Mandatory=$True)]
        [string] $queryType,

        [Parameter(Mandatory=$true)]
        [int] $frequencyInMinutes,

        [Parameter(Mandatory=$True)]
        [int] $queryWindow,

        [Parameter(Mandatory=$true)]
        [string] $thresholdOperator,

        [Parameter(Mandatory=$True)]
        [int] $thresholdValue,

        [Parameter(Mandatory=$True)]
        [int] $alertSeverity,

        [Parameter(Mandatory=$true)]
        [string] $alertResourceGroup,

        [Parameter(Mandatory=$true)]
        [bool] $isEnabled,

        [Parameter(Mandatory=$true)]
        [string] $alertDescription,
        
        [Parameter(Mandatory=$true)]
        [string] $alertName
    )
    process {       
        Write-LogInfo "Inside Function Create-AlertRule"
        #Create Scheduled query rule source
        $source=New-AzScheduledQueryRuleSource -Query $query -DataSourceId $workspaceResourceId -QueryType $queryType
        Write-LogDebug "Created Scheduled query rule source: $source"

        #Create Scheduled query rule schedule
        $schedule=New-AzScheduledQueryRuleSchedule -FrequencyInMinutes $frequencyInMinutes -TimeWindowInMinutes $queryWindow
        Write-LogDebug "Created Scheduled query rule schedule: $schedule"

        #Create Scheduled query rule trigger condition
        $triggerCondition=New-AzScheduledQueryRuleTriggerCondition -ThresholdOperator $thresholdOperator -Threshold $thresholdValue
        Write-LogDebug "Created Scheduled query rule trigger condition: $triggerCondition"

        #Create Alerting Action
        $alertingAction=New-AzScheduledQueryRuleAlertingAction -Severity $alertSeverity -Trigger $triggerCondition
        Write-LogDebug "Created Scheduled query rule trigger condition: $alertingAction"

        #Create Alert
        $newAlert=New-AzScheduledQueryRule -ResourceGroupName $alertResourceGroup -Location $workspaceLocation -Action $alertingAction -Enabled $isEnabled -Description $alertDescription -Schedule $schedule -Source $source -Name $alertName 3> $null
        Write-LogDebug "Created Scheduled query rule: $newAlert"
        Write-LogInfo "Exiting Function Create-AlertRule"
    }
}