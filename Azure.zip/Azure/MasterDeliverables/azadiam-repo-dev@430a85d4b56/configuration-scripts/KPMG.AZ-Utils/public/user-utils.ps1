<#
    .SYNOPSIS
        Creates new guest invite in Azure AD.
    .DESCRIPTION
        Function New-AzureGuestInvite Creates new guest invite in Azure AD.
    .PARAMETER DisplayName
        Specifies the display name for the guest.
    .PARAMETER EmailAddress
        Specifies valid email address for the guest.
    .PARAMETER RedirectUrl
        Specifies redirect url for guests after accepting invitation.
    .PARAMETER SendEmail
        Specifies if function should send invitation email to guest.
    .PARAMETER CustomMessage
        Specifies custom message to be included in guest invitation.
    .PARAMETER AccessToken
        Specifies the bearer token for MS graph API calls.
    .OUTPUTS
        System.Object. Null on failure.
#>
Function New-AzureGuestInvite {
    [CmdletBinding()]
    [OutputType([System.Object])]

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]$DisplayName,

        [Parameter(Mandatory = $True, Position = 1)]
        [string]$EmailAddress,

        [Parameter(Mandatory = $True, Position = 2)]
        [string]$RedirectUrl,

        [Parameter(Mandatory = $False, Position = 3)]
        [bool]$SendEmail = $False,

        [Parameter(Mandatory = $False, Position = 4)]
        [string]$CustomMessage,

        [Parameter(Mandatory = $True, Position = 5)]
        [string]$AccessToken
    )

    Process {
        Write-LogInfo "Inside Function New-AzureGuestInvite"
        Write-LogDebug "Input DisplayName :: $DisplayName"
        Write-LogDebug "Input EmailAddress :: $EmailAddress"
        Write-LogDebug "Input RedirectUrl :: $RedirectUrl"
        Write-LogDebug "Input SendEmail :: $SendEmail"
        Write-LogDebug "Input CustomMessage :: $CustomMessage"
        Write-LogDebug "Input AccessToken :: $AccessToken"

        $invitationObj = $null
        $userFound = $False

        Try {
            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $headers.Add("Content-Type", "application/json")
            $headers.Add("Authorization", "Bearer $AccessToken")

            Write-LogDebug "Created request headers."
            #Check if invite exists
            Try {
                Write-LogDebug "Checking invitation/user already exists for $DisplayName"
                $getUserUrl = "https://graph.microsoft.com/beta/users?$" + "filter=mail eq '" + $EmailAddress + "'"
                $getUserResponse = Invoke-RestMethod $getUserUrl -Method 'GET' -Headers $headers
                $getUserResponse = $getUserResponse | ConvertTo-Json
                $userFound = $getUserResponse.Contains("id")
            }
            Catch [System.Exception] {
                Write-LogWarning "Get-User call failed for $DisplayName"
            }

            If ($userFound) {
                Write-LogDebug "Invitation/User already exists for $DisplayName"
                $invitationObj = $getUserResponse
            }
            Else {
                Write-LogInfo "Couldn't find user/invitation for $DisplayName . Creatig new guest invite."
                $body = @{
                    "invitedUserDisplayName"  = $DisplayName;
                    "invitedUserEmailAddress" = $EmailAddress;
                    "inviteRedirectUrl"       = $RedirectUrl;
                    "customizedMessageBody"   = $CustomMessage;
                    "sendInvitationMessage"   = $SendEmail
                } | ConvertTo-Json
                Write-LogDebug "Created request JSON body."
                Write-LogDebug "Calling invitation API for $DisplayName"

                $response = Invoke-RestMethod 'https://graph.microsoft.com/beta/invitations' -Method 'POST' -Headers $headers -Body $body
                $invitationObj = $response | ConvertTo-Json

                If (($null -ne $invitationObj) -and ($invitationObj.Contains("invitedUser"))) {
                    Write-LogDebug "Guest invitation created successfully for $DisplayName"
                }
                Else {
                    Write-LogErro "Guest invitation failed for $DisplayName"
                    $invitationObj = $null
                }

            }

        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Invitation failed for $DisplayName"            
            Write-LogError "Error Message :: $ErrorMessage"
            $invitationObj = $null
        }
        Write-LogInfo "Exiting Function New-AzureGuestInvite"
        return $invitationObj
    }
}

<#
.SYNOPSIS
    This function finds the user's Azure AD role
.DESCRIPTION
    This function finds the user Azure AD role
.PARAMETER key
    JSON array which has list of Azure AD roles which user should belong to
.PARAMETER userName
	User name whose role needs to be evaluated
.OUTPUTS
    int userRoleCount
#>

Function Find-UserAADRole {
    [CmdletBinding()]
    Param(
		[string[]]$key,
		[string[]]$userName
    )
    Process {	
	 try {
			Write-LogInfo "Entering function Find-UserRole"
			$userRole = $key
			$userRoleCount = 0
			Write-LogInfo "User Name :: $userName"
			foreach( $roleName in $userRole )
			{
				$roleNameVal = Get-AzureADDirectoryRole | Where-Object {$_.displayName -eq $roleName}
				$getRoleMember = Get-AzureADDirectoryRoleMember -ObjectId $roleNameVal.ObjectId | Where-Object {$_.UserPrincipalName -eq $userName}
				If($null -eq $getRoleMember){
					Write-LogError "User '$userName' is not assigned to role :: $roleName"
				} Else {
					$userRoleCount = $userRoleCount + 1
					Write-LogInfo "User '$userName' is assigned to role :: $roleName"
				}				
			} 
		} catch {
			$ErrorMessage = $_.Exception.Message
			$FailedItem = $_.Exception.ItemName
			Write-LogError $ErrorMessage
			Write-LogError $FailedItem
			break
		}
		Write-LogInfo "Exiting function Find-UserRole"
		return $userRoleCount
     }
  }
 
<#
.SYNOPSIS
    This function checks the AzureAD License
.DESCRIPTION
    This function checks the AzureAD License
.OUTPUTS
    string AADLicense
#>

Function Find-AADLicense {
    [CmdletBinding()]
    Param(
		
    )
    Process {	
	 try {
			Write-LogInfo "Entering function Find-AADLicense"
			$AADLicense = $null
			$AADLicenseArr = ( Get-AzureADSubscribedSku ).SkuPartNumber
			Write-LogDebug "Azure AD Licenses Array:: $AADLicenseArr"
			foreach( $license in $AADLicenseArr )
			{	
				Write-LogDebug "License :: $license"
			  	If (( $license -eq "EMSPREMIUM" ) -or ( $license -eq "SPE_E5" )){
					$AADLicense = "AAD_PREMIUM_P2"
					break
				} else {
					$AADLicense = "Invalid"
				}
			} 		
			Write-LogDebug "Azure AD License :: $AADLicense"			
		} catch {
			$ErrorMessage = $_.Exception.Message
			$FailedItem = $_.Exception.ItemName
			Write-LogError $ErrorMessage
			Write-LogError $FailedItem
			break
		}
		Write-LogInfo "Exiting function Find-AADLicense"
		return $AADLicense
     }
  }