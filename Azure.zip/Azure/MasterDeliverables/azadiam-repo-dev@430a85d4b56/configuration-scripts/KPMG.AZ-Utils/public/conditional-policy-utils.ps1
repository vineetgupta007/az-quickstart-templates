﻿<#
    .SYNOPSIS
        This function is used to run pre-check on "includeapplications" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values & get the application ID based on app name specified in configuration parameter
    .PARAMETER appKey
        Setting this parameter will get configuration key
    .PARAMETER appValue
        Setting this parameter will get configuration value
    .OUTPUTS
        Returns the valid "includeapplications" configuration key values
    .EXAMPLE
        Check-IncludeApplications
#>
Function Check-IncludeApplications {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$appKey,
        [Parameter(Mandatory = $true, Position = 1)] 
        [string[]]$appValue
    )
    Process {
        Write-LogInfo "Entering function Check-IncludeApplications"
        $temp = [System.Collections.ArrayList]@()
        $arr = $appValue -split '\|'

        foreach ($item in $arr) {                                                     
            # Check if "All" is the only value present in key config
            if ("All" -eq $item) {
                if ($arr.length -eq 1) {
                    $temp = $temp + $item
                }
                else {
                    Throw "Only 'All' value is allowed for $appKey`n"
                }
            }

            # Check if "None" is the only value present in key config
            elseif ("None" -eq $item) {
                if ($arr.length -eq 1) {
                    $temp = $temp + $item
                }
                else {
                    Throw "Only 'None' value is allowed for $appKey`n"
                }
            }

            # Get the App ID against the App Name in key config & throws error if it doesn't exist
            else {                      
                try {                      
                    $appID = (Get-AzureADApplication -Filter "DisplayName eq '$item'").AppId
                
                    if ($null -ne $appID) {
                        $temp = $temp + $appID
                    }
                    else {
                        Throw "Only Application Name/s are allowed for $appKey`n"
                    }            

                }
                catch {            
                    Throw "Only Application Name/s are allowed for $appKey`n" 
                }                                
            }

        }
        Write-LogInfo "Exiting function Check-IncludeApplications"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "excludeapplications" configuration key values
    .DESCRIPTION
        This function get the application ID based on app name specified in configuration parameter
    .PARAMETER appKey
        Setting this parameter will get configuration key
    .PARAMETER appValue
        Setting this parameter will get configuration value
    .OUTPUTS
        Returns the valid "excludeapplications" configuration key values
    .EXAMPLE
        Check-ExcludeApplications
#>
Function Check-ExcludeApplications {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$appKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$appValue
    )
    Process {
        Write-LogInfo "Entering function Check-ExcludeApplications"
        $temp = [System.Collections.ArrayList]@()
        $arr = $appValue -split '\|'

        foreach ($item in $arr) {
            if ($null -ne $item) {

                # Get the App ID against the App Name in key config & throws error if it doesn't exist
                try {                         
                    $appID = (Get-AzureADApplication -Filter "DisplayName eq '$item'").AppId
                
                    if ($null -ne $appID) {
                        $temp = $temp + $appID
                    }
                    else {
                        Throw "Only Application Name/s are allowed for $appKey`n"
                    }            
            
                }
                catch {
                    Throw "Only Application Name/s are allowed for $appKey`n" 
                }
            }                            
        }
        Write-LogInfo "Exiting function Check-ExcludeApplications"
        return $temp                                    
    }
}

    
<#
    .SYNOPSIS
        This function is used to run pre-check on "includeusers" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values & get the user ID based on user principal name(UPN) specified in configuration parameter
    .PARAMETER userKey
        Setting this parameter will get configuration key
    .PARAMETER userValue
        Setting this parameter will get configuration value
    .OUTPUTS
        Returns the valid "includeusers" configuration key values
    .EXAMPLE
        Check-IncludeUsers
#>
Function Check-IncludeUsers {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$userKey,
        [Parameter(Mandatory = $true, Position = 1)] 
        [string[]]$userValue
    )
    Process {
        Write-LogInfo "Entering function Check-IncludeUsers"
        $temp = [System.Collections.ArrayList]@()
        $arr = $userValue -split '\|'

        foreach ($item in $arr) {
            # Check if "All" is the only value present in key config                                             
            if ("All" -eq $item) {
                if ($arr.length -eq 1) {
                    $temp = $temp + $item
                }
                else {
                    Throw "Only 'All' value is allowed for $userKey`n"
                }
            }

            # Check if "None" is the only value present in key config
            elseif ("None" -eq $item) {
                if ($arr.length -eq 1) {
                    $temp = $temp + $item
                }
                else {
                    Throw "Only 'None' value is allowed for $userKey`n"
                }
            }

            # Check if "GuestsOrExternalUsers" value present in key config
            elseif ("GuestsOrExternalUsers" -eq $item) {
                $temp = $temp + $item
            }

            # Get the Object ID against the User Principal Name in key config & throws error if it doesn't exist
            else {
                try {                         
                    $userID = (Get-AzureADUser -ObjectId "$item").ObjectId
                    $temp = $temp + $userID                       
                }
                catch {
                    Throw "Only UserPrincipalNames(UPN) or 'GuestsOrExternalUsers' values are allowed for $userKey`n" 
                }                              
            }

        }
        Write-LogInfo "Exiting function Check-IncludeUsers"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "excludeusers" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values & get the user ID based on user principal name(UPN) specified in configuration parameter
    .PARAMETER userKey
        Setting this parameter will get configuration key
    .PARAMETER userValue
        Setting this parameter will get configuration value
    .OUTPUTS
        Returns the valid "excludeusers" configuration key values
    .EXAMPLE
        Check-ExcludeUsers
#>
Function Check-ExcludeUsers {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$userKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$userValue
    )
    Process {
        Write-LogInfo "Entering function Check-ExcludeUsers"
        $temp = [System.Collections.ArrayList]@()
        $arr = $userValue -split '\|'

        foreach ($item in $arr) {
            # Check if "GuestsOrExternalUsers" value present in key config
            if ("GuestsOrExternalUsers" -eq $item) {
                $temp = $temp + $item
            }

            else {
                if ($null -ne $item) {
                    # Get the Object ID against the User Principal Name in key config & throws error if it doesn't exist
                    try {                         
                        $userID = (Get-AzureADUser -ObjectId "$item").ObjectId
                        $temp = $temp + $userID  
                         
            
                    }
                    catch {
                        Throw "Only UserPrincipalNames(UPN) or 'GuestsOrExternalUsers' values are allowed for $userKey`n"
                    }
                }                            
            }

        }
        Write-LogInfo "Exiting function Check-ExcludeUsers"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "includeGroups/excludeGroups" configuration key values
    .DESCRIPTION
        This function gets the group ID based on the group name specified in configuration parameter
    .PARAMETER groupKey
        Setting this parameter will get configuration key
    .PARAMETER groupValue
        Setting this parameter will get configuration value
    .OUTPUTS
        Returns the valid "includeGroups/excludeGroups" configuration key values
    .EXAMPLE
        Get-GroupID
#>
Function Get-GroupID {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$groupKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$groupValue
    )
    Process {
        Write-LogInfo "Entering function Get-GroupID"
        $temp = [System.Collections.ArrayList]@()
        $arr = $groupValue -split '\|'

        foreach ($item in $arr) {
            if ($null -ne $item) {
                # Get the Object ID against the Group Name in key config & throws error if it doesn't exist
                try {                         
                    $GroupID = (Get-AzureADGroup -Filter "DisplayName eq '$item'").ObjectId
                
                    if ($null -ne $GroupID) {
                        $temp = $temp + $GroupID
                    }
                    else {
                        Throw "Only group names are allowed for $groupKey`n"
                    }            
            
                }
                catch {
                    Throw "Only group names are allowed for $groupKey`n"
                }
            }                            
        }
        Write-LogInfo "Exiting function Get-GroupID"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "includeRoles/excludeRoles" configuration key values
    .DESCRIPTION
        This function gets the Role ID based on role name specified in configuration parameter
    .PARAMETER roleKey
        Setting this parameter will get configuration key
    .PARAMETER roleValue
        Setting this parameter will get configuration value
    .OUTPUTS
        Returns the valid "includeRoles/excludeRoles" configuration key values
    .EXAMPLE
        Get-RoleID
#>
Function Get-RoleID {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$roleKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$roleValue
    )
    Process {
        Write-LogInfo "Entering function Get-RoleID"
        $temp = [System.Collections.ArrayList]@()
        $arr = $roleValue -split '\|'
    
        foreach ($item in $arr) {
            # Get the Object ID against the Role Name in key config & throws error if it doesn't exist
            try {                         
                $RoleID = (Get-AzureADDirectoryRoleTemplate | ? { $_.DisplayName -eq $item}).ObjectId
                
                if ($null -ne $RoleID) {
                    $temp = $temp + $RoleID
                }
                else {
                    Throw "Only role names are allowed for $roleKey`n"
                }            
            
            }
            catch {
                Throw "Only role names are allowed for $roleKey`n" 
            }                           
        }
        Write-LogInfo "Exiting function Get-RoleID"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "userRiskLevels" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER userRiskKey
        Setting this parameter will get configuration key
    .PARAMETER userRiskValue
        Setting this parameter will get configuration value
    .PARAMETER RiskLevels
        Setting this parameter will get allowed valid configuration values
    .OUTPUTS
        Returns the valid "userRiskLevels" configuration key values
    .EXAMPLE
        Check-UserRiskLevels
#>
Function Check-UserRiskLevels {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$userRiskKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$userRiskValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [String[]]$RiskLevels
    )
    Process {
        Write-LogInfo "Entering function Check-UserRiskLevels"
        $temp = [System.Collections.ArrayList]@()
        $arr = $userRiskValue -split '\|'

        foreach ($item in $arr) {                                                    
            if ($null -ne $item) {
                # Check if value present in RiskLevels Array
                if ($RiskLevels -contains "$item") {
                    $temp = $temp + $item                             
                }
        
                else {
                    Throw "Only '$RiskLevels' values are allowed for $userRiskKey`n"
                } 
            }                             

        }
        Write-LogInfo "Exiting function Check-UserRiskLevels"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "signInRiskLevels" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER signInKey
        Setting this parameter will get configuration key
    .PARAMETER signInValue
        Setting this parameter will get configuration value
    .PARAMETER SigninRiskLevels
        Setting this parameter will get allowed valid configuration values
    .OUTPUTS
        Returns the valid "signInRiskLevels" configuration key values
    .EXAMPLE
        Check-SignInRiskLevels
#>
Function Check-SignInRiskLevels {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$signInKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$signInValue,
        [Parameter(Mandatory = $true, Position = 2)]    
        [string[]]$SigninRiskLevels
    )
    Process {
        Write-LogInfo "Entering function Check-SignInRiskLevels"
        $temp = [System.Collections.ArrayList]@()
        $arr = $signInValue -split '\|'
        foreach ($item in $arr) {                                                    
            if ($null -ne $item) {
                # Check if value present in SigninRiskLevels Array
                if ($SigninRiskLevels -contains "$item") {
                    $temp = $temp + $item                             
                }
        
                else {
                    Throw "Only '$SigninRiskLevels' values are allowed for $signInKey`n"
                } 
            }                             
        }
        Write-LogInfo "Exiting function Check-SignInRiskLevels"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "clientAppTypes" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER clientAppKey
        Setting this parameter will get configuration key
    .PARAMETER clientAppValue
        Setting this parameter will get configuration value
    .PARAMETER clientAppTypes
        Setting this parameter will get allowed valid configuration values
    .OUTPUTS
        Returns the valid "clientAppTypes" configuration key values
    .EXAMPLE
        Check-ClientAppTypes
#>
Function Check-ClientAppTypes {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$clientAppKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$clientAppValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [string[]]$clientAppTypes
    )
    Process {
        Write-LogInfo "Entering function Check-ClientAppTypes"
        $temp = [System.Collections.ArrayList]@()
        $arr = $clientAppValue -split '\|'

        foreach ($item in $arr) {                                                    
            if ($null -ne $item) {

                if ($clientAppTypes -contains "$item") {
                    $temp = $temp + $item                             
                }
        
                else {
                    Throw "Only '$clientAppTypes' values are allowed for $clientAppKey`n"
                }
            }                                 

        }
        Write-LogInfo "Exiting function Check-ClientAppTypes"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "includePlatforms" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER platformKey
        Setting this parameter will get configuration key
    .PARAMETER platformValue
        Setting this parameter will get configuration value
    .PARAMETER Platforms
        Setting this parameter will get allowed valid configuration values
    .OUTPUTS
        Returns the valid "includePlatforms" configuration key values
    .EXAMPLE
        Check-IncludePlatforms
#>
Function Check-IncludePlatforms {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$platformKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$platformValue,
        [Parameter(Mandatory = $true, Position = 2)]    
        [string[]]$Platforms
    )
    Process {
        Write-LogInfo "Entering function Check-IncludePlatforms"
        $temp = [System.Collections.ArrayList]@()
        $arr = $platformValue -split '\|'

        foreach ($item in $arr) {                                                    
            # Check if "all" is the only value present in key config
            if ("all" -eq "$item") {
                if ($arr.length -eq 1) {
                    $temp = $temp + $item
                }
                else {
                    Throw "Only 'all' value is allowed for $platformKey`n"
                }
            }

            # Check if value present in Platforms Array
            elseif ($Platforms -contains "$item") {
                $temp = $temp + $item                             
            }
        
            else {
                Throw "Only '$Platforms' value are allowed for $platformKey`n"
            }                             

        }
        Write-LogInfo "Exiting function Check-IncludePlatforms"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "excludePlatforms" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER platformKey
        Setting this parameter will get configuration key
    .PARAMETER platformValue
        Setting this parameter will get configuration value
    .PARAMETER Platforms
        Setting this parameter will get allowed valid configuration values
    .OUTPUTS
        Returns the valid "excludePlatforms" configuration key values
    .EXAMPLE
        Check-ExcludePlatforms
#>
Function Check-ExcludePlatforms {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$platformKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$platformValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [string[]]$Platforms
    )
    Process {
        Write-LogInfo "Entering function Check-ExcludePlatforms"
        $temp = [System.Collections.ArrayList]@()
        $arr = $platformValue -split '\|'

        foreach ($item in $arr) {                                                   
            if ($null -ne $item) {
                # Check if value present in Platforms Array
                if ($Platforms -contains "$item") {
                    $temp = $temp + $item                             
                }
        
                else {
                    Throw "Only '$Platforms' values are allowed for $platformKey`n"
                } 
            }                             

        }
        Write-LogInfo "Exiting function Check-ExcludePlatforms"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "includeLocations" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter & gets the named location ID based on Location name
    .PARAMETER locationKey
        Setting this parameter will get configuration key
    .PARAMETER locationValue
        Setting this parameter will get configuration value
    .PARAMETER locAPIURL
        Setting this parameter will get named location API URL
    .PARAMETER tokenResponse
        Setting this parameter will get access token
    .OUTPUTS
        Returns the valid "includeLocations" configuration key values
    .EXAMPLE
        Check-IncludeLocations
#>
Function Check-IncludeLocations {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$locationKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$locationValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [string]$locAPIURL,
        [Parameter(Mandatory = $true, Position = 3)]
        [string]$tokenResponse
    )
    Process {
        Write-LogInfo "Entering function Check-IncludeLocations"
        $temp = [System.Collections.ArrayList]@() 
        $arr = $locationValue -split '\|'

        foreach ($item in $arr) {                                                    
            # Check if "All" is the only value present in key config
            if ("All" -eq "$item") {
                if ($arr.length -eq 1) {
                    $temp = $temp + $item
                }
                else {
                    Throw "Only 'All' value is allowed for $locationKey`n"
                }
            }

            # Check if value is present in Locations Array
            elseif ("AllTrusted" -contains "$item") {
                if ($arr.length -eq 1) {
                    $temp = $temp + $item
                }
                else {
                    Throw "Only 'AllTrusted' value is allowed for $locationKey`n"
                }                            
            }


            else {
                #Graph API to get named locations ID 
                $getLocUrl = "$locAPIURL '$item'"
                $getResp = Invoke-RestMethod -Headers @{Authorization = "Bearer $($tokenResponse)"} -Uri $getLocUrl -Method GET
                $LOC_ID = $getResp.value.id
                if ($null -ne $LOC_ID) {
                    $temp = $temp + $LOC_ID
                } 
                else {
                    Throw "Only named location values are allowed for $locationKey`n"
                }
            }                            

        }
        Write-LogInfo "Exiting function Check-IncludeLocations"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "excludeLocations" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter & gets the named location ID based on Location name
    .PARAMETER locationKey
        Setting this parameter will get configuration key
    .PARAMETER locationValue
        Setting this parameter will get configuration value
    .PARAMETER locAPIURL
        Setting this parameter will get named location API URL
    .PARAMETER tokenResponse
        Setting this parameter will get access token
    .OUTPUTS
        Returns the valid "excludeLocations" configuration key values
    .EXAMPLE
        Check-ExcludeLocations
#>
Function Check-ExcludeLocations {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$locationKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$locationValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [string]$locAPIURL,
        [Parameter(Mandatory = $true, Position = 3)]
        [string]$tokenResponse
    )
    Process {
        Write-LogInfo "Entering function Check-ExcludeLocations"
        $temp = [System.Collections.ArrayList]@()
        $arr = $locationValue -split '\|'

        foreach ($item in $arr) {                                                    
            if ($null -ne $item) {

                # Check if value is present in Locations Array
                if ("AllTrusted" -contains "$item") {
                    if ($arr.length -eq 1) {
                        $temp = $temp + $item
                    }
                    else {
                        Throw "Only 'AllTrusted' value is allowed for $locationKey`n"
                    }                            
                }

                else {
                    #Graph API to get named locations ID
            
                    $getLocUrl = "$locAPIURL '$item'"
                    $getResp = Invoke-RestMethod -Headers @{Authorization = "Bearer $($tokenResponse)"} -Uri $getLocUrl -Method GET
                    $LOC_ID = $getResp.value.id
                    if ($null -ne $LOC_ID) {
                        $temp = $temp + $LOC_ID
                    } 
                    else {
                        Throw "Only named location values are allowed for $locationKey`n"
                    }
                }      
            }                             
        }
        Write-LogInfo "Exiting function Check-ExcludeLocations"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "includeDeviceStates" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER deviceKey
        Setting this parameter will get configuration key
    .PARAMETER deviceValue
        Setting this parameter will get configuration value
    .PARAMETER DeviceStates
        Setting this parameter will get the list of allowed configuration values
    .OUTPUTS
        Returns the valid "includeDeviceStates" configuration key values
    .EXAMPLE
        Check-IncludeDeviceStates
#>
Function Check-IncludeDeviceStates {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$deviceKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$deviceValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [string[]]$DeviceStates
    )
    Process {
        Write-LogInfo "Entering function Check-IncludeDeviceStates"
        $temp = [System.Collections.ArrayList]@()
        $arr = $deviceValue -split '\|'

        foreach ($item in $arr) {                                                    
            # Check if "All" is the only value present in key config
            if ("All" -eq "$item") {
                if ($arr.length -eq 1) {
                    $temp = $temp + $item
                }
                else {
                    Throw "Only 'All' value is allowed for $deviceKey`n"
                }
            }
        
            else {
                Throw "Only '$DeviceStates' values are allowed for $deviceKey`n"
            }                             

        }
        Write-LogInfo "Exiting function Check-IncludeDeviceStates"
        return $temp                                    
    }
}

   
<#
    .SYNOPSIS
        This function is used to run pre-check on "excludeDeviceStates" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER deviceKey
        Setting this parameter will get configuration key
    .PARAMETER deviceValue
        Setting this parameter will get configuration value
    .PARAMETER DeviceStates
        Setting this parameter will get the list of allowed configuration values
    .OUTPUTS
        Returns the valid "excludeDeviceStates" configuration key values
    .EXAMPLE
        Check-ExcludeDeviceStates
#>
Function Check-ExcludeDeviceStates {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$deviceKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$deviceValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [string[]]$DeviceStates
    )
    Process {
        Write-LogInfo "Entering function Check-ExcludeDeviceStates"
        $temp = [System.Collections.ArrayList]@()
        $arr = $deviceValue -split '\|'

        foreach ($item in $arr) {                                                    
            if ($null -ne $item) {

                #Checks if value exist in DeviceStates Array
                if ($DeviceStates -contains "$item") {
                    $temp = $temp + $item                             
                }
        
                else {
                    Throw "Only '$DeviceStates' values are allowed for $deviceKey`n"
                } 
            }                             

        }
        Write-LogInfo "Exiting function Check-ExcludeDeviceStates"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "builtInControls" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER builtInKey
        Setting this parameter will get configuration key
    .PARAMETER builtInValue
        Setting this parameter will get configuration value
    .PARAMETER builtInControls
        Setting this parameter will get the list of allowed configuration values
    .OUTPUTS
        Returns the valid "builtInControls" configuration key values
    .EXAMPLE
        Check-BuiltInControls
#>
Function Check-BuiltInControls {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$builtInKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$builtInValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [String[]]$builtInControls
    )
    Process {
        Write-LogInfo "Entering function Check-BuiltInControls"
        $temp = [System.Collections.ArrayList]@()
        $arr = $builtInValue -split '\|'

        foreach ($item in $arr) {
            # Check if "block" value present in key config                                             
            if ("block" -eq $item) {
                if ($arr.length -eq 1) {
                    $temp = $temp + $item
                }
                else {
                    Throw "Only 'block' value is allowed for $builtInKey`n"
                }
            }

            # Check if value present in builtInControls Array
            elseif ($builtInControls -contains "$item") {
                $temp = $temp + $item                             
            }
        
            else {
                Throw "Only '$builtInControls' values are allowed for $builtInKey`n"
            }                              

        }
        Write-LogInfo "Exiting function Check-BuiltInControls"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "cloudAppSecurityType" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER cloudAppSeckey
        Setting this parameter will get configuration key
    .PARAMETER cloudAppSecValue
        Setting this parameter will get configuration value
    .PARAMETER cloudAppSecurityType
        Setting this parameter will get the list of allowed configuration values
    .OUTPUTS
        Returns the valid "cloudAppSecurityType" configuration key values
    .EXAMPLE
        Check-CloudAppSecurityType
#>
Function Check-CloudAppSecurityType {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$cloudAppSeckey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$cloudAppSecValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [string[]]$cloudAppSecurityType
    )
    Process {
        Write-LogInfo "Entering function Check-CloudAppSecurityType"
        $temp = [System.Collections.ArrayList]@()
        $arr = $cloudAppSecValue -split '\|'

        foreach ($item in $arr) {                                                    
            if ($null -ne $item) {

                #Checks if value exist in cloudAppSecurityType Array
                if ($cloudAppSecurityType -contains "$item") {
                    if ($arr.length -eq 1) {
                        $temp = $temp + $item
                    }
                    else {
                        Throw "Only '$cloudAppSecurityType' values are allowed for $cloudAppSeckey`n"
                    }                            
                }
        
                else {
                    Throw "Only '$cloudAppSecurityType' values are allowed for $cloudAppSeckey`n"
                } 
            }                             
        }
        Write-LogInfo "Exiting function Check-CloudAppSecurityType"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "SignInFrequencyType" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER signinFreqkey
        Setting this parameter will get configuration key
    .PARAMETER signinFreqValue
        Setting this parameter will get configuration value
    .PARAMETER signInFrequency
        Setting this parameter will get the list of allowed configuration values
    .OUTPUTS
        Returns the valid "SignInFrequencyType" configuration key values
    .EXAMPLE
        Check-SignInFrequencyType
#>
Function Check-SignInFrequencyType {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$signinFreqkey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$signinFreqValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [string[]]$signInFrequency
    )
    Process {
        Write-LogInfo "Entering function Check-SignInFrequencyType"
        $temp = [System.Collections.ArrayList]@()
        $arr = $signinFreqValue -split '\|'

        foreach ($item in $arr) {                                                    
            if ($null -ne $item) {

                #Checks if value exist in signInFrequency Array
                if ($signInFrequency -contains "$item") {
                    if ($arr.length -eq 1) {
                        $temp = $temp + $item
                    }
                    else {
                        Throw "Only '$signInFrequency' values are allowed for $signinFreqkey`n"
                    }                            
                }
        
                else {
                    Throw "Only '$signInFrequency' values are allowed for $signinFreqkey`n"
                } 
            }                             
        }
        Write-LogInfo "Exiting function Check-SignInFrequencyType"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on "includeUserActions" configuration key values
    .DESCRIPTION
        This function validates the valid allowed values specified in configuration parameter
    .PARAMETER userActionsKey
        Setting this parameter will get configuration key
    .PARAMETER userActionsValue
        Setting this parameter will get configuration value
    .PARAMETER includeUserActions
        Setting this parameter will get the list of allowed configuration values
    .OUTPUTS
        Returns the valid "includeUserActions" configuration key values
    .EXAMPLE
        Check-IncludeUserActions
#>
Function Check-IncludeUserActions {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$userActionsKey,
        [Parameter(Mandatory = $true, Position = 1)]
        [string[]]$userActionsValue,
        [Parameter(Mandatory = $true, Position = 2)]
        [string]$includeUserActions
    )
    Process {
        Write-LogInfo "Entering function Check-IncludeUserActions"
        $temp = [System.Collections.ArrayList]@()
        $arr = $userActionsValue -split '\|'

        foreach ($item in $arr) {                                                    
            if ($null -ne $item) {

                if ($includeUserActions -contains "$item") {
                    if ($arr.length -eq 1) {
                        $temp = $temp + $item
                    }
                    else {
                        Throw "Only '$includeUserActions' value is allowed for $userActionsKey`n"
                    }                            
                }
        
                else {
                    Throw "Only '$includeUserActions' value is allowed for $userActionsKey`n"
                } 
            }                             
        }
        Write-LogInfo "Exiting function Check-IncludeUserActions"
        return $temp                                    
    }
}


<#
    .SYNOPSIS
        This function is used to run pre-check on mandatory configuration key values
    .DESCRIPTION
        This function validates if mandatory key values are present
    .PARAMETER result
        Setting this parameter will get mandatory keys
    .PARAMETER mandatory
        Setting this parameter will get the list of allowed configuration values
    .OUTPUTS
        Returns the collection of missing mandatory key value errors
    .EXAMPLE
        Check-MandatoryKeyValue
#>
Function Check-MandatoryKeyValue {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $true, Position = 0)]
        [Hashtable]$result,
        [Parameter(Mandatory = $true, Position = 1)]
        [String[]] $mandatory
    )
    Process {	
        Write-LogInfo "Entering function Check-MandatoryKeyValue"
        $errorMandatoryMsg = $null
        foreach ($i in $mandatory) { 
            if (!$result.Item($i)) {
                $errorMandatoryMsg += "`n$i value is mandatory`n"
            }
        }

        if (!$result.Item('includeApplications') -and !$result.Item('includeUserActions')) {
            #To check if mandatory application key value is empty
            $errorMandatoryMsg += "Mandatory App key 'includeApplications' or 'includeUserActions' value is missing`n"
        }

        if ($result.Item('includeApplications') -and $result.Item('includeUserActions')) {
            #Checks Only one mandatory app key value is allowed
            $errorMandatoryMsg += "Applications condition cannot include both 'includeApplications' and 'includeUserActions'`n"
        }
        Write-LogInfo "Exiting function Check-MandatoryKeyValue"
        return $errorMandatoryMsg
    }
}


<#
    .SYNOPSIS
        This function is used to create a json template for conditional access policy 
    .DESCRIPTION
        This function invokes configuration key validation functions & create a json template for conditional access policy 
    .PARAMETER result
        Setting this parameter will get configuration keys
    .PARAMETER exportPathTemplate
        Setting this parameter will get the conditional policy template
    .PARAMETER param
        Setting this parameter will get the list of allowed configuration key values
    .PARAMETER locAPIURL
        Setting this parameter will get named location API URL
    .PARAMETER tokenResponse
        Setting this parameter will get access token
    .OUTPUTS
        Returns the policy data template
    .EXAMPLE
        Create-PolicyTemplate
#>
Function Create-PolicyTemplate {
    [CmdletBinding()]
    [OutputType([string])]
    Param([Hashtable]$result,
        [String] $exportPathTemplate,
        [PSCustomObject] $param,
        [string]$locAPIURL,
        [string]$tokenResponse
    )
    Process {	
        Write-LogInfo "Entering function Create-PolicyTemplate"

        $builtInControls = $param.builtInControls
        $RiskLevels = $param.RiskLevels
        $SigninRiskLevels = $param.SigninRiskLevels
        $clientAppTypes = $param.clientAppTypes
        $Platforms = $param.Platforms
        $DeviceStates = $param.DeviceStates
        $signInFrequency = $param.signInFrequency
        $cloudAppSecurityType = $param.cloudAppSecurityType
        $includeUserActions = $param.includeUserActions
        $isBulkLoad = $param.isBulkLoad

        $errorMsg = $null
        # Get Policy Template
        $data_template = Get-Content -Path $exportPathTemplate

        # Iterate through "conditional-policy" config type keys
        foreach ($key in  $result.Keys) {  
            $keyName = "%%$key%%"
            if ($key -eq "displayName" -or $key -eq "state") {
                $keyvalue = $result.Item($key) | ConvertTo-Json
    
            } 
            else { 
                if ($key -eq "includeApplications") {
                    #Invokes Check-IncludeApplications Function for config key precheck
                    try {
                        if ($result.Item($key)) {
                            $precheck = Check-IncludeApplications -appKey $key -appValue $result.Item($key)
                            $keyValue = ConvertTo-Json @($precheck)  
                        }
                        else {
                            $keyValue = '[]'
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    }             
                }

                elseif ($key -eq "excludeApplications") {
                    #Invokes Check-ExcludeApplications Function for config key precheck
                    try {
                        if ($result.Item($key)) {
                            $precheck = Check-ExcludeApplications -appKey $key -appValue $result.Item($key)
                            $keyValue = ConvertTo-Json @($precheck)  
                        }
                        else {
                            $keyValue = '[]'
                        } 
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    } 
                }

                elseif ($key -eq "includeUsers") {
                    try {
                        #Invokes Check-IncludeUsers Function for config key precheck  & to get the UPN ID
                        if ($result.Item($key)) {
                            $precheck = Check-IncludeUsers -userKey $key -userValue $result.Item($key)
                            $keyValue = ConvertTo-Json @($precheck) 
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    }                                                 
                }

                elseif ($key -eq "excludeUsers") {
                    try {
                        #Invokes Check-ExcludeUsers Function for config key precheck & to get the UPN ID
                        if ($result.Item($key)) {
                            $precheck = Check-ExcludeUsers -userKey $key -userValue $result.Item($key)
                            $keyValue = ConvertTo-Json @($precheck)  
                        }
                        else {
                            $keyValue = '[]'
                        }   
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    }                                                  
                }

                elseif ($key -eq "includeGroups") {
                    try {
                        #Invokes Get-GroupID Function for config key precheck & to get the GroupID
                        if ($result.Item($key)) {
                            $precheck = Get-GroupID -groupKey $key -groupValue $result.Item($key)
                            $keyValue = ConvertTo-Json @($precheck)  
                        }
                        else {
                            $keyValue = '[]'
                        } 
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    }                                                  
                }

                elseif ($key -eq "excludeGroups") {
                    try {
                        #Invokes Get-GroupID Function for config key precheck & to get the GroupID
                        if ($result.Item($key)) {
                            $precheck = Get-GroupID -groupKey $key -groupValue $result.Item($key)
                            $keyValue = ConvertTo-Json @($precheck)  
                        }
                        else {
                            $keyValue = '[]'
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    }                                                   
                }

                elseif ($key -eq "includeRoles") {
                    try {
                        #Invokes Get-RoleID Function for config key precheck & to get the RoleID
                        if ($result.Item($key)) {
                            $precheck = Get-RoleID -roleKey $key -roleValue $result.Item($key)
                            $keyValue = ConvertTo-Json @($precheck)  
                        }
                        else {
                            $keyValue = '[]'
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    }                                                  
                }

                elseif ($key -eq "excludeRoles") {
                    try {
                        #Invokes Get-RoleID Function for config key precheck & to get the RoleID
                        if ($result.Item($key)) {
                            $precheck = Get-RoleID -roleKey $key -roleValue $result.Item($key)
                            $keyValue = ConvertTo-Json @($precheck)  
                        }
                        else {
                            $keyValue = '[]'
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    } 
                                              
                }

                elseif ($key -eq "builtInControls") {
                    try {
                        #Invokes Check-BuiltInControls Function for config key precheck
                        if ($result.Item($key)) {
                            $precheck = Check-BuiltInControls -builtInKey $key -builtInValue $result.Item($key) -builtInControls $builtInControls 
                            $keyValue = ConvertTo-Json @($precheck)
                        }
                        else {
                            $keyValue = ''
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    } 
                }

                elseif ($key -eq "userRiskLevels") {
                    try {
                        #Invokes Check-UserRiskLevels Function for config key precheck
                        if ($result.Item($key)) {
                            $precheck = Check-UserRiskLevels -userRiskKey $key -userRiskValue $result.Item($key) -RiskLevels $RiskLevels
                            $keyValue = ConvertTo-Json @($precheck)  
                        }
                        else {
                            $keyValue = '[]'
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    } 

                }

                elseif ($key -eq "signInRiskLevels") {
                    try {
                        #Invokes Check-SignInRiskLevels Function for config key precheck
                        if ($result.Item($key)) {
                            $precheck = Check-SignInRiskLevels -signInKey $key -signInValue $result.Item($key) -SigninRiskLevels $SigninRiskLevels
                            $keyValue = ConvertTo-Json @($precheck)  
                        }
                        else {
                            $keyValue = '[]'
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    } 
                }

                elseif ($key -eq "clientAppTypes") {
                    try {
                        #Invokes Check-ClientAppTypes Function for config key precheck
                        if ($result.Item($key)) {
                            $precheck = Check-ClientAppTypes -clientAppKey $key -clientAppValue $result.Item($key) -clientAppTypes $clientAppTypes
                            $keyValue = ConvertTo-Json @($precheck)
                        }
                        else {
                            $keyValue = '[]'
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    } 
                }

                elseif ($key -eq "locations") {
                    try {
                        $val = $result.Item($key)
                        $keyLocation = $val -split ";"
                        $includeLocations = $keyLocation[0]
                        $excludeLocations = $keyLocation[1]

                        # If excludelocations & includelocations both are empty
                        if ((!$includeLocations -and !$excludeLocations) -or (!$includeLocations)) {
                            $keyValue = "null"
                        }

                        # If excludelocations is empty
                        elseif (!$excludeLocations) {                       
                            #Invokes Check-IncludeLocations Function for config key precheck & to get the named Locations ID                     
                            $precheck = Check-IncludeLocations -locationKey $key -locationValue $includeLocations -locAPIURL $locAPIURL -tokenResponse $tokenResponse
                            $inc = ConvertTo-Json @($precheck)                          
                            #Creating a JSON String
                            $keyValue = "{`"includeLocations`": $inc,`"excludeLocations`":[]}"   
                                         
                        }

                        # If both excludelocations & includelocations value exist
                        else {
                            #Invokes Check-IncludeLocations Function for config key precheck & to get the named Locations ID
                            $precheck = Check-IncludeLocations -locationKey $key -locationValue $includeLocations -locAPIURL $locAPIURL -tokenResponse $tokenResponse
                            $inc = ConvertTo-Json @($precheck)

                            #Invokes Check-ExcludeLocations Function for config key precheck & to get the named Locations ID
                            $precheck = Check-ExcludeLocations -locationKey $key -locationValue $excludeLocations -locAPIURL $locAPIURL -tokenResponse $tokenResponse
                            $exc = ConvertTo-Json @($precheck)
                            $keyValue = "{`"includeLocations`": $inc,`"excludeLocations`": $exc}"                      
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    }  
                }

                elseif ($key -eq "platforms") {

                    try {
                        $val = $result.Item($key)
                        $keyPlatform = $val -split ";"
                        $includePlatforms = $keyPlatform[0]
                        $excludePlatforms = $keyPlatform[1]

                        # If includePlatforms & excludePlatforms both are empty
                        if ((!$includePlatforms -and !$excludePlatforms) -or (!$includePlatforms)) {
                            $keyValue = "null"
                        }

                        # If excludePlatforms is empty
                        elseif (!$excludePlatforms) {   
                            #Invokes IncludePlatforms Function for config key precheck                    
                            $precheck = Check-IncludePlatforms -platformKey $key -platformValue $includePlatforms -Platforms $Platforms
                            $inc = ConvertTo-Json @($precheck)                          
                            #Creating a JSON String
                            $keyValue = "{`"includePlatforms`": $inc,`"excludePlatforms`":[]}"   
                                         
                        }

                        # If both includePlatforms & excludePlatforms value exist
                        else {
                            #Invokes IncludePlatforms Function for config key precheck
                            $precheck = Check-IncludePlatforms -platformKey $key -platformValue $includePlatforms -Platforms $Platforms
                            $inc = ConvertTo-Json @($precheck)

                            #Invokes ExcludePlatforms Function for config key precheck
                            $precheck = Check-ExcludePlatforms -platformKey $key -platformValue $excludePlatforms -Platforms $Platforms
                            $exc = ConvertTo-Json @($precheck)
                            $keyValue = "{`"includePlatforms`": $inc,`"excludePlatforms`": $exc}"                      
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    }
                }
                               

                elseif ($key -eq "devices") {
                    try {
                        $val = $result.Item($key)
                        $keyDevices = $val -split ";"
                        $includeDeviceStates = $keyDevices[0]
                        $excludeDeviceStates = $keyDevices[1]

                        # If includeDeviceStates & excludeDeviceStates both are empty
                        if ((!$includeDeviceStates -and !$excludeDeviceStates) -or (!$includeDeviceStates)) {
                            $keyValue = "null"
                        }

                        # If excludeDeviceStates is empty
                        elseif (!$excludeDeviceStates) {   
                            #Invokes Check-IncludeDeviceStates Function for config key precheck & to get the named Locations ID                     
                            $precheck = Check-IncludeDeviceStates -deviceKey $key -deviceValue $includeDeviceStates -DeviceStates $DeviceStates
                            $inc = ConvertTo-Json @($precheck)                          
                            #Creating a JSON String
                            $keyValue = "{`"includeDeviceStates`": $inc,`"excludeDeviceStates`":[]}"   
                                         
                        }

                        # If both includeDeviceStates & excludeDeviceStates value exist
                        else {
                            #Invokes Check-IncludeDeviceStates function for config key precheck
                            $precheck = Check-IncludeDeviceStates -deviceKey $key -deviceValue $includeDeviceStates -DeviceStates $DeviceStates
                            $inc = ConvertTo-Json @($precheck)

                            #Invokes ExcludeDeviceStates Function for config key precheck
                            $precheck = Check-ExcludeDeviceStates -deviceKey $key -deviceValue $excludeDeviceStates -DeviceStates $DeviceStates
                            $exc = ConvertTo-Json @($precheck)
                            $keyValue = "{`"includeDeviceStates`": $inc,`"excludeDeviceStates`": $exc}"                      
                        }                             
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    } 
                }
                
                elseif ($key -eq "sessionControls") {
                    
                    try {
                        $val = $result.Item($key)
                        $keySessionControls = $val -split ";"
                        $cloudAppSecurityType = $keySessionControls[0]
                        $signInFrequencyValue = $keySessionControls[1]
                        $signInFrequencyType = $keySessionControls[2]

                        # If cloudAppSecurityType & signInFrequency type both are empty
                        if (!$cloudAppSecurityType -and !($signInFrequencyType -and $signInFrequencyValue)) {
                            $keyValue = "null"
                        }

                        # If signInFrequency type or signInFrequency Value is empty
                        elseif (!$signInFrequencyType -or !$signInFrequencyValue) {
                            #Invokes CloudAppSecurityType function for config key precheck
                            $precheck = Check-CloudAppSecurityType -cloudAppSeckey $key -cloudAppSecValue $cloudAppSecurityType -cloudAppSecurityType $cloudAppSecurityType                           
                            #Creating a JSON String
                            $keyValue = "{`"cloudAppSecurity`": {`"cloudAppSecurityType`": `"$precheck`",`"isEnabled`": true},`"signInFrequency`":null}"                    
                        }

                        # If cloudAppSecurityType is empty
                        elseif (!$cloudAppSecurityType) {
                            #Invokes SignInFrequencyType function for config key precheck
                            $precheck = Check-SignInFrequencyType -signinFreqkey $key -signinFreqValue $signInFrequencyType -signInFrequency $signInFrequency                                                                                                                    
                            #Creating a JSON String
                            $keyValue = "{`"cloudAppSecurity`": null,`"signInFrequency`":{`"value`": $signInFrequencyValue,`"type`": `"$precheck`",`"isEnabled`": true}}"
                        }    
                
                        else {
                            #Invokes CloudAppSecurityType function for config key precheck
                            $precheckcloudappsec = Check-CloudAppSecurityType -cloudAppSeckey $key -cloudAppSecValue $cloudAppSecurityType -cloudAppSecurityType $cloudAppSecurityType                                                                                       

                            #Invokes SignInFrequencyType function for config key precheck
                            $prechecksigninFreq = Check-SignInFrequencyType -signinFreqkey $key -signinFreqValue $signInFrequencyType -signInFrequency $signInFrequency 
                    
                            $keyValue = "{`"cloudAppSecurity`": {`"cloudAppSecurityType`": `"$precheckcloudappsec`",`"isEnabled`": true},`"signInFrequency`":{`"value`": $signInFrequencyValue,`"type`": `"$prechecksigninFreq`",`"isEnabled`": true}}"                                                                                          
                        } 
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    }              
                
                }

                elseif ($key -eq "includeUserActions") {
                    try {
                        #Invokes IncludeUserActions function for config key precheck
                        if ($result.Item($key)) {
                            $precheck = Check-IncludeUserActions -userActionsKey $key -userActionsValue $result.Item($key) -includeUserActions $includeUserActions
                            $keyValue = ConvertTo-Json @($precheck)
                        }
                        else {
                            $keyValue = '[]'
                        }
                    }
                    catch [System.Exception] {
                        $errorMsg += $_.Exception.Message
                    } 
                }

            } 
                      
            #Replaces values in the Policy Template   
            $data_template = $data_template -replace $keyName, $keyValue 
                     
           
        }
     
        if ($null -ne $errorMsg) {
            throw $errorMsg
        }
        Write-LogInfo "Exiting function Create-PolicyTemplate"
        return $data_template
         
    }
  
}  