<#
    .SYNOPSIS
        Create Enterprise application and application roles in Azure AD
    .DESCRIPTION
        This is the function to create Enterprise application and application roles in Azure AD.
    .PARAMETER principalId
        Object id of the service principal
    .PARAMETER permissionsList
        String array containing display name of permissions that need to be added to the service principal    
#>
function Add-ServicePrincipal-GraphAPIPermissions {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string] $principalId,

        [Parameter(Mandatory=$True)]
        [array] $permissionsList
    )
    process {
        Write-LogInfo "Inside Function Add-ServicePrincipal-GraphAPIPermissions"

        # Initialize graph object id (ootb value)
        $graphAppId="00000003-0000-0000-c000-000000000000"

        #Get graph object
        $graph=Get-AzureADServicePrincipal -Filter "AppId eq '$graphAppId'"
        
        foreach($i in 0..($permissionsList.Count-1)) {
            $increment_count=($i+1)
            Write-LogDebug "Graph permissions Iteration:$increment_count"
            $log_var=$permissionsList[$i]
            Write-LogDebug "Current permission name: $log_var"            

            $currentPermissionObj=$graph.AppRoles | where Value -Like $permissionsList[$i] | Select-Object -First 1
            if( $null -eq $currentPermissionObj ) {
                $LASTEXITCODE = 5
        	    Throw "Could not retrieve object for graph API permission: $permissionsList[$i]"
            }

            #Add permission
            New-AzureADServiceAppRoleAssignment -Id $currentPermissionObj.Id -ObjectId $principalId -PrincipalId $principalId -ResourceId $graph.ObjectId
            Write-LogDebug "Permission assigned successfully"
        }
        Write-LogInfo "Exiting Function Add-ServicePrincipal-GraphAPIPermissions"
    }
}