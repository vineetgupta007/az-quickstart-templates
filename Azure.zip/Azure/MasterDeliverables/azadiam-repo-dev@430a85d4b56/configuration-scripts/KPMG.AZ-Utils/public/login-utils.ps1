Function Connection-MSOL{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $LoginProps
    )
    Process{
        Write-LogInfo "Inside Function Connection-MSOL"
        try{
            $LPwd=Convert-PasswordToSecureString -Password $LoginProps.password
            $Credential = Get-PSCredentials -Username $LoginProps.username -Password $LPwd
            Connect-MsolService -Credential $Credential
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Connection-MSOL"
    }
}

Function Get-ConnectionMSOL{
    
    [CmdletBinding()]
    [OutputType([bool])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $LoginProps
    )
    Process{
        Write-LogInfo "Inside Function Get-ConnectionMSOL"
        $isConnectionSuccess=$false
        $LoginConnProps = $null
        try{
            #check for connection type
            $ConnType = $LoginProps.'connection-type'
            If($ConnType -eq 'user-credential'){
                # Connect to Azure AD
                $LoginConnProps=$LoginProps.'az-ad-user-login'
                If($null -eq $LoginConnProps){
                    Throw "Login configuration is not configured in JSON properties file"
                }
                Connection-MSOL -LoginProps $LoginConnProps
                $isConnectionSuccess=$true
            } Else {
                Write-LogInfo "Invalid connection type"
            }
         }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Get-ConnectionMSOL"
         return $isConnectionSuccess
    }
}


function Generate-AppToken {

    [CmdletBinding()]
    [OutputType([string])]
    param(
       [Parameter(Mandatory=$true,Position=0)]
       [string]$ClientSecret,

       [Parameter(Mandatory=$true,Position=1)]
       [string]$ClientID,

       [Parameter(Mandatory=$true,Position=2)]
       [string]$TenantID,

       [Parameter(Mandatory=$false,Position=3)]
       [string]$Scope="https%3A//graph.microsoft.com/.default"
       )
       process {
            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $headers.Add("Content-Type", "application/x-www-form-urlencoded")
            $authUrl = "https://login.microsoftonline.com";
            $body = "grant_type=client_credentials&client_id=$ClientID&client_secret=$ClientSecret&scope=$Scope"
            #Write-LogDebug "Body :: $body"
            try {
                $response = Invoke-RestMethod "$authUrl/$TenantID/oauth2/v2.0/token" -Method 'POST' -Headers $headers -Body $body

                $accessToken=$response.access_token
                return $accessToken
            
            } catch {
                Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
                Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
                Write-Host "Response:" $_.Exception.Response
                Write-Host "Response:" $_.
                return $null
       }                
       }
}

function Generate-UserToken {

    [CmdletBinding()]
    [OutputType([string])]
    param(
       [Parameter(Mandatory=$true)]
       [string]
       $ClientSecret,

       [Parameter(Mandatory=$true)]
       [string]
       $ClientID,

       [Parameter(Mandatory=$true)]
       [string]
       $TenantID,

       [Parameter(Mandatory=$true)]
       [string]
       $Username,

       [Parameter(Mandatory=$true)]
       [string]
       $Password,

       [Parameter(Mandatory=$true)]
       [string]
       $Scope

       )
       process {

            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $headers.Add("Content-Type", "application/x-www-form-urlencoded")
            $authUrl = "https://login.microsoftonline.com";
            $body = "grant_type=password&client_id=$ClientID&client_secret=$ClientSecret&scope=$Scope&userName=$Username&password=$Password"
            try {
                $response = Invoke-RestMethod "$authUrl/$TenantId/oauth2/v2.0/token" -Method 'POST' -Headers $headers -Body $body

                $accessToken=$response.access_token
                return $accessToken
            
            } catch {
                Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
                Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
                Write-Host "Response:" $_.Exception.Response
                Write-Host "Response:" $_.
                return $null

       }
       }
}

<#
    .SYNOPSIS
        This function connects an authenticated account to use for Azure Active Directory cmdlet requests
    .DESCRIPTION
        This function connects an authenticated account to use for Azure Active Directory cmdlet requests
    .PARAMETER Username
        Username of the user 
    .PARAMETER Password
        Cleartext password of the user
#>
Function Connection-AzureAD{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $LoginProps
    )
    Process{
        Write-LogInfo "Inside Function Connection-AzureAD"
        try{
            # Connect to Azure AD
            $LPwd=Convert-PasswordToSecureString -Password $LoginProps.password
            $Credential = Get-PSCredentials -Username $LoginProps.username -Password $LPwd
            Connect-AzureAD -Credential $Credential
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Connection-AzureAD"
    }
}

<#
    .SYNOPSIS
        This function connects to Azure AD with the connection-type selected
    .DESCRIPTION
        This function connects to Azure AD with the connection-type selected
    .PARAMETER LoginProps
        AZ-Login PSCustomObject 
#>
Function Get-Connection{
    [CmdletBinding()]
    [OutputType([bool])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $LoginProps
    )
    Process{
        Write-LogInfo "Inside Function Get-Connection"
        $isConnectionSuccess=$false
        $LoginConnProps = $null
        try{
            #check for connection type
            $ConnType = $LoginProps.'connection-type'
            If($ConnType -eq 'user-credential'){
                # Connect to Azure AD
                $LoginConnProps=$LoginProps.'az-ad-user-login'
                If($null -eq $LoginConnProps){
                    Throw "Login configuration is not configured in JSON properties file"
                }
                Connection-AzureAD -LoginProps $LoginConnProps
                $isConnectionSuccess=$true
            } Else {
                Write-LogInfo "Invalid connection type"
            }
         }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Get-Connection"
         return $isConnectionSuccess
    }
}

<#
    .SYNOPSIS
        This function connects an authenticated account to use for Azure cmdlet requests
    .DESCRIPTION
        This function connects an authenticated account to use for Azure cmdlet requests
    .PARAMETER Username
        Username of the user 
    .PARAMETER Password
        Cleartext password of the user
#>
Function Connection-AZAccount{
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $LoginProps
    )
    Process{
        Write-LogInfo "Inside Function Connection-AZAccount"
        try{
            ## -- Connect to Azure
            $LPwd=Convert-PasswordToSecureString -Password $LoginProps.password
            $Credential = Get-PSCredentials -Username $LoginProps.username -Password $LPwd
            Connect-AzAccount -Credential $Credential
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Connection-AZAccount"
    }
}

<#
    .SYNOPSIS
        This function connects an authenticated account to use for Azure Active Directory cmdlet requests
    .DESCRIPTION
        This function connects an authenticated account to use for Azure Active Directory cmdlet requests
    .PARAMETER Username
        Username of the user 
    .PARAMETER Password
        Cleartext password of the user
#>
Function Connection-AZAccount-SPN {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $LoginProps
    )
    Process{
        Write-LogInfo "Inside Function Connection-AZAccount-SPN"
        try{
            ## -- Connect to Azure
            $sp = Get-AzADServicePrincipal -DisplayName $LoginProps.spn
            $userName = $sp.ApplicationId
            $LPwd=Convert-PasswordToSecureString -Password $LoginProps.password
            $Credential = Get-PSCredentials -Username $userName -Password $LPwd
            Connect-AzAccount -ServicePrincipal -Credential $Credential -Tenant $LoginProps.tenantId
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Connection-AZAccount-SPN"
    }
}

<#
    .SYNOPSIS
        This function connects to Azure with the connection-type selected
    .DESCRIPTION
        This function connects to Azure with the connection-type selected
    .PARAMETER LoginProps
        AZ-Login PSCustomObject 
#>
Function Get-AZConnection{
    [CmdletBinding()]
    [OutputType([bool])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $LoginProps
    )
    Process{
        Write-LogInfo "Inside Function Get-AZConnection"
        $isConnectionSuccess=$false
        $LoginConnProps = $null
        try{
            ## -- check for connection type
            $ConnType = $LoginProps.'connection-type'
            If( $ConnType -eq 'user-credential' ){
                ## -- Connect to Azure
                $LoginConnProps=$LoginProps.'az-ad-user-login'
                If( $null -eq $LoginConnProps ){
                    Throw "Login configuration is not configured in JSON properties file"
                }
                Connection-AZAccount -LoginProps $LoginConnProps
                $isConnectionSuccess=$true
            } ElseIf ( $ConnType -eq 'spn-login' ) {
				# Connect to Azure using SPN
                $LoginConnProps=$LoginProps.'az-spn-login'
                If($null -eq $LoginConnProps){
                    Throw "Login configuration is not configured in JSON properties file"
                }
                Connection-AZAccount-SPN -LoginProps $LoginConnProps
                $isConnectionSuccess=$true
			} Else{
                Write-LogInfo "Invalid connection type"
            }
         }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Get-AZConnection"
         return $isConnectionSuccess
    }
}

<#
    .SYNOPSIS
        This function returns the username used to connect to  Azure AD
    .DESCRIPTION
        This function returns the username used to connect to  Azure AD
    .PARAMETER LoginProps
        AZ-Login PSCustomObject 
#>
Function Get-Username {
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $LoginProps
    )
    Process{
        Write-LogInfo "Inside Function Get-Username"
        $UserName = $false
        $LoginConnProps = $null
        try{
            #check for connection type
            $ConnType = $LoginProps.'connection-type'
            If($ConnType -eq 'user-credential'){
                # Connect to Azure AD
                $LoginConnProps=$LoginProps.'az-ad-user-login'
                If($null -eq $LoginConnProps){
                    Throw "Login configuration is not configured in JSON properties file"
                }
                $UserName = $LoginConnProps.username
               
            } Else {
                # Connect to Azure using SPN
                $LoginConnProps=$LoginProps.'az-spn-login'
                If($null -eq $LoginConnProps){
                    Throw "Login configuration is not configured in JSON properties file"
                }
                $UserName = $LoginConnProps.username
            }
         }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Get-Username"
         return $UserName
    }
}

 <#
    .SYNOPSIS
        This function gets the access token for the scope
    .DESCRIPTION
        This function gets the access token for the scope
    .PARAMETER TokenProps
        Token-Configuration PSCustomObject  
#>
Function Get-Token{
    [CmdletBinding()]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $TokenProps
    )
    Process{
        Write-LogInfo "Inside Function Get-Token"
        $accessToken=$null

        try{
            #check for connection type
            $TokenType = $TokenProps.'token-type'
            if($TokenType -eq 'app-token'){
                $AppTokenProps=$TokenProps.'app-token'
                If($null -eq $AppTokenProps){
                    Throw "Token configuration is not configured in JSON properties file"
                }
                $accessToken = Generate-AppToken -ClientSecret $AppTokenProps.'clientSecret' -ClientID $AppTokenProps.'clientId' -TenantID $AppTokenProps.'tenantId' -Scope $AppTokenProps.'scope'
            }elseif ($TokenType -eq 'user-token') {
                $UserTokenProps=$TokenProps.'user-token'
                If($null -eq $UserTokenProps){
                    Throw "Token configuration is not configured in JSON properties file"
                }
                $accessToken = Generate-UserToken -ClientSecret $UserTokenProps.'clientSecret' -ClientID $UserTokenProps.'clientId' -TenantID $UserTokenProps.'tenantId' -Username $UserTokenProps.'username' -Password $UserTokenProps.'password' -Scope $UserTokenProps.'scope'
             }else{
                Write-LogInfo "Invalid token type"
            }
         }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Get-Token"
         return $accessToken
    }
}
