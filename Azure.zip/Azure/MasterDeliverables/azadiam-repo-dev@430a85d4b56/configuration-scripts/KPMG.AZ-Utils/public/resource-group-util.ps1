<#
    .SYNOPSIS
        This Utility contains functions related to resource group
    .DESCRIPTION
        This Utility contains functions related to resource group
#>

<#
    .SYNOPSIS
        This function is used for checking if resource group exists, if not then create a new one
    .DESCRIPTION
        This function is used for checking if resource group exists, if not then create a new one.
    .PARAMETER resourceGroupName
        Resource Group Name
    .PARAMETER createResource
        Flag to create resources
	.PARAMETER resourceGroupLocation
        Location for resource group
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
        2 - Resource doesn't exists
    .EXAMPLE
       Check-AzureResourceGroup -resourceGroupName "AnalyticsDemo01" -createResource $true
#>
function Check-AzureResourceGroup {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$resourceGroupName,

        [Parameter(Mandatory = $true, Position = 1)]
        [bool]$createResource,
		
		[Parameter(Mandatory = $true, Position = 2)]
        [string]$resourceGroupLocation
    )
    Process {
        Write-LogDebug "Inside Function Check-AzureResourceGroup"
        try {
            #Setting default Exit Code
            $LASTEXITCODE = 1
            Write-LogDebug "Checking if Resource Group Exists"
            $resourceGroup = Get-AzResourceGroup -Name $resourceGroupName
            if (!$resourceGroup) {
                Write-LogDebug "Resource group '$resourceGroupName' does not exist."
                if ($createResource) {
                    if (!$resourceGroupLocation) {
                        #$resourceGroupLocation = Read-Host "resourceGroupLocation";
						Throw "Location to create resource Group '$resourceGroupName' is null"
                    }
                    Write-LogDebug "Creating resource group '$resourceGroupName' in location '$resourceGroupLocation'"
                    $newAzRG = New-AzResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation
                }
                else {
                    $LASTEXITCODE = 2
                    Throw "Resource group '$resourceGroupName' does not exist"
                }    
            }
            else {
                Write-LogDebug "Using existing '$resourceGroupName' resource group "
            }
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }
        Write-LogDebug "Exiting Function Check-AzureResourceGroup"
        return $LASTEXITCODE
    }
}