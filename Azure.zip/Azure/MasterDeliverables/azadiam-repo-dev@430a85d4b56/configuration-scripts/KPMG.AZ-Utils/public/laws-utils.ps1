<#
    .SYNOPSIS
        This contains all the utility functions related to Log Analytics Workspace
    .DESCRIPTION
        This contains all the common utility related to Log Analytics Workspace

#>

<#
    .SYNOPSIS
        This function is used for building signature which is required for HTTP POST request to Log Analytics Workspace
    .DESCRIPTION
        This function gets all the parameter to generate authorizaton token which is required for HTTP POST request to Log Analytics Workspace
    .PARAMETER customerId
        This is the Log Analytics Workspace ID where data needs to be uploaded
    .PARAMETER sharedKey
        This is the shared key of Log Analytics Workspace where data needs to be uploaded. This is used for accessing the workspace
    .PARAMETER date
        Current Date used for header
    .PARAMETER contentLength
        Size of JSON body that will be sent as part of HTTP POST request to Log Analytics Workspace
    .PARAMETER method
        HTTP method used for this particular execution
    .PARAMETER contentType
        Type of content being sent over the HTTP request (e.g. application/json)
    .PARAMETER resource
        Used for setting the api end point
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Build-Signature -customerId $customerId -sharedKey $sharedKey -date $date -contentLength $contentLength -method $method -contentType $contentType -resource $resource
#>
function Build-Signature {
    [CmdletBinding()]
    [OutputType([string])]
    param (
        [Parameter(Mandatory = $True, Position = 0)]
        [string]$customerId,

        [Parameter(Mandatory = $True, Position = 1)]
        [SecureString]$sharedKey,

        [Parameter(Mandatory = $True, Position = 2)]
        [string]$contentLength,

        [Parameter(Mandatory = $True, Position = 3)]
        [string]$date,

        [Parameter(Mandatory = $True, Position = 4)]
        [string]$contentType,

        [Parameter(Mandatory = $True, Position = 5)]
        [string]$method,

        [Parameter(Mandatory = $True, Position = 6)]
        [string]$resource
    )
    Process {
        Write-LogInfo "Inside Function Build-Signature"
        try {
            #Deafult exit code
            $LASTEXITCODE = 1
            $xHeaders = "x-ms-date:" + $date
            $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource

            $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
            $Key = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($sharedKey))
            $keyBytes = [Convert]::FromBase64String($Key)

            $sha256 = New-Object System.Security.Cryptography.HMACSHA256
            $sha256.Key = $keyBytes
            $calculatedHash = $sha256.ComputeHash($bytesToHash)
            $encodedHash = [Convert]::ToBase64String($calculatedHash)
            $authorization = 'SharedKey {0}:{1}' -f $customerId, $encodedHash
            
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }
        Write-LogInfo "Exiting Function Build-Signature"
        return $authorization
    }
}

<#
    .SYNOPSIS
        This function is used for uploading data to Log Analytics Workspace in Azure Tenant 
    .DESCRIPTION
        This function uploads data to Log Analytics Workspace in Azure Tenant as per defined workspace
    .PARAMETER customerId
        This is the Log Analytics Workspace ID where data needs to be uploaded
    .PARAMETER sharedKey
        This is the shared key of Log Analytics Workspace where data needs to be uploaded. This is used for accessing the workspace
    .PARAMETER body
        This is the data that need to be sent to Log Analytics Workspace. This has to be provided in JSON format.
    .PARAMETER logType
        This defines the name of the log table in the workspace.
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body $jsonObject -logType "MFALogs"
#>
function Post-LogAnalyticsData {
    [CmdletBinding()]
    [OutputType([Int])]
    param (
        [Parameter(Mandatory = $True, Position = 0)]
        [string]$customerId,

        [Parameter(Mandatory = $True, Position = 1)]
        [SecureString]$sharedKey,

        [Parameter(Mandatory = $True, Position = 2)]
        [string]$body,

        [Parameter(Mandatory = $True, Position = 3)]
        [string]$logType
    )
    Process {
        Write-LogInfo "Inside Function Post-LogAnalyticsData"
        try {
            #Deafult exit code
            $LASTEXITCODE = 1
            $TimeStampField = ""
            $method = "POST"
            $contentType = "application/json"
            $resource = "/api/logs"
            $rfc1123date = [DateTime]::UtcNow.ToString("r")
            $contentLength = $body.Length
            
            $signature = Build-Signature `
                -customerId $customerId `
                -sharedKey $sharedKey `
                -contentLength $contentLength `
                -date $rfc1123date `
                -contentType $contentType `
                -method $method `
                -resource $resource
            
            If ($null -eq $signature) {
                Throw "Signature Build Failed"
            }
            $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"
            
            $headers = @{
                "Authorization"        = $signature;
                "Log-Type"             = $logType;
                "x-ms-date"            = $rfc1123date;
                "time-generated-field" = $TimeStampField;
            }
            $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
            if ($response.StatusCode -eq 200) {
                $LASTEXITCODE = 0
                Write-LogDebug "LAWS Data upload successful for $logType"
            }
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            
        }
        Write-LogInfo "Exiting Function Post-LogAnalyticsData"
        return $response.StatusCode
    }

}

<#
    .SYNOPSIS
        This function is used for uploading file to Log Analytics Workspace for a given file
    .DESCRIPTION
        This function is used for uploading file to Log Analytics Workspace for a given file
    .PARAMETER customerId
        LAWS workspace ID
    .PARAMETER filePath
        Full path of the file to be uploaded
    .PARAMETER sharedKey
        Shared key of the LAWS for uploading file
    .PARAMETER logType
        LAWS table name where the file to be uploaded
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
        2 - Post Data to LAWS failed
    .EXAMPLE
       Add-DataToLAWS -customerId $customerId -filePath "\data\AssessmentCriteria.csv" -sharedKey $sharedKey -logType $logType 
#>
function Add-DataToLAWS {
    [CmdletBinding()]
    [OutputType([int])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$customerId,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]$filePath,

        [Parameter(Mandatory = $true, Position = 2)]
        [SecureString]$sharedKey,

        [Parameter(Mandatory = $true, Position = 3)]
        [string]$logType

    )
    Process {
        Write-LogInfo "Inside Function Add-DataToLAWS"
        try {
            $LASTEXITCODE = 1
            $jsonObject = Import-CSV $filePath | ConvertTo-Json
            $response = Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body $jsonObject -logType $logType
            if ($response -ne 200) {
                $LASTEXITCODE = 2
                
            }
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }
        Write-LogInfo "Exiting Function Add-DataToLAWS"
        return $LASTEXITCODE  
    }
    
}

<#
    .SYNOPSIS
        This function is used for checking if log analytics workspace exists, if not then create a new one
    .DESCRIPTION
        This function is used for checking if log analytics workspace exists, if not then create a new one.
        Once workspace is found/created, return workspace ID and primary shared key
    .PARAMETER lawsResourceGroupName
        Resource Group Name where Azure Log Analytics is defined
    .PARAMETER workspaceLAWS
        Name of the Log Analytics Workspace
    .PARAMETER createResource
        Flag to create resources
	.PARAMETER resourceGroupLocation
        Location for resource group
	.PARAMETER workspaceLocation
        Location for log analytics workspace
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Check-AzureLogAnalyticsWorkspace -lawsResourceGroupName "AnalyticsDemo01" -workspaceLAWS "DemoLAWS2021" -createResource $true
#>
function Check-AzureLogAnalyticsWorkspace {
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$lawsResourceGroupName,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]$workspaceLAWS,

        [Parameter(Mandatory = $true, Position = 2)]
        [bool]$createResource,
		
		[Parameter(Mandatory = $true, Position = 3)]
        [string]$resourceGroupLocation,
		
		[Parameter(Mandatory = $true, Position = 4)]
        [string]$workspaceLocation
    )
    Process {
        Write-LogInfo "Inside Function Check-AzureLogAnalyticsWorkspace"
        try {
            $LASTEXITCODE = 1
            $checkResourceGroup = Check-AzureResourceGroup -resourceGroupName $lawsResourceGroupName -createResource $createResource -resourceGroupLocation $resourceGroupLocation
            if ($checkResourceGroup -eq 0) {
                Write-LogDebug "Checking if LAWS Exists"
            
                $workspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName $lawsResourceGroupName -Name $workspaceLAWS
                if (!$workspace) {
                    Write-LogDebug "Log Analytics '$workspaceLAWS' does not exist";
                    if ($createResource) {
                        if (!$workspaceLocation) {
                             #$resourceGroupLocation = Read-Host "resourceGroupLocation";
							 Throw "Location to create Log Analytics '$workspaceLAWS' is null"
                        }
                        Write-LogDebug "Creating LAWS '$workspaceLAWS' in location '$workspaceLocation'"
                        $workspace = New-AzOperationalInsightsWorkspace -ResourceGroupName $lawsResourceGroupName -Name $workspaceLAWS -Sku "Standard" -Location $workspaceLocation
                    }
                    else {
                        Throw "Log Analytics '$workspaceLAWS' does not exist"
                    }  
                }
                else {
                    Write-LogDebug "Using existing LAWS '$workspaceLAWS'"
                }
            
                $workspaceId = $workspace.CustomerId
                $primarySharedKey = (Get-AzOperationalInsightsWorkspaceSharedKey -ResourceGroupName $lawsResourceGroupName -Name $workspaceLAWS).PrimarySharedKey

                $workspaceInfo = @{customerId = $workspaceId; sharedKey = $primarySharedKey }
            }
            
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }
        Write-LogInfo "Exiting Function Check-AzureLogAnalyticsWorkspace"
        return $workspaceInfo

    }
}

<#
    .SYNOPSIS
        This function is used to get detauls from azure using azure powershell api based on the input query and post it to Log Analytics Workspace in Azure
    .DESCRIPTION
        This function is used to get detauls from azure using azure powershell api based on the input query and post it to Log Analytics Workspace in Azure
	.PARAMETER customerId
        Specifies the workspace Id.
    .PARAMETER sharedKey
        Specifies the workspace shared key
    .PARAMETER logType
        Specifies the table name for logs to load in log analytics
    .PARAMETER query
        Specifies the azure ad powershell api to get data
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
#>
Function Add-DataToLogs {

    [CmdletBinding()]
    [OutputType([Int])]
    param (
        [Parameter(Mandatory = $True, Position = 0)]
        [string]$customerId,

        [Parameter(Mandatory = $True, Position = 1)]
        [SecureString]$sharedKey,

        [Parameter(Mandatory = $True, Position = 2)]
        [string]$logType,
		
        [Parameter(Mandatory = $True, Position = 3)]
        [PSCustomObject]$query		
    )
    Process {
        Write-LogInfo "Starting Function Add-DataToLogs"
        try {
            $getData = Invoke-Expression $query
            $getDataJson = $getData | ConvertTo-Json
            $response = Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body $getDataJson -logType $logType 
            If ($response.StatusCode -eq "200") {	
                Write-LogDebug "Record type posted successfully to azure"
            }
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }	
        Write-LogInfo "Exiting Function Add-DataToLogs"
    } 	
}

<#
    .SYNOPSIS
        This function is used to create a temp Datatable to combain two different api data to single object
    .DESCRIPTION
        This function is used to create a temp Datatable to combain two different api data to single object
	.PARAMETER obj1
        Specifies the id column name for temp Datatable
    .PARAMETER obj2
        Specifies the name column name for temp Datatable
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
#>
function createSingleObj($obj1, $obj2) {
    ###Creating a new DataTable###
    $tempTable = New-Object System.Data.DataTable
    ##Creating Columns for DataTable##
    $col1 = New-Object System.Data.DataColumn("userId")
    $col2 = New-Object System.Data.DataColumn("displayName")
    $col3 = New-Object System.Data.DataColumn($obj1)
    $col4 = New-Object System.Data.DataColumn($obj2)
    ###Adding Columns for DataTable###
    $tempTable.columns.Add($col1)
    $tempTable.columns.Add($col2)
    $tempTable.columns.Add($col3)
    $tempTable.columns.Add($col4)
    return , $tempTable
}
<#
    .SYNOPSIS
        This function is used to get details of Group Membership and user manager using azure powershell api and post it to Log Analytics Workspace in Azure
    .DESCRIPTION
        This function is used to get details of Group Membership and user manager using azure powershell api and post it to Log Analytics Workspace in Azure
	.PARAMETER customerId
        Specifies the workspace Id.
    .PARAMETER sharedKey
        Specifies the workspace shared key
    .PARAMETER logType
        Specifies the tble name fot logs to load in log analytics
	.PARAMETER obj1
        Specifies the id column name for temp Datatable
    .PARAMETER obj2
        Specifies the name column name for temp Datatable
	.PARAMETER query
        Specifies the first azure powershell api
    .PARAMETER querySecond
        Specifies the second azure powershell api
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
#>
Function Add-CombinedDataToLogs {
    [CmdletBinding()]
    [OutputType([Int])]
    param (
        [Parameter(Mandatory = $True, Position = 0)]
        [string]$customerId,

        [Parameter(Mandatory = $True, Position = 1)]
        [SecureString]$sharedKey,

        [Parameter(Mandatory = $True, Position = 2)]
        [string]$logType,
		
		[Parameter(Mandatory = $True, Position = 3)]
        [string]$obj1,
		
		[Parameter(Mandatory = $True, Position = 4)]
        [string]$obj2,
		
		[Parameter(Mandatory = $True, Position = 5)]
        [string]$query,
		
		[Parameter(Mandatory = $True, Position = 6)]
        [string]$querySecond,
		
		[Parameter(Mandatory = $True, Position = 7)]
        [string]$check

    )
    Process {
	
        Write-LogInfo "Starting Function Add-CombinedDataToLogs"
        ###Getting a new DataTable [System.Data.DataTable]###
        try {
            $dTable = createSingleObj -obj1 $obj1 -obj2 $obj2
            $getQueryData = Invoke-Expression $query
            $getSecondQueryData = ""
            foreach ($queryValue in $getQueryData) {
				$objId = $queryValue.ObjectId
				$updatedQuery = "$querySecond -ObjectId $objId | select ObjectId, displayName"
				$getSecondQueryData = Invoke-Expression $updatedQuery
				foreach ($secondQueryValue in $getSecondQueryData) {
				if ($check -eq "user"){
					$row = $dTable.NewRow()
					$row["userId"] = $queryValue.ObjectId
					$row["displayName"] = $queryValue.displayName
					$row[$obj1] = $secondQueryValue.ObjectId
					$row[$obj2] = $secondQueryValue.displayName
					$dTable.rows.Add($row)
				}elseif($check -eq "group"){
					$row = $dTable.NewRow()
					$row["userId"] = $secondQueryValue.ObjectId
					$row["displayName"] = $secondQueryValue.displayName
					$row[$obj1] = $queryValue.ObjectId
					$row[$obj2] = $queryValue.displayName
					$dTable.rows.Add($row)
				} 				
			 }	
            } 
			
            $getCombinedData = ($dTable | select $dTable.Columns.ColumnName ) | ConvertTo-Json 	
			$response = Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body $getCombinedData -logType $logType 
            If ($response.StatusCode -eq "200") {	
                Write-Output "Record type posted successfully to azure"
            }
        }catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }	
        Write-LogInfo "Exiting Function Add-CombinedDataToLogs"
    }
}


<#
    .SYNOPSIS
        This function is used to get all the details of Application using graph api and post it to Log Analytics Workspace in Azure
    .DESCRIPTION
        This function is used to get all the details of Application using graph api and post it to Log Analytics Workspace in Azure
	.PARAMETER SelGraphApp
        Specifies the graph api access deatils
	.PARAMETER customerId
        Specifies the workspace Id.
    .PARAMETER sharedKey
        Specifies the workspace shared key
    .PARAMETER logType
        Specifies the tble name fot logs to load in log analytics
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
#>
Function Add-ApplicationDataToLAWS {
    [CmdletBinding()]
    [OutputType([Int])]
    param (
	
        [Parameter(Mandatory = $True, Position = 0)]
        [PSCustomObject]$SelGraphApp,
		
        [Parameter(Mandatory = $True, Position = 1)]
        [string]$customerId,

        [Parameter(Mandatory = $True, Position = 2)]
        [SecureString]$sharedKey,

        [Parameter(Mandatory = $True, Position = 3)]
        [string]$logType				

    )
    Process {
        Write-LogInfo "Starting Function Add-ApplicationDataToLAWS"
        try {
            $clientId = $SelGraphApp.clientid 
            $clientSecret = $SelGraphApp.clientSecret
            $tenantName = $SelGraphApp.tenantId 
            $resource = $SelGraphApp.resource  
            $URL = $SelGraphApp.urial 
            $tokenResponse = Generate-AppToken -ClientSecret $clientSecret -ClientID $clientId -TenantID $tenantName
            $result = Invoke-RestMethod -Headers @{Authorization = "Bearer $($tokenResponse)" } -Uri $URL -Method Get
            $ApplicationsArray = $result.Value | ConvertTo-Json
            $response = Post-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body $ApplicationsArray -logType $logType
            If ($response.StatusCode -eq "200") {	
                Write-Output "Record type posted successfully to azure"
            }
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }	
        Write-LogInfo "Exiting Function Add-ApplicationDataToLAWS"    
    }	 
}

<#
    .SYNOPSIS
        This function is used to set log analytics rule to push logs from Azure AD Diagnostics to Log Analytics Workspace Azure
    .DESCRIPTION
        This function is used to set log analytics rule to push logs from Azure AD Diagnostics to Log Analytics Workspace Azure
	.PARAMETER workspaceName
        Specifies the name of workspace
	.PARAMETER ruleName
        Specifies the name of AAD rule name
#>
Function Set-AzureLogAnalyticsWorkspace {
[CmdletBinding()]
[OutputType([string])]
    param (
	[Parameter(Mandatory = $True, Position = 0)]
	[string]$workspaceName,

	[Parameter(Mandatory = $True, Position = 1)]
	[String]$ruleName
    )
    Process {
        Write-LogInfo "Starting Function Set-AzureLogAnalyticsWorkspace"
        try {
			
			$ErrorActionPreference = 'Stop'
			$workspaceResource = Get-AzResource -ResourceType "Microsoft.OperationalInsights/workspaces" -Name $workspaceName
			$workspaceId = $workspaceResource.ResourceId
			$azureRmProfileModuleVersion = (Get-Module Az.Profile).Version
			$azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
			if(-not $azureRmProfile.Accounts.Count) {
				Write-LogError "Ensure you have logged in before calling this function."    
			}
			$currentAzureContext = Get-AzContext
			$profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
			Write-LogDebug ("Getting access token for tenant :: " + $currentAzureContext.Tenant.TenantId)
			$token = $profileClient.AcquireAccessToken($currentAzureContext.Tenant.TenantId)
			$tokenResponse = $token.AccessToken
			#Write-LogDebug "TokenResponse :: $tokenResponse" 		
			
			$uri = "https://management.azure.com/providers/microsoft.aadiam/diagnosticSettings/{0}?api-version=2017-04-01-preview" -f $ruleName
			$body = @"
	{
    "id": "providers/microsoft.aadiam/diagnosticSettings/$ruleName",
    "type": null,
    "name": "Log Analytics",
    "location": null,
    "kind": null,
    "tags": null,
    "properties": {
      "storageAccountId": null,
      "serviceBusRuleId": null,
      "workspaceId": "$workspaceId",
      "eventHubAuthorizationRuleId": null,
      "eventHubName": null,
      "metrics": [],
      "logs": [
        {
          "category": "AuditLogs",
          "enabled": true,
          "retentionPolicy": { "enabled": false, "days": 31 }
        },
        {
          "category": "SignInLogs",
          "enabled": true,
          "retentionPolicy": { "enabled": false, "days": 31 }
        }
      ]
    },
    "identity": null
  }
"@

			$headers = @{
				"Authorization" = "Bearer $tokenResponse"
				"Content-Type"  = "application/json"
			}
			$response = Invoke-WebRequest -Method Put -Uri $uri -Body $body -Headers $headers
			#Write-LogDebug "Response :: $response"
		}catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }     
		
		Write-LogInfo "Exiting Function Set-AzureLogAnalyticsWorkspace"   
	}
}	 