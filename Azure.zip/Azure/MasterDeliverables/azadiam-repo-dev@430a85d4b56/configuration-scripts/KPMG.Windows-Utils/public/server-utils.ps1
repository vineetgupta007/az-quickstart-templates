<#
    .SYNOPSIS
        Adds a Reverse DNS Lookup Zone
    .DESCRIPTION
        Function Add-ReverseDNSZone will add a reverse DNS lookup zone to the Forest Root DC. It supports Local and Remote execution.
    .PARAMETER NetID
        Specifies a network ID (IP Address) and prefix length for a reverse lookup zone
        Example: 172.16.14.36
    .PARAMETER LastOctave
        Specifies the last octave for reverse dns lookup zone. Default is 24.
    .PARAMETER ComputerName
        Computer name or ip address of the remote host server.
    .PARAMETER LAdminCreds
        PSCredential object with host's admin credentials
    .OUTPUTS
        int
        0 on success
        1 when NetID is null/empty
        2 when NetID is invalid address
        3 when Add-DnsServerPrimaryZone cmdlet didn't finish successfully
        4 when Add-DnsServerPrimaryZone cmdlet returns NULL
        5 when unknown error.
#>
Function Add-ReverseDNSZone {
    [CmdletBinding()]
    [OutputType([int])]
    
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $NetID,

        [Parameter(Mandatory = $False, Position = 1)]
        [string]
        $LastOctave,

        [Parameter(Mandatory = $False, Position = 2)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $False, Position = 3)]
        [pscredential]
        $LAdminCreds
    )

    Process {

        $respCode = 1
        $dnsResp = $null
        
        Write-LogInfo "Inside Function Add-ReverseDNSZone."
        Write-LogDebug "Input NetID :: $NetID"
        Write-LogDebug "Input ComputerName :: $ComputerName" 
        Write-LogDebug "Input LastOctave :: $LastOctave" 

        try {

            If ((StringNullOrEmpty $NetID)) {
                $respCode = 1 
                Throw "Network ID range is null/empty/whitespace."            
            }

            #IP validation
            $isValidIp = IsIPAddressValid $NetID
            Write-LogDebug "isValidIp :: $isValidIp"
            If (!($isValidIp)) {
                $respCode = 2
                Throw "Provided NetID is invalid. Please provide valid DNS Server IP."
            }

            If(StringNullOrEmpty $LastOctave){
                $LastOctave = '24'
            }

            $NetID = ($NetID.Split(".")[0..2]) -join (".")
            $NetID = $NetID + '.0/' + $LastOctave
            Write-LogDebug "Using NetID :: $NetID"

            If (!(StringNullOrEmpty $ComputerName)) {
                Write-LogDebug "Invoke-Command -ComputerName $ComputerName -ScriptBlock { Add-DnsServerPrimaryZone -NetworkID $NetID -ReplicationScope Forest -PassThru -ErrorAction Stop} -Credential $LAdminCreds"
                $dnsResp = Invoke-Command -ComputerName $ComputerName -ScriptBlock { Add-DnsServerPrimaryZone -NetworkID $using:NetID -ReplicationScope "Forest" -PassThru -ErrorAction Stop } -Credential $LAdminCreds
            }
            Else {
                Write-LogDebug "Add-DnsServerPrimaryZone -NetworkID $NetID -ReplicationScope Forest -PassThru -ErrorAction Stop"
                $dnsResp = Add-DnsServerPrimaryZone -NetworkID $NetID -ReplicationScope "Forest" -PassThru -ErrorAction Stop
            }
            
            If ($null -ne $dnsResp) {
                $dnsZoneName = $dnsResp.ZoneName
                Write-LogDebug "Zone name :: $dnsZoneName"

                $isDnsRev = $dnsResp.IsReverseLookupZone
                Write-LogDebug "Is Zone reverse lookup :: $isDnsRev"

                If ((StringNullOrEmpty $dnsZoneName) -or !($isDnsRev)) {
                    $respCode = 3
                    Throw "ReverseDNSZone setup did not finish successfully."                    
                }
                Else {
                    Write-LogDebug "ReverseDNSZone setup finished successfully."
                    $respCode = 0
                }
            }
            Else {
                $respCode = 4
                Throw "Add-DnsServerPrimaryZone cmdlet returned NULL response."                
            }         
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            If (($null -eq $respCode) -or ($respCode = 0)) {
                $respCode = 5
            }
        }
        Write-LogInfo "Exiting Function Add-ReverseDNSZone with response :: $respCode"
        return $respCode
    }    
}

<#
    .SYNOPSIS
        Restarts remote computer
    .DESCRIPTION
        Function Restart-ComputerWSMan will restart the remote computer and confirm the restart status. It uses WSMan protocol.
    .PARAMETER ComputerName,
        Remote computr name or ip address
    .PARAMETER LAdminCreds
        PSCredential object with admin credentials
    .OUTPUTS
        int
        0 on success
        1 on failure
#>
Function Restart-ComputerWSMan {
    [CmdletBinding()]
    [OutputType([int])]
    
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $True, Position = 1)]
        [pscredential]
        $LAdminCreds
    )

    Process {

        $respCode = 2
        Write-LogInfo "Entering Function Restart-ComputerWSMan."
		
        Try {
            Write-LogDebug "Restarting computer :: $ComputerName"

            #Restart-Computer doesn't return any output
            Write-LogDebug "Restart-Computer -Wait -ComputerName $ComputerName -Credential $LAdminCreds -Force -Protocol WSMan -ErrorAction Stop"
            Restart-Computer -Wait -ComputerName $ComputerName -Credential $LAdminCreds -Force -Protocol WSMan -ErrorAction Stop

            Write-LogDebug "Restarted computer :: $ComputerName"	
            $respCode = 0
        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            $respCode = 1
        }
        Write-LogInfo "Exiting Function Restart-ComputerWSMan with response :: $respCode" 
        return $respCode 
    }
}

<#
    .SYNOPSIS
        Adds windows feature.
    .DESCRIPTION
        Function Add-WinFeature installs given window feature
    .PARAMETER FeatureName
        Name of the window feature that you want to add.
    .PARAMETER ComputerName
        Computer name or ip if running remotely.
    .PARAMETER LAdminCredentials
        Admin credential object.
    .OUTPUTS
        int
        0 on success
        1 when featurename is NULL
        2 when credentials are NULL
        3 when Add-WindowsFeature cmdlet returns NULL
        4 when Add-WindowsFeature cmdlet returns failure
        5 when unknown error
#>
Function Add-WinFeature {
    [CmdletBinding()]
    [OutputType([int])]
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $FeatureName,

        [Parameter(Mandatory = $False, Position = 1)]
        [pscredential]
        $LAdminCredentials,

        [Parameter(Mandatory = $False, Position = 2)]
        [string]
        $ComputerName
    )

    Process {

        $respCode = 5
        $addFeatResp = $null

        Write-LogInfo "Inside Function Add-WinFeature."
        Write-LogDebug "Input FeatureName :: $FeatureName"       
        
        If (StringNullOrEmpty $FeatureName) {
            $respCode = 1
            Write-LogError "FeatureName is NULL/Empty."
            Write-LogInfo "Exiting Function Add-WinFeature with response :: $respCode"
            return $respCode
        }

        try {
            
            If ($ComputerName) {
                If ($LAdminCredentials -eq $null) {
                    $respCode = 2
                    Write-LogError "Credentials are NULL."
                    Write-LogInfo "Exiting Function Add-WinFeature with response :: $respCode"
                    return $respCode
                }
                Write-LogDebug "Invoke-Command -ComputerName $ComputerName -ScriptBlock { Add-WindowsFeature -Name $FeatureName -IncludeAllSubFeature -IncludeManagementTools -PassThru } -credential $LAdminCredentials"

                $addFeatResp = Invoke-Command -ComputerName $ComputerName -ScriptBlock { Add-WindowsFeature -Name $FeatureName -IncludeAllSubFeature -IncludeManagementTools -PassThru } -credential $LAdminCredentials                                                       
            }
            Else {
                Write-LogDebug "Add-WindowsFeature -Name $FeatureName -IncludeAllSubFeature -IncludeManagementTools -PassThru"
                $addFeatResp = Add-WindowsFeature -Name $FeatureName -IncludeAllSubFeature -IncludeManagementTools -PassThru
            }

            Write-LogDebug "Checking Add-WindowsFeature cmdlet response."

            If ($null -eq $addFeatResp) {
                Write-LogError "$FeatureName feature didn't install successfully."              
                $respCode = 3  
            }
            Else {
                $isFeatAdded = $addFeatResp.Success
                Write-LogDebug "isFeatAdded :: $isFeatAdded"

                If ($isFeatAdded -eq $True) {
                    Write-LogDebug "$FeatureName added successfully."
                    $respCode = 0
                }
                Else {
                    Write-LogError "$FeatureName was not added successfully."
                    $respCode = 4
                }               
            }
                    
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage" 
            $respCode = 5
        }
        Write-LogInfo "Exiting Function Add-WinFeature with response :: $respCode"
        return $respCode
    }
}

<#
    .SYNOPSIS
        Gets .NET framework version's release data key.
    .DESCRIPTION
        Function Get-DotNet4Version returns the .NET framework's release data key [REG_DWORD entry named Release] from windows registry.
        [("HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").Release]
    .PARAMETER ComputerName
        Computer name or ip if running remotely.
    .PARAMETER LAdminCredentials
        Admin credential object.
    .OUTPUTS
        int
        .NET4 version Code on success
        1 when credentials are NULL
        2 when version not found
        3 when unknown error
#>
Function Get-DotNet4Version {
    [CmdletBinding()]
    [OutputType([int])]
    Param(
        [Parameter(Mandatory = $False, Position = 0)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $False, Position = 1)]
        [pscredential]
        $LAdminCredentials
    )

    Process {

        $respCode = 3

        Write-LogInfo "Inside Function Get-DotNet4Version."
        
        Write-LogDebug "Input ComputerName :: $ComputerName"
        Write-LogDebug "Input LAdminCredentials :: $LAdminCredentials"

        try {
            If (!(StringNullOrEmpty $ComputerName)) {
                If ($null -eq $LAdminCredentials) {
                    $respCode = 1
                    Write-LogError "Credentials are NULL."
                    Write-LogInfo "Exiting Function Get-DotNet4Version with response :: $respCode"
                    return $respCode
                }
                Write-LogDebug "Invoke-Command -ComputerName $ComputerName -ScriptBlock { (Get-ItemProperty HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full).Release } -credential $LAdminCredentials"
                $respCode = Invoke-Command -ComputerName $ComputerName -ScriptBlock { (Get-ItemProperty "HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").Release } -credential $LAdminCredentials
            }
            Else {
                Write-LogDebug "(Get-ItemProperty HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full).Release"
                $respCode = (Get-ItemProperty "HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").Release
            }

            If (StringNullOrEmpty $respCode) {
                Write-LogError "Could not find the .Net4 version."
                $respCode = 2
            }
            Else {
                Write-LogDebug "Found the .NET4 version :: $respCode"
            }

        }
        catch {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage" 
            $respCode = 3
        }
        Write-LogInfo "Exiting Function Get-DotNet4Version with response :: $respCode"
        return $respCode
    }
}

<#
    .SYNOPSIS
        Rename and reboot server
    .DESCRIPTION
        Rename and reboot a windows server
    .PARAMETER IpAddress
        Computer name or ip of the server
    .PARAMETER ServerName
        Desired server name
    .PARAMETER LAdminCredentials
        Admin credential object.
    .OUTPUTS
        int
        .NET4 version Code on success
        0 - Success
        1 - Rename-Computer cmdlet returned failure response
        2 - Rename-Computer cmdlet returned NULL
        3 - Failure to restart
        4 - Unknown exception occured
#>
Function Rename-AndReboot {
    [CmdletBinding()]
    [OutputType([int])] 
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $IpAddress,

        [Parameter(Mandatory = $True, Position = 1)]
        [string]
        $ServerName,

        [Parameter(Mandatory = $True, Position = 2)]
        [PSCredential]
        $LACredentials
    )

    Process {
        
        $respCode = 4

        Write-LogInfo "Inside Function Rename-AndReboot."
        Write-LogDebug "Input ServerName is :: $ServerName"
        Write-LogDebug "Input IpAddress is :: $IpAddress"
            
        Try {
            #Check current comp name
            $CurrentCompName = Invoke-Command -ComputerName $IpAddress -ScriptBlock { $env:computername } -Credential $LACredentials
            Write-LogDebug "CurrentCompName :: $CurrentCompName"
            If ($CurrentCompName -eq $ServerName) {
                Write-LogInfo "No need to rename computer as the current computer name is already set as $ServerName"
                $respCode = 0
            }
            Else {

                Write-LogDebug "Ranaming computer to $ServerName"
                $CompChangeInfo = Rename-Computer -ComputerName $IpAddress -NewName $ServerName -LocalCredential $LACredentials -PassThru -Protocol WSMan
                If ($null -ne $CompChangeInfo) {
                    $isChangeSuccess = $CompChangeInfo.HasSucceeded
                    Write-LogDebug "Is Rename-Computer cmdlet success :: $isChangeSuccess"
                    If ($isChangeSuccess) {
                        Write-LogDebug "Computer $ServerName renamed successfully."
                    }
                    Else {
                        $respCode = 1
                        Throw "Computer $ServerName could not be renamed. Rename-Computer cmdlet returned $isChangeSuccess"                        
                    }
                }
                Else {
                    $respCode = 2
                    Throw "Computer $ServerName could not be renamed. Rename-Computer cmdlet returned NULL."                    
                }
                Write-LogDebug "Computer $ServerName renamed successfully. Proceeding to reboot."

                $restartResp = Restart-ComputerWSMan $IpAddress $LACredentials
                If ($restartResp -ne 0) {
                    $respCode = 3
                    Throw "Failed to restart computer $IpAddress $ServerName"
                }
                
                Write-LogDebug "Computer $ServerName restarted successfully."
                $respCode = 0  
            }  
        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            If (($respCode -eq $null) -or ($respCode -eq 0)) {
                $respCode = 4
            }
        }
        Write-LogInfo "Exiting Function Rename-AndReboot. Response Code :: $respCode"
        return $respCode
    }
}

<#
    .SYNOPSIS
        Sets DNS address for a given network interface
    .DESCRIPTION
        Sets DNS address for a given network interface
    .PARAMETER IntfAlias
        String. Network interface alias. i.e. Ethernet0, etc.
    .PARAMETER DNServer
        String. DNS server address.
    .PARAMETER LAdminCreds
        Admin credential object.
    .PARAMETER ComputerName
        String. Computer name or IP Address if running remotely.
    .OUTPUTS
        int
        .NET4 version Code on success
        0 - Success
        1 - Failure occured while setting DNS Server
        2 - Unknown exception occured
#>
Function Set-InterfaceDNS {
    [CmdletBinding()]
    [OutputType([int])] 

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $IntfAlias,

        [Parameter(Mandatory = $True, Position = 1)]
        [string]
        $DNServer,

        [Parameter(Mandatory = $True, Position = 2)]
        [PSCredential]
        $LAdminCreds,

        [Parameter(Mandatory = $False, Position = 3)]
        [string]
        $ComputerName
    )

    Process {
        Write-LogInfo "Inside function Set-InterfaceDNS."
        Write-LogDebug "Input IntfAlias :: $IntfAlias"
        Write-LogDebug "Input DNServer :: $DNServer"
        Write-LogDebug "Input LAdminCreds :: $LAdminCreds"
        Write-LogDebug "Input ComputerName :: $ComputerName"

        $respCode = 2

        Try {

            If (!(StringNullOrEmpty $ComputerName)) {
                $IntfIndex = Invoke-Command -ComputerName $ComputerName -ScriptBlock { Get-NetIPConfiguration -InterfaceAlias $using:IntfAlias | Select-Object -ExpandProperty 'InterfaceIndex' Name -first 1 } -Credential $LAdminCreds
                Write-LogDebug "Found interface index :: $IntfIndex" 

                Write-LogDebug "Changing DNS server to :: $DNServer" 
                Write-LogDebug "Invoke-Command -ComputerName $ComputerName -ScriptBlock { Set-DnsClientServerAddress -InterfaceIndex $IntfIndex -ServerAddresses $DNServer -PassThru -ErrorAction Stop} -Credential $LAdminCreds"
                $dnsResp = Invoke-Command -ComputerName $ComputerName -ScriptBlock { Set-DnsClientServerAddress -InterfaceIndex $using:IntfIndex -ServerAddresses $using:DNServer -PassThru -ErrorAction Stop } -Credential $LAdminCreds
            }
            Else {
                $IntfIndex = Get-NetIPConfiguration -InterfaceAlias $IntfAlias | Select-Object -ExpandProperty 'InterfaceIndex' Name -first 1;    
                Write-LogDebug "Found interface index :: $IntfIndex" 

                Write-LogDebug "Changing DNS server to :: $DNServer" 
                $dnsResp = Set-DnsClientServerAddress -InterfaceIndex $IntfIndex -ServerAddresses $DNServer -PassThru -ErrorAction Stop
            }

            Write-LogDebug "dnsResp :: $dnsResp"
            If ($null -eq $dnsResp) {
                $respCode = 1
                Throw "Failure occured while setting DNS Server $DNServer for interface $IntfAlias"
            }

            Write-LogInfo "DNS server changed to $DNServer" 
            $respCode = 0
        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            If (($respCode -eq $null) -or ($respCode -eq 0)) {
                $respCode = 2
            }
        }
        Write-LogInfo "Exiting function Set-InterfaceDNS. Response code :: $respCode"
        return $respCode
    }
}


<#
    .SYNOPSIS
        Waits for connection on a given port
    .DESCRIPTION
        Waits and retries the connection on a given port for a given server.
    .PARAMETER ComputerName
        String. Computer name or IP Address to test connection
    .PARAMETER Port
        int. Port number for connection
    .PARAMETER TimeToWait
        int. Time To Wait before retry
    .PARAMETER MaxTries
        int. Number of maximum reties for the connection test
    .OUTPUTS
        int
        .NET4 version Code on success
        0 - Success
        1 - Not able to connect after all retries
        2 - Unknown exception occured
#>
Function Wait-ForConnection {
    [CmdletBinding()]
    [OutputType([int])] 

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $True, Position = 1)]
        [int]
        $Port,

        [Parameter(Mandatory = $False, Position = 2)]
        [int]
        $TimeToWait = 30,

        [Parameter(Mandatory = $False, Position = 3)]
        [int]
        $MaxTries = 30
    )

    Process {
        $respCode = 1
        Write-LogInfo "Inside function Wait-ForConnection"

        Write-LogDebug "Input ComputerName :: $ComputerName"
        Write-LogDebug "Input Port :: $Port"
        Write-LogDebug "Input TimeToWait [in seconds] :: $TimeToWait"
        Write-LogDebug "Input MaxTries :: $MaxTries"

        Try {
            $ConnectionSuccess = $False
            $TrialCounter = 0
            while ($TrialCounter -lt $MaxTries) {
                Write-LogDebug "TrialCounter :: $TrialCounter"
                $ConnectionSuccess = (Test-NetConnection -ComputerName $ComputerName -Port $Port).TcpTestSucceeded
                If ($ConnectionSuccess) {
                    Write-LogDebug "Connection successful."
                    $TrialCounter = $MaxTries
                    $respCode = 0
                }
                Else {
                    $TrialCounter++
                    Start-Sleep -s $TimeToWait
                }
            } 
            
            Write-LogDebug "Final value for ConnectionSuccess :: $ConnectionSuccess"

        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            If (($respCode -eq $null) -or ($respCode -eq 0)) {
                $respCode = 2
            }
        }
        Write-LogInfo "Exiting function Wait-ForConnection. Response code :: $respCode"
        return $respCode
    }
}

<#
    .SYNOPSIS
        Runs a windows command scriptblock on local or remote server.
    .DESCRIPTION
        Runs a windows command scriptblock on local or remote server.
    .PARAMETER ScriptBlock
        String. Valid scriptblock with {} included.
    .PARAMETER ComputerName
        String. Computer name or IP Address.
    .PARAMETER UserCredentials
        pscredential. Admin credentials object for remote machine.
    .PARAMETER Session
        PSSession. Active session with appropriate permissions to run scriptblock commands.
    .OUTPUTS
        int,object
        0 - Success
        1 - Failure
#>
Function Submit-WinCommand {
    [CmdletBinding(DefaultParametersetName = "LocalCommand")]

    Param(
        [Parameter(Mandatory = $True, ParameterSetName = 'LocalCommand')]
        [Parameter(Mandatory = $True, ParameterSetName = 'RemoteCommand')]
        [Parameter(Mandatory = $True, ParameterSetName = 'RemoteSession')]
        [string]
        [ValidateNotNullOrEmpty()]
        $ScriptBlock,

        [Parameter(Mandatory = $True, ParameterSetName = 'RemoteCommand')]
        [string]
        [ValidateNotNullOrEmpty()]
        $ComputerName,

        [Parameter(Mandatory = $True, ParameterSetName = 'RemoteCommand')]
        [pscredential]
        $UserCredentials,

        [Parameter(Mandatory = $True, ParameterSetName = 'RemoteSession')]
        [System.Management.Automation.Runspaces.PSSession]
        $Session
    )

    Process {
        $respCode = 1
        $respObj = $null

        Write-LogInfo "Inside Function Submit-WinCommand."
        Write-LogDebug "Input ScriptBlock :: $ScriptBlock"
        Write-LogDebug "Input ComputerName :: $ComputerName"
        Write-LogDebug "Input UserCredentials :: $UserCredentials"
        Write-LogDebug "Input Session :: $Session"

        $SetName = $PSCmdlet.ParameterSetName
        Write-LogDebug "SetName :: $SetName"

        Try {
            $CommandScript = [scriptblock]::Create($ScriptBlock)
            If ($SetName -eq "RemoteCommand") {
                $respObj = Invoke-Command -ComputerName $ComputerName -Credential $UserCredentials -ScriptBlock $CommandScript
            }
            ElseIf ($SetName -eq "RemoteSession") {
                $respObj = Invoke-Command -Session  $Session -ScriptBlock $CommandScript
            }
            Else {
                $respObj = Invoke-Command -ScriptBlock $CommandScript
            }
            $respCode = 0
        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            If (($respCode -eq $null) -or ($respCode -eq 0)) {
                $respCode = 1
            }
        }
        Write-LogInfo "Exiting Function Submit-WinCommand."
        return $respCode, $respObj
    }
}

<#
    .SYNOPSIS
        Gets network interface alias name for given IpAddress
    .DESCRIPTION
        Gets network interface alias name for given IpAddress
    .PARAMETER IpAddress
        String. IpAddress of the computer/server.
    .PARAMETER LAdminCreds
        Admin credential object.
    .PARAMETER ComputerName
        String. Computer name or IP Address if running remotely.
    .OUTPUTS
        string. Interface Alias Name on success. Null on failure.
#>
Function Get-InterfaceAliasByIP {
    [CmdletBinding()]
    [OutputType([string])] 

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $IpAddress,

        [Parameter(Mandatory = $False, Position = 1)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $True, Position = 2)]
        [PSCredential]
        $LAdminCreds
    )

    Process {
        $IntfAlias = $null
        Write-LogInfo "Inside Function Get-InterfaceAliasByIP."
        Write-LogDebug "Input IpAddress :: $IpAddress"
        Write-LogDebug "Input ComputerName :: $ComputerName"
        Write-LogDebug "Input LAdminCreds :: $LAdminCreds"

        Try {
            If (!(StringNullOrEmpty $ComputerName) -and ($null -ne $LAdminCreds)) {
                $IntfAlias = Invoke-Command -ComputerName $ComputerName -Credential $LAdminCreds -ScriptBlock { (Get-NetIPAddress -IPAddress $using:IpAddress).InterfaceAlias }
            }
            Else {
                IntfAlias = (Get-NetIPAddress -IPAddress $IpAddress).InterfaceAlias
            }
            Write-LogDebug "Retrived IntfAlias :: $IntfAlias"
        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            $IntfAlias = $null
        }
        Write-LogInfo "Exiting Function Get-InterfaceAliasByIP."
        return $IntfAlias
    }


}

<#
    .SYNOPSIS
        Creates a System.Management.Automation.Runspaces.PSSession object.
    .DESCRIPTION
        Create-Session function creates a System.Management.Automation.Runspaces.PSSession object with supplied computername and credentials.
    .PARAMETER ComputerName
        Host on which session should be created 
    .PARAMETER LAdmCredentials
        System.Management.Automation.PSCredential object
    .OUTPUTS
        PSSession. Session object
#>

Function Get-PSSession{
    [CmdletBinding()]
    [OutputType([System.Management.Automation.Runspaces.PSSession])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [string] $ComputerName,
        [Parameter(Mandatory=$True,Position=1)]
        [string] $Username,
        [Parameter(Mandatory=$True,Position=2)]
        [SecureString] $Password
    )
    Process{
        try{
            $PSSessionObj = $null
            #Get-Credential object
            $CredentialObj = Get-PSCredentials -Username $Username -Password $Password
            If($null -eq $CredentialObj){
                Write-LogError "Credential creation failed for $ComputerName"
                Write-LogError "Exiting from script"
                exit 
            }
            Write-LogInfo "Inside Function Get-PSSession."
            Write-LogDebug "Input ComputerName is >$ComputerName<"
            $PSSessionObj = New-PSSession -ComputerName $ComputerName -Credential $CredentialObj
            Write-LogDebug "Returning PSSession object"
            Write-LogInfo "Exiting function Get-PSSession"
            return $PSSessionObj
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
        }
     }
}

 <#
.SYNOPSIS
    This function verifies the status of the service of remote server
.DESCRIPTION
     This function verifies the status of the service of remote server
.PARAMETER Services
    JSON array with names of services to be validated
.PARAMETER SessionObj
    Session object to connect to remote server
.OUTPUTS
    int serviceStatusCount
#>
Function Find-ServiceStatus {
    [CmdletBinding()]
	[OutputType([int])]
    Param(
		[string[]]$Services,
		[PSObject]$SessionObj
    )
    Process {	
	 try {
			Write-LogInfo "Entering function Find-ServiceStatus"
			$serviceStatusCount = 0
			foreach($ServiceName in $Services)
			{
				$serviceStatus = & Invoke-Command -Session $SessionObj -ScriptBlock { get-service $Using:ServiceName -ErrorAction 'SilentlyContinue' }
				If ( $serviceStatus ){
					$displayName = $serviceStatus.DisplayName
					Write-LogDebug "Display Name of service :: $displayName"
					$serviceStatus = $serviceStatus.Status
					Write-LogDebug "Status of service :: $serviceStatus"
					If ($serviceStatus -eq 'Running'){
						Write-LogInfo "Status of $displayName is  :: $serviceStatus "
					} Else {
						Write-LogError "Status of $displayName is  :: $serviceStatus "
					}
				} Else {			
					$serviceStatusCount = $serviceStatusCount + 1
					Write-LogInfo "Azure AD Password Protection Proxy service :: $ServiceName :: is not configured on remote server"
				}
			}				
		} catch {
			$ErrorMessage = $_.Exception.Message
			$FailedItem = $_.Exception.ItemName
			Write-LogError $ErrorMessage
			Write-LogError $FailedItem
			break
		}
		Write-LogInfo "Exiting function Find-ServiceStatus"
		return $serviceStatusCount
     }
  }
  
<#
.SYNOPSIS
    This function checks the operating system version for remote server
.DESCRIPTION
    This function checks the operating system version for remote server
.PARAMETER SessionObj
    Session object to connect to remote server
.OUTPUTS
    int getWinVer
#>
Function Get-WinOS {
    [CmdletBinding()]
	[OutputType([int])]
    Param(
		[PSObject]$SessionObj
    )
    Process {	
	 try {
			Write-LogInfo "Entering function Get-WinOS"
			$getWinVersion =  & Invoke-Command -Session $SessionObj -ScriptBlock {(Get-WmiObject -class Win32_OperatingSystem).Caption}
			$getWinVer = [int] ($getWinVersion -replace "[^0-9]" , '')
			Write-LogDebug "Windows OS Version on Remote Server :: $getWinVersion"
		} catch {
			$ErrorMessage = $_.Exception.Message
			$FailedItem = $_.Exception.ItemName
			Write-LogError $ErrorMessage
			Write-LogError $FailedItem
			break
		}
		Write-LogInfo "Exiting function Get-WinOS"
		return $getWinVer
     }
  }
  
<#
.SYNOPSIS
    This function finds checks the stauts of outbound ports
.DESCRIPTION
    This function finds checks the stauts of outbound ports
.PARAMETER OutbountPort
    JSON array which has list of roles which user can be part of
.PARAMETER testporthost
	User name whose role needs to be evaluated
.PARAMETER SessionObj
    Session object to connect to remote server
.OUTPUTS
    int outboundPortStatus
#>
Function Find-outboundPortStatus {
    [CmdletBinding()]
	[OutputType([int])]
    Param(
		[string[]]$OutbountPort,
		[PSObject]$SessionObj,
		[string] $testporthost
    )
    Process {	
	 try {
			Write-LogInfo "Entering function Find-outboundPortStatus"
			$outboundPortStatus = 0
			foreach($port in $OutbountPort)
			{
				Write-LogDebug "Test port Microsoft URL :: $testporthost"
				$testPort= & Invoke-Command -Session $SessionObj -ScriptBlock {Test-NetConnection $using:testporthost -Port $using:port | findstr "TcpTestSucceeded"}
				Write-LogDebug "Test port for port $port with Microsoft URL is :: $testPort"
				If( $testPort -match "TcpTestSucceeded : True") {	
					Write-LogInfo "Outbound port $port is already open"		
				} Else {
					$outboundPortStatus = $outboundPortStatus + 1
					Write-LogError "Outbound port $port is blocked" 
				}
			}
		} catch {
			$ErrorMessage = $_.Exception.Message
			$FailedItem = $_.Exception.ItemName
			Write-LogError $ErrorMessage
			Write-LogError $FailedItem
			break
		}
		Write-LogInfo "Exiting function Find-outboundPortStatus"
		return $outboundPortStatus
     }
  }
  
<#
    .SYNOPSIS
        Gets Windows RAM for a given machine
    .DESCRIPTION
        Function Get-WindowsRAM returns the RAM of a given windows machine
    .PARAMETER ComputerName
        Computer name or ip if running remotely.
    .PARAMETER LAdminCredentials
        Admin credential object.
    .OUTPUTS
        int
        .RAM on success
        0 when credentials are NULL or RAM not found
        -1 when unknown error
#>
Function Get-WindowsRAM {
    [CmdletBinding()]
    [OutputType([int])]
    Param(
        [Parameter(Mandatory = $False, Position = 0)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $False, Position = 1)]
        [pscredential]
        $LAdminCredentials
    )

    Process {

        $respCode = 3

        Write-LogInfo "Inside Function Get-WindowsRAM."
        
        Write-LogDebug "Input ComputerName :: $ComputerName"
        Write-LogDebug "Input LAdminCredentials :: $LAdminCredentials"

        try {
            If (!(StringNullOrEmpty $ComputerName)) {
                If ($null -eq $LAdminCredentials) {
                    $respCode = 0
                    Write-LogError "Credentials are NULL."
                    Write-LogInfo "Exiting Function Get-WindowsRAM with response :: $respCode"
                    return $respCode
                }
                
                Write-LogDebug "Invoke-Command -ComputerName $ComputerName -ScriptBlock { (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property capacity -Sum | % { [Math]::Round(($_.sum / 1GB), 2) }) } -credential $LAdminCredentials"
                $respCode = Invoke-Command -ComputerName $ComputerName -ScriptBlock { (Get-WMIObject -class Win32_PhysicalMemory | Measure-Object -Property capacity -Sum | % { [Math]::Round(($_.sum / 1GB), 2) }) } -credential $LAdminCredentials
            }

            If (StringNullOrEmpty $respCode) {
                Write-LogError "Could not find the RAM."
                $respCode = 0
            }
            Else {
                Write-LogDebug "Found the RAM :: $respCode"
            }

        }
        catch {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage" 
            $respCode = -1
        }
        Write-LogInfo "Exiting Function Get-WindowsRAM with response :: $respCode"
        return $respCode
    }
}
  
 