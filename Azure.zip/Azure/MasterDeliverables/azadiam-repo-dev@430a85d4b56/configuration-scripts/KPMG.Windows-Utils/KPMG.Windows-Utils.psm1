#Import pre-requisite modules
Import-Module KPMG.Common-Utils

#Get public and private function definition files.
$Public = @( Get-ChildItem -Path $PSScriptRoot\public\*.ps1 -ErrorAction SilentlyContinue )
$Private = @( Get-ChildItem -Path $PSScriptRoot\private\*.ps1 -ErrorAction SilentlyContinue )

#Load module source files
Foreach ($import in @($Public + $Private)) {
    try {
        . $import.fullname
    }
    catch {
        Write-Error -Message "Failed to import function $($import.fullname): $_"
    }
}

Set-Variable -Name SCRIPT_PATH -Value (Split-Path (Resolve-Path $myInvocation.MyCommand.Path)) -Scope local
Set-Variable -Name FULL_SCRIPT_PATH -Value (Resolve-Path $myInvocation.MyCommand.Path) -Scope local
Set-Variable -Name CURRENT_PATH -Value ((Get-Location).Path) -Scope local

#Export Windows util functions
Export-ModuleMember -Function Add-ReverseDNSZone
Export-ModuleMember -Function Restart-ComputerWSMan
Export-ModuleMember -Function Add-WinFeature
Export-ModuleMember -Function Get-DotNet4Version
Export-ModuleMember -Function Rename-AndReboot
Export-ModuleMember -Function Set-InterfaceDNS
Export-ModuleMember -Function Wait-ForConnection
Export-ModuleMember -Function Submit-WinCommand
Export-ModuleMember -Function Get-InterfaceAliasByIP
Export-ModuleMember -Function Get-PSSession
Export-ModuleMember -Function Find-ServiceStatus
Export-ModuleMember -Function Get-WinOS
Export-ModuleMember -Function Find-outboundPortStatus
Export-ModuleMember -Function Get-WindowsRAM