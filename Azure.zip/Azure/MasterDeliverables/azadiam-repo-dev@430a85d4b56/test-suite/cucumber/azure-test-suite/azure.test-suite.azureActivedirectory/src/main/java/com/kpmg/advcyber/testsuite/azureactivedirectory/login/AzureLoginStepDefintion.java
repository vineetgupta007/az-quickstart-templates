/**
 * 
 */
package com.kpmg.advcyber.testsuite.azureactivedirectory.login;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.kpmg.advcyber.testsuite.azureactivedirectory.AzurePortal;
import com.kpmg.advcyber.testsuite.selenium.SeleniumUIOperation;
import com.kpmg.advcyber.testsuite.selenium.SeleniumWebDriver;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.When;

/**
*
* This is class is used to perform  Azure Login feature cucumber step definition 
*/
public class AzureLoginStepDefintion {
private static Logger log = Logger.getLogger(AzureLoginStepDefintion.class);
	
	SeleniumWebDriver webDriverUtils;
	SeleniumUIOperation loginpage ;
	AzurePortal azurePortal;
	
	public AzureLoginStepDefintion(SeleniumWebDriver webDriverUtils,SeleniumUIOperation loginpage,AzurePortal azurePortal) throws Exception {
		this.webDriverUtils = webDriverUtils;
		this.loginpage = loginpage;
		this.azurePortal = azurePortal;
		
	}
	public AzureLoginStepDefintion() throws Exception{
		webDriverUtils = new SeleniumWebDriver();
		loginpage = new SeleniumUIOperation(webDriverUtils);
		azurePortal = new AzurePortal(webDriverUtils,loginpage);
		
	}
	/**
	 * @param data
	 * @throws Exception
	 * Perform When operation of Azure Login
	 */
	@When("^Login into Azure Application$")
	public void login_into_Azure_Application(DataTable data) throws Exception{
		log.info("------Start step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
		
		HashMap<String, Object> inputData=new HashMap<String, Object>();
		List<Map<String,Object>> inputRows = data.asMaps(String.class, Object.class);
		
		for(Map<String,Object> row:inputRows) {
			inputData.put((String) row.get("AttributeName"), row.get("AttributeValue"));
		}
		log.info("Input Data " + inputData);
		
		boolean success = azurePortal.validateAuthenticationonPortal((String)inputData.get("applicationURL"),(String)inputData.get("userName"),(String)inputData.get("Password"), (String)inputData.get("validateText"));
		log.info("success :" + success);
		if(success) {
			log.info("This Use Case is successfully completed");
		}else {
			log.info("------End step with error " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
			throw new Exception("This use has error >>>> Login Failure on Azure Application");
		}
		log.info("------End step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
			
	}
}
