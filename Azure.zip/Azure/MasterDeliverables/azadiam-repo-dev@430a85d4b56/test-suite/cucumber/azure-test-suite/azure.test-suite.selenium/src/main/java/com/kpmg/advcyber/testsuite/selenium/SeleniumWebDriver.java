package com.kpmg.advcyber.testsuite.selenium;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxDriverLogLevel;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.BrowserVersion;

import io.github.bonigarcia.wdm.WebDriverManager;


/**
 *
 * This class is used to load Web browser configuration and launch web browser
 *
 */
public class SeleniumWebDriver {

	private Logger log = Logger.getLogger(SeleniumWebDriver.class);
	//private GenericUtils genericUtils = new GenericUtils();
	protected WebDriver driver;
	Properties properties = null;
	private  ChromeDriverService service;
	//GlobalTestData globalTestData = new GlobalTestData();
	
	/**
	 * Refresh the Browser
	 */
	public void refreshBrowser() {
		driver.navigate().refresh();
		driver.navigate().to(driver.getCurrentUrl());
	}
	
	/**
	 * @return
	 * return web driver
	 */
	public WebDriver getDriver() {
		return driver;
	}

	/**
	 * @param driver
	 * set the web driver
	 */
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * @param applicationURL
	 * @param browserName
	 * @return
	 * accept application URL and browser and launch browser with application URL
	 */
	public  HashMap<String, Object> launchApplicationInBrowser(String applicationURL, String browserName){
		log.info("Driver setup started..." + browserName + ",  URL : " + applicationURL);
		HashMap<String, Object> response = new HashMap<String, Object>();
		
		try {
			//properties = genericUtils.getConfigProperties();
			System.setProperty("browser", browserName);
			
			long implicitWaitTime, pageLoadWaitTime;
			//String browserpath = "";
			implicitWaitTime = 15;
//			implicitWaitTime = (properties.getProperty("browser.implicit.wait") != null) ? Long
//					.parseLong(properties.getProperty("browser.implicit.wait"))
//					: 15;
//			pageLoadWaitTime = (properties.getProperty("browser.pageload.wait") != null) ? Long
//					.parseLong(properties.getProperty("browser.pageload.wait"))
//					: 60;
			pageLoadWaitTime = 60;
			switch (browserName.toUpperCase()) {
		        case "FIREFOX":
		        	WebDriverManager.firefoxdriver().setup();
//		        	browserpath = (properties.getProperty("webdriver.gecko.driver.file.path") != null) ? properties
//							.getProperty("webdriver.gecko.driver.file.path").toString() : "";
//							
//					System.setProperty("webdriver.gecko.driver", browserpath);
					System.setProperty("browser","FIREFOX");
					
					final FirefoxProfile firefoxProfile = new FirefoxProfile();
					firefoxProfile
							.setPreference("xpinstall.signatures.required", false);
	
					FirefoxOptions ffOptions = new FirefoxOptions();
					ffOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
					this.setDriver(new FirefoxDriver());
					
		            break;
		            
		        case "CHROME" :
		        	WebDriverManager.chromedriver().setup();
//		        	browserpath = (properties.getProperty("webdriver.chrome.driver.file.path") != null) ? properties
//							.getProperty("webdriver.chrome.driver.file.path").toString() : "";
//					System.setProperty("webdriver.chrome.driver", browserpath);
					System.setProperty("browser","Chrome");
					
//					service = new ChromeDriverService.Builder()
//					        .usingDriverExecutable(new File(browserpath))
//					        .usingAnyFreePort()
//					        .build();
//					try {
//						service.start();
//					} catch (IOException e) {
//						
//						e.printStackTrace();
//					}
				    
				    ChromeOptions options = new ChromeOptions();
				    options.addArguments("start-maximized");
				    options.addArguments("screenshot");
				    options.addArguments("--no-sandbox");
			        options.addArguments("--disable-dev-shm-usage");
				    options.setAcceptInsecureCerts(true);
				    options.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
				    options.setCapability("applicationCacheEnabled", false);
				    options.setExperimentalOption("useAutomationExtension", false);
				    //options.setBinary(browserpath);
				    //options.setCapability(key, value);
				    //options.setPageLoadStrategy(strategy);
				    if(properties.getProperty("webdriver.browser.headless").equalsIgnoreCase("true")){
				    	options.addArguments("--headless");
				    }
				    
					this.setDriver(new RemoteWebDriver(service.getUrl(), options));
					
				    //this.setDriver(new ChromeDriver());
					
					break;
		        	
		        case "INTERNETEXPLORER":
		        	WebDriverManager.iedriver().setup();
//		        	browserpath = (properties.getProperty("webdriver.ie.driver.file.path") != null) ? properties
//							.getProperty("webdriver.ie.driver.file.path").toString() : "";
//		        							
//					System.setProperty("webdriver.ie.driver", browserpath);
		        	System.setProperty("browser","INTERNETEXPLORER");
		        	
		        	InternetExplorerOptions ieOptions = new InternetExplorerOptions();
		        	//ieOptions.setCapability(CapabilityType.BROWSER_NAME, "IE");
		        	ieOptions.setCapability(InternetExplorerDriver.
							  INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		        	ieOptions.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		        	ieOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
					this.setDriver(new InternetExplorerDriver(ieOptions));
		            break;
		           
		        case "SAFARI": 
		        	break;
		        
		        case "HTMLUNIT":
		        	
		        	System.setProperty("browser","HTMLUNIT");
		        	
		        	//this.setDriver(new HtmlUnitDriver(true));
		        	//this.setDriver(new HtmlUnitDriver(BrowserVersion.BEST_SUPPORTED, true));
		        	
		        	break;	
		        
		        case "PHANTOMJS":
		        	WebDriverManager.phantomjs().setup();
//		        	browserpath = (properties.getProperty("webdriver.phantomjs.driver.file.path") != null) ? properties
//							.getProperty("webdriver.phantomjs.driver.file.path").toString() : "";
					
					DesiredCapabilities	caps = new DesiredCapabilities();
					//caps.setCapability("PHANTOMJS_GHOSTDRIVER_PATH_PROPERTY", browserpath);
					//caps.setCapability("phantomjs.binary.path", browserpath);
					//caps.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY, browserpath);
					//caps.setCapability(PhantomJSDriverService.PHANTOMJS_PAGE_SETTINGS_PREFIX,"Y");
					caps.setCapability("phantomjs.page.settings.userAgent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:16.0) Gecko/20121026 Firefox/16.0");
					caps.setCapability("takesScreenshot", true);
					caps.setCapability("cssSelectorsEnabled", true);
					caps.setCapability("javascriptEnabled", true);
					caps.setCapability("nativeEvents", true);
					caps.setCapability("userAgent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/538.1 (KHTML, like Gecko) PhantomJS/2.1.1 Safari/538.1");
					//caps.setCapability("", value);
					
					//System.setProperty("PHANTOMJS_GHOSTDRIVER_PATH_PROPERTY", browserpath);
		        	//System.setProperty("phantomjs.binary.path", browserpath);
					System.setProperty("browser","PHANTOMJS");
					System.setProperty("headless.browser","true");
				
		        	        
					this.setDriver(new PhantomJSDriver(caps));
		            break;
		            
		        default:
		        	WebDriverManager.firefoxdriver().setup();
//		        	browserpath = (properties.getProperty("webdriver.gecko.driver.file.path") != null) ? properties
//							.getProperty("webdriver.gecko.driver.file.path").toString() : "";
//					System.setProperty("webdriver.gecko.driver", browserpath);
					final FirefoxProfile firefoxProfile1 = new FirefoxProfile();
					firefoxProfile1.setPreference("xpinstall.signatures.required", false);
					this.setDriver(new FirefoxDriver());
		            break;
			} 
			
			this.getDriver().manage().deleteAllCookies();
			this.getDriver().get(applicationURL);
			this.getDriver().manage().window().maximize();	
			this.getDriver().manage().timeouts()
					.implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
			this.getDriver().manage().timeouts()
					.pageLoadTimeout(pageLoadWaitTime, TimeUnit.SECONDS);
			
			response.put("message", "success");
			log.info("Driver setup with ...");
			log.info("baseURL..." + applicationURL);
			log.info("implicitWaitTime..." + implicitWaitTime + "Seconds.");
			log.info("pageLoadWaitTime..." + pageLoadWaitTime + "Seconds.");
			log.info("Driver setup .....Completed.");
		} catch (Exception ex) {
			response.put("message", "Error in launching application");
			response.put("exception", Arrays.toString(ex.getStackTrace()));
		}
		return response;
	}
	
	/**
	 * @param browserName
	 * @throws Exception
	 * accept browser and set Web Driver
	 */
	public  void setUpDriver(String browserName,String headlessMode) throws Exception{
		log.info("Start - Web Driver setup....");
		try {
		
		
		
//		headlessMode = (properties.getProperty("webdriver.browser.headless") != null) ? properties
//				.getProperty("webdriver.browser.headless").toString() : "false";
//		log.info("Headless mode is - " + headlessMode.toString());
		System.out.println("Headless mode is - " + headlessMode.toString());
		System.out.println(browserName);
			switch (browserName.toUpperCase()) {
		        case "FIREFOX":
		        	WebDriverManager.firefoxdriver().setup();
//		        	log.info("Firefox browser setup....started");
//		        	browserpath = (properties.getProperty("webdriver.gecko.driver.file.path") != null) ? properties
//							.getProperty("webdriver.gecko.driver.file.path").toString() : "";
//							
//					System.setProperty("webdriver.gecko.driver", browserpath);
					System.setProperty("browser","FIREFOX");
					
					final FirefoxProfile firefoxProfile = new FirefoxProfile();
					firefoxProfile.setPreference("xpinstall.signatures.required", false);
					firefoxProfile.setPreference("dom.disable_beforeunload", true);
					
					FirefoxOptions ffOptions = new FirefoxOptions();
					ffOptions.setProfile(firefoxProfile);
					ffOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
					ffOptions.addPreference("extensions.logging.enabled", false);
					ffOptions.setLogLevel(FirefoxDriverLogLevel.ERROR);
					
					if(headlessMode.equalsIgnoreCase("true")){
						ffOptions.setHeadless(true);	
					}
					this.setDriver(new FirefoxDriver(ffOptions));
					log.info("Firefox browser setup....End");
		            break;
		            
		        case "CHROME" :
		        	WebDriverManager.chromedriver().setup();
		        	
//		        	browserpath = (properties.getProperty("webdriver.chrome.driver.file.path") != null) ? properties
//							.getProperty("webdriver.chrome.driver.file.path").toString() : "";
//					System.setProperty("webdriver.chrome.driver", browserpath);
					
					log.info("Chrome browser setup....Start");
					
					System.setProperty("browser","Chrome");
				    ChromeOptions options = new ChromeOptions();
		
			        options.addArguments("start-maximized"); // open Browser in maximized mode
			        options.addArguments("disable-infobars"); // disabling infobars
			        options.addArguments("--disable-extensions"); // disabling extensions
			        options.addArguments("--disable-gpu"); // applicable to windows os only
			        options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
			        options.addArguments("--no-sandbox"); // Bypass OS security model
				    options.addArguments("screenshot");// add screenshot capabilities in headless mode
				   
				    if(headlessMode.equalsIgnoreCase("true")){
				    	options.addArguments("--headless");	
				    }
				    options.setExperimentalOption("useAutomationExtension", false);
				    
				    options.setAcceptInsecureCerts(true);
				    options.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
				    //options.setBinary(browserpath);
				    //options.setCapability(key, value);
				    //options.setPageLoadStrategy(strategy);
				   
					//this.setDriver(new RemoteWebDriver(service.getUrl(), options));
				    this.setDriver(new ChromeDriver(options));
					break;
		        	
		        case "INTERNETEXPLORER":
		        	WebDriverManager.iedriver().setup();
//		        	browserpath = (properties.getProperty("webdriver.ie.driver.file.path") != null) ? properties
//							.getProperty("webdriver.ie.driver.file.path").toString() : "";
//		        							
//					System.setProperty("webdriver.ie.driver", browserpath);
		        	System.setProperty("browser","INTERNETEXPLORER");
		        	
		        	InternetExplorerOptions ieOptions = new InternetExplorerOptions();
		        	//ieOptions.setCapability(CapabilityType.BROWSER_NAME, "IE");
		        	
		        	ieOptions.setCapability(InternetExplorerDriver.
							  INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		        	ieOptions.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		        	ieOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
					this.setDriver(new InternetExplorerDriver(ieOptions));
		            break;
		           
		        case "SAFARI": 
		        	break;
		        
		        case "HTMLUNIT":
		        	
		        	System.setProperty("browser","HTMLUNIT");
		        	
		        	this.setDriver(new HtmlUnitDriver(BrowserVersion.getDefault()));	        	
		        	break;	
		        
		        case "PHANTOMJS":
		        	WebDriverManager.phantomjs().setup();
//		        	browserpath = (properties.getProperty("webdriver.phantomjs.driver.file.path") != null) ? properties
//							.getProperty("webdriver.phantomjs.driver.file.path").toString() : "";
					
					DesiredCapabilities	caps = new DesiredCapabilities();
					//caps.setCapability("PHANTOMJS_GHOSTDRIVER_PATH_PROPERTY", browserpath);
					//caps.setCapability("phantomjs.binary.path", browserpath);
					//caps.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY, browserpath);
					//caps.setCapability(PhantomJSDriverService.PHANTOMJS_PAGE_SETTINGS_PREFIX,"Y");
					caps.setCapability("phantomjs.page.settings.userAgent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:16.0) Gecko/20121026 Firefox/16.0");
					caps.setCapability("takesScreenshot", true);
					caps.setCapability("cssSelectorsEnabled", true);
					caps.setCapability("javascriptEnabled", true);
					caps.setCapability("nativeEvents", true);
					caps.setCapability("userAgent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/538.1 (KHTML, like Gecko) PhantomJS/2.1.1 Safari/538.1");
					//caps.setCapability("", value);
					
					//System.setProperty("PHANTOMJS_GHOSTDRIVER_PATH_PROPERTY", browserpath);
		        	//System.setProperty("phantomjs.binary.path", browserpath);
					System.setProperty("browser","PHANTOMJS");
					System.setProperty("headless.browser","true");
				
		        	        
					this.setDriver(new PhantomJSDriver(caps));
		            break;
		            
		        default:
		        	WebDriverManager.firefoxdriver().setup();
//		        	browserpath = (properties.getProperty("webdriver.gecko.driver.file.path") != null) ? properties
//							.getProperty("webdriver.gecko.driver.file.path").toString() : "";
//					System.setProperty("webdriver.gecko.driver", browserpath);
					final FirefoxProfile firefoxProfile1 = new FirefoxProfile();
					firefoxProfile1.setPreference("xpinstall.signatures.required", false);
					this.setDriver(new FirefoxDriver());
		            break;
		            
			}
			
		this.getDriver().manage().deleteAllCookies();
		this.getDriver().manage().window().maximize();
		log.info("Webdriver is set with browser - " + browserName);		
		log.info("End - Web Driver setup....");
	}catch(Exception ex) {
		log.error(ex.toString());
	}
	}

	/**
	 * @param testEnvironment
	 * @param browserName
	 * accept test environment name and browser and set Web driver
	 */
	
	/**
	 * launch application using base URL
	 */
//	public  void launchApplication(){
//		long implicitWaitTime = 0, pageLoadWaitTime = 0;
//		String baseURL = null;
//		
//		try {
//			//properties = genericUtils.getConfigProperties();
//			baseURL = getBaseURL();
//			implicitWaitTime = 15;
//			pageLoadWaitTime = 60;
//			
//		} catch (Exception e) {
//			log.error(e.toString());
//			e.printStackTrace();
//		}
//				
//		this.getDriver().get(baseURL);
//		this.getDriver().manage().timeouts()
//				.implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
//		this.getDriver().manage().timeouts()
//				.pageLoadTimeout(pageLoadWaitTime, TimeUnit.SECONDS);
//		
//		log.info("Application launched with ...");
//		log.info("baseURL..." + baseURL);
//		log.info("implicitWaitTime..." + implicitWaitTime + "Seconds.");
//		log.info("pageLoadWaitTime..." + pageLoadWaitTime + "Seconds.");
//		log.info("Driver setup .....Completed.");
//	}
//	
	/**
	 * @param application
	 * accept application name and launch application
	 */
	public  void launchApplication(String baseURL){
		long implicitWaitTime = 0, pageLoadWaitTime = 0;
		
		
		try {
//			properties = genericUtils.getConfigProperties();
//			if(application.equalsIgnoreCase("Azure")){
//				baseURL = properties.getProperty("azure.webdriver.base.url");
//			}
//			if(application.equalsIgnoreCase("identity")){
//				baseURL = getIdentityBaseURL();
//			}else if(application.equalsIgnoreCase("Sysadmin")) {
//				baseURL = getSysadminBaseURL();
//			}
			implicitWaitTime= 15;
			pageLoadWaitTime = 60;
			
			
		} catch (Exception e) {
			log.error(e.toString());
			e.printStackTrace();
		}
				
		this.getDriver().get(baseURL);
		this.getDriver().manage().timeouts()
				.implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
		this.getDriver().manage().timeouts()
				.pageLoadTimeout(pageLoadWaitTime, TimeUnit.SECONDS);
		
		log.info("Application launched with ...");
		log.info("baseURL..." + baseURL);
		log.info("implicitWaitTime..." + implicitWaitTime + "Seconds.");
		log.info("pageLoadWaitTime..." + pageLoadWaitTime + "Seconds.");
		log.info("Driver setup .....Completed.");
	}
	
	
	/**
	 * @return
	 * return Web Driver 
	 */
	public WebDriver getDriverInstance() {
		return driver;
	}

	/**
	 * Shutdown the web driver 
	 */
	public  void shutDownDriver() {
		
		try{		
			String browserName = System.getProperty("browser");
			System.out.println("browserName :" + browserName);
			switch (browserName.toUpperCase()) {
	        	case "FIREFOX":
	        		
	        		Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe");
	        		Runtime.getRuntime().exec("taskkill /F /IM plugin-container.exe");
	        		Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
	        		this.getDriver().quit();
	        		break;
	        	
	        	case "CHROME" :
	        		this.getDriver().quit();
	        		break;
	        	
	        	case "INTERNETEXPLORER":
	        		this.getDriver().quit();
	        		break;
	        	
	        	default:
	        		this.getDriver().quit();
			}
			
		}catch(Exception ex){
			log.error("Closing browser error - " + ex.toString());	
		}
	}
	
	/**
	 * @param element
	 * @return
	 * Accept web element and wait for the some time
	 */
	public  WebElement waitforElementToBeClickable(WebElement element){
		return (new WebDriverWait(this.getDriver(), 120))
				.until(ExpectedConditions.elementToBeClickable(element));
						
	}
	
	/**
	 * @param element
	 * @return
	 * Accept web element and return JavascriptExecuter web element
	 */
	public  WebElement scrolltoElement(WebElement element){
		((JavascriptExecutor) this.getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
		return element;
	}
	
	/**
	 * @param element
	 * Move Web element on the browser
	 */
	public  void moveToElement(WebElement element) {
		 Actions builder = new Actions(this.getDriver());
         Action mouseOverHome = builder
                 .moveToElement(element)
                 .build();
         mouseOverHome.perform(); 
	}
 
	/**
	 * @param locator
	 * @return
	 * wait for presence of element using locator 
	 */
	public  WebElement waitforPresenceOfElement(By locator){
		return (new WebDriverWait(this.getDriver(), 120))
				.until(ExpectedConditions.presenceOfElementLocated(locator));
	}
	
	/**
	 * @param driver
	 * accept web driver , take screen shot and save file on directory
	 */
	public  void takeScreenShot(WebDriver driver) {
		if (driver != null) {
			File scrFile = ((TakesScreenshot) driver)
					.getScreenshotAs(OutputType.FILE);

			try {
				String fileNameToCopy = "target/custom-test-reports/"
						+ getCurrentTime() + ".jpeg";
				FileUtils.copyFile(scrFile, new File(fileNameToCopy));
//				Reporter.log("[Console Log] Screenshot saved in "
//						+ genericUtils.getCurrentTime() + ".jpeg");
			} catch (IOException ex) {
				// Log error message
			}
		}
	}
	
	/**
	 * @return
	 * return current Time 
	 */
	public String getCurrentTime() {
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss:SSS");
		Date dt = new Date();
		return dateFormat.format(dt);
	}

	/**
	 * @param element
	 * @param value
	 * Accept web element , value and set value by visible text in drop down 
	 */
	public  void selectValueFromDropDownList(WebElement element,
			String value) {
		try {
				Select selectValue = new Select(element);
				element.click();
				selectValue.selectByVisibleText(value);
				//element.sendKeys(Keys.ENTER);
				log.info("Val - " + value
						+ " selected");

		} catch (Exception ex) {
			log.error("Value or dropdownlist does not found." + ex);
		}
	}
	
	/**
	 * @param element
	 * @param value
	 * Accept web element , value and set value by value  in drop down
	 */
	public  void selectByValueFromDropDownList(WebElement element,
			String value) {
		try {
				Select selectValue = new Select(element);
				element.click();
				selectValue.selectByValue(value);
				//element.sendKeys(Keys.ENTER);
				log.info("Val - " + value
						+ " selected");

		} catch (Exception ex) {
			log.error("Value or dropdownlist does not found." + ex);
		}
	}

	/**
	 * @param element
	 * Accept web element and perform check operation of checkbox 
	 */
	public  void checktheCheckBox(WebElement element){
		try{
			if(!element.isSelected()){
				Actions action = new Actions(getDriver());
				action.moveToElement(element).build().perform();
				action.click(element).perform();
				//element.click();
			}else{
				log.info("Check box is already checked" );
			}
		}catch(Exception ex){
			log.error("Check box does not checked" + ex);
		}
	}
	
	/**
	 * @param element
	 * Accept web element and perform un-check operation of checkbox
	 */
	public  void unchecktheCheckBox(WebElement element){
		try{
			if(element.isSelected()){
				Actions action = new Actions(getDriver());
				action.moveToElement(element).build().perform();
				action.click(element).perform();
				//element.click();
			}else{
				log.info("Check box is already unchecked" );
			}
		}catch(Exception ex){
			log.error("Check box does not get unchecked" + ex);
		}
	}
	
	/**
	 * @param element
	 * Accept web element and high light element on browser
	 */
	public  void hightLightElement(WebElement element){
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].setAttribute('style,'border: solid 2px red'');", element);
	}
	
 	/**
 	 * @param text
 	 * @return
 	 * Check text present on browser and return true OR false
 	 */
 	public  boolean isTextPresent(String text) {
		try {
			boolean b = driver.getPageSource().contains(text);
			return b;
		} catch (Exception e) {
			return false;
		}
	}

//	/**
//	 * @return
//	 * @throws Exception
//	 * return Base URL from Configuration file 
//	 */
//	private  String getBaseURL() throws Exception {
//		String baseUrl = null;
//		Properties properties = genericUtils.getConfigProperties();
//	
//		baseUrl = properties.getProperty("webdriver.base.url");
//				
//		log.info("Base URL - " + baseUrl);
//
//		return baseUrl;
//	}
//	

	
	/**
	 * @param element
	 * scroll down element on browser
	 */
	public  void scrollDown(WebElement element){

		JavascriptExecutor js = (JavascriptExecutor) getDriver();
				js.executeScript("arguments[0].scrollIntoView();", element);
				log.info("Scrolled to the element");
			
	}
	
	/**
	 * scroll down at bottom on the browser
	 */
	public  void scrollDownAtBottom(){

		JavascriptExecutor js = (JavascriptExecutor) getDriver();
				js.executeScript("window.scrollTo(0, document.body.scrollHeight)");;
				log.info("Scrolled to the bottom of the web page ");
	}
	
	/**
	 * @param element
	 * @return
	 * Accept Web element and return element text 
	 */
	public  String getCellText(WebElement element){
		String text=null;
		text=element.getText().toString();
		log.info("Text fetched : "+text);
		return text;
		
		
	}
}
