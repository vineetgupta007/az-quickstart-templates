/**
 * 
 */
package com.kpmg.advcyber.testsuite.selenium;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Arrays;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;


/**
 * 
 * THis is usefull for Selenium web UI operations
 */
public class SeleniumUIOperation {
	private static Logger log = Logger.getLogger(SeleniumUIOperation.class);
	private SeleniumWebDriver webDriverUtils ;
	private WebElement textField;
	private WebElement btnLogin;
	private WebElement label;
	private WebElement image;
	public SeleniumUIOperation(SeleniumWebDriver webDriverUtils) {
		this.webDriverUtils = webDriverUtils;
	}
	
	/**
	 * @param value
	 * @param elementXpath
	 * @return
	 * Perform filling operation on text field
	 */
	public boolean fillTextField(String value, String elementXpath) {
		try {
			Thread.sleep(10000);
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_ESCAPE);
			r.keyRelease(KeyEvent.VK_ESCAPE);
			Thread.sleep(10000);
			
			textField = webDriverUtils.waitforElementToBeClickable(webDriverUtils.getDriver().findElement(PageObjects.getElementIdentifier(elementXpath)));
				
			textField.clear();
			textField.sendKeys(value);
			
			return true;
			
			
		}catch(Exception ex) {
			log.error("User name does not got filled");
			log.error(Arrays.toString(ex.getStackTrace()));
			return false;
		}
	}
	
	/**
	 * @param elementXpath
	 * @return
	 * Perform Click operation on button
	 */
	public boolean clickOnBUtton(String elementXpath) {
		try {
			btnLogin = webDriverUtils.waitforElementToBeClickable(webDriverUtils
					.getDriver().findElement(PageObjects.getElementIdentifier(elementXpath)));
			btnLogin.click();
			//Thread.sleep(2000);
			log.info("Login button is clicked");
			return true;
		}catch(Exception ex) {
			log.error("Login button does not clicked");
			log.error(Arrays.toString(ex.getStackTrace()));
			return false;
		}
	}
	
	/**
	 * @param elementXpath
	 * @return
	 * Accept label Xpath and return text of label
	 */
	public String getLabelText(String elementXpath) {
		String labelText  = null;
		try {
			label = webDriverUtils.waitforElementToBeClickable(webDriverUtils
					.getDriver().findElement(PageObjects.getElementIdentifier(elementXpath)));
			
			labelText = webDriverUtils.getCellText(label);
			
		}catch(Exception ex) {
			log.error("Login button does not clicked");
			log.error(Arrays.toString(ex.getStackTrace()));
			
		}
		return labelText;
	}
	
	/**
	 * @param elementXpath
	 * @return
	 * Accept xPath of Image and return source attribute of image
	 */
	public String getImageSrc(String elementXpath) {
		String imageSrc = null;
		try {
			image = webDriverUtils.waitforElementToBeClickable(webDriverUtils
					.getDriver().findElement(PageObjects.getElementIdentifier(elementXpath)));
			
			imageSrc = image.getAttribute("src");
			
		}catch(Exception ex) {
			log.error("Login button does not clicked");
			log.error(Arrays.toString(ex.getStackTrace()));
			
		}
		
		return imageSrc;
	}
}
