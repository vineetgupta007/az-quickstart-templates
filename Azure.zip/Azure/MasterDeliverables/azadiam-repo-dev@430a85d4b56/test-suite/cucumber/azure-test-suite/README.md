Change Parent module directory on Command prompt to build All modules and run following command

mvn clean install

After built all modules zip file will be created in bin folder. Change to bin directory , extract zip file and run following bat file on command promt


ExecuteTestCase.bat

