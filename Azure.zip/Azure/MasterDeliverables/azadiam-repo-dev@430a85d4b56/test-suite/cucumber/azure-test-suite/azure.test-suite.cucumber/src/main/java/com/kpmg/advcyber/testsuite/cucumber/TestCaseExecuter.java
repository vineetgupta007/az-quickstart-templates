/**
 * 
 */
package com.kpmg.advcyber.testsuite.cucumber;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * @author kpmg
 *
 */
public class TestCaseExecuter {
	private static Logger log = Logger.getLogger(TestCaseExecuter.class);
	public static void main(String[] argv) {
		String logFile = "Resources/log4j.properties";
		File file = new File(logFile);
		System.out.println(file.getAbsolutePath());
		PropertyConfigurator.configure(file.getAbsolutePath());
		
		File testSuiteFile = new File("AzureTestSuite.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        try {
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(testSuiteFile);
			doc.getDocumentElement().normalize();
			log.info("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("test");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				 Node nNode = nList.item(temp);
				 
				 if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					 ArrayList<String> list = new ArrayList<String>();
					 Element eElement = (Element) nNode;
					 String testcase = eElement.getAttribute("name");
					 log.info("\ntestcase :" + testcase);
					 String featureFileName = eElement.getElementsByTagName("featurefile").item(0).getTextContent();
					 log.info("\nfeatureFileName :" + featureFileName);
					 NodeList glueList = eElement.getElementsByTagName("glueClassPath");
					 for(int index = 0;index < glueList.getLength();index++ ) {
						
						 Node glueNode = glueList.item(index);
						 String gluePath = glueNode.getTextContent();
						 list.add("--glue");
						 list.add(gluePath);
						 log.info("\ngluePath :" + gluePath);
					 }
					 
					 if(!list.isEmpty()) {
						 list.add("--plugin");
						 list.add("pretty");
						 list.add("--plugin");
						 String htmlReport = "html:target/" + testcase + "-html-report";
						 list.add(htmlReport);
						 list.add(featureFileName);
						 String[] are = new String[0];
						 are = list.toArray(are);
						 for(String ar : are) {
							 log.info("\nar :" + ar);
						 }
//						 
						 io.cucumber.core.cli.Main.run(are, CucumberMainRunner.class.getClassLoader());
					 }else {
						 
					 }
					 
					 
					 
				 }
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
//		String[] are = new String[] {
//				"--glue",
//				"com.kpmg.advcyber.testsuite.branding",
//				"--plugin",
//				"pretty",
//				"--plugin",
//				"html:target/cucumber-html-report",
//				"features/AzureBranding.feature"
//				};
		
	}
}
