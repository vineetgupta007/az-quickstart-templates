/**
 * 
 */
package com.kpmg.advcyber.testsuite.activedirectory;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;

import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import static javax.naming.directory.SearchControls.SUBTREE_SCOPE;

/**
 * @author kpmg
 * This class is used for Active directory operation like create , update
 */
public class ActiveDirectoryOperation {
	private static Logger log = Logger.getLogger(ActiveDirectoryOperation.class);
	private String configFilePath = "Resources/config.properties";
	private DirContext dctx = null;
	private String host ;
	private String port;
	private String AdminUserDN ;
	private String password ;
	private String domainName;
	Properties configProperties = null;
	private String[] userAttributes = {
	        "distinguishedName","cn","name","uid",
	        "sn","givenname","memberOf","samaccountname",
	        "userPrincipalName"
	    };
	
	public ActiveDirectoryOperation() {
		
	}
	public ActiveDirectoryOperation(String host, String port,String AdminUserDN,String password,String domainName) throws Exception{
		this.host = host;
		this.port = port;
		this.AdminUserDN = AdminUserDN;
		this.password = password;
		this.domainName = domainName;
		
		String url = "ldaps://"+this.host+ ":" + this.port;
		
		Hashtable<Object, Object> env = new Hashtable<Object, Object>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, url);
		env.put(Context.SECURITY_PRINCIPAL, this.AdminUserDN);
		env.put(Context.SECURITY_CREDENTIALS, this.password);
		env.put(Context.SECURITY_PROTOCOL,"ssl");
		
		dctx = new InitialDirContext(env);
	}
	/**
	 * @param shortDomainName
	 * @return
	 * @throws Exception
	 * This function accept Domain Name short name like US, UK and fetch connection details from properties file and establish connection.
	 */
	public boolean setConnection(String shortDomainName) throws Exception {
		log.info("------Start step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
		boolean connectionSuccess = false;
		configProperties = new Properties();
		File configfileLocation = new File(configFilePath);
		InputStream inputStream = new FileInputStream(configfileLocation);
		configProperties.load(inputStream);
		
		this.host = configProperties.getProperty(shortDomainName + "_Host");
		this.port = configProperties.getProperty(shortDomainName + "_Port");
		this.AdminUserDN = configProperties.getProperty(shortDomainName + "_AdminUserDN");
		this.password = configProperties.getProperty(shortDomainName + "_Password");
		this.domainName = configProperties.getProperty(shortDomainName + "_DomainName");
		
		String url = "ldaps://"+this.host+ ":" + this.port;
		
		Hashtable<Object, Object> env = new Hashtable<Object, Object>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, url);
		//env.put(Context.SECURITY_AUTHENTICATION, conntype);
		env.put(Context.SECURITY_PRINCIPAL, this.AdminUserDN);
		env.put(Context.SECURITY_CREDENTIALS, this.password);
		 env.put(Context.SECURITY_PROTOCOL,"ssl");
		//env.put(Context.REFERRAL, "ignore");
		
		dctx = new InitialDirContext(env);
		//dctx.bind
		
		connectionSuccess = true;
		
		return connectionSuccess;
	}
	
	/**
	 * @param username
	 * @return
	 * @throws Exception
	 * THis function check user exist in Active Directory
	 */
	public  boolean userExist(String username) throws Exception {
		boolean exist = false;
		try {
			
	        System.out.println(domainName);
	        if (domainName!=null) {
	        	String principalName = username + "@" + domainName;
	        	System.out.println(principalName);
                SearchControls controls = new SearchControls();
                controls.setSearchScope(SUBTREE_SCOPE);
                controls.setReturningAttributes(userAttributes);
                
                NamingEnumeration<SearchResult> searchResult = dctx.search( toDC(domainName), "(& (userPrincipalName="+principalName+")(objectClass=user))", controls);
                if(searchResult.hasMoreElements()) {
                	exist = true;
                }
	        }
		}catch(NamingException ex){
            throw ex;
        }
		
		return exist;
	}
	/**
	 * @param userData
	 * @param OU
	 * @return
	 * @throws Exception
	 * This function is used to create user in Active Directory
	 */
	public boolean createUser(HashMap<String,Object> userData,String OU) throws Exception{
		boolean success = false;
		final Attributes container = new BasicAttributes();
		
		final Attribute objClasses = new BasicAttribute("objectClass");
		objClasses.add("organizationalPerson");
		objClasses.add("person");
		objClasses.add("top");
		objClasses.add("user");
		container.put(objClasses);
		
		if(!userData.isEmpty()) {
			String firstName = (String)userData.get("givenName");
			String lastName = (String)userData.get("sn");
			String userName = firstName + " " + lastName;
			Set<String> attrs = userData.keySet();
			for(String attr : attrs) {
				System.out.println(attr);
				if(attr.equals("unicodePwd")) {
					 String password = (String)userData.get(attr);
					 System.out.println(password);
					 String quotedPassword = "\"" + password + "\"";
					 System.out.println(quotedPassword);
					 byte[] unicodePassword = quotedPassword.getBytes("UTF-16LE");
					 for(byte bit : unicodePassword) {
						 System.out.print(bit);
						 System.out.print(" ");
					 }
					 System.out.println();
					// byte[] unicodePassword = createUnicodePassword(password);
					 
					 Attribute attribute = new BasicAttribute(attr, unicodePassword);
					 container.put(attribute);
				}else {
					Attribute attribute = new BasicAttribute(attr, userData.get(attr));
					container.put(attribute);
				}
				
//				Attribute attribute = new BasicAttribute(attr, userData.get(attr));
//				container.put(attribute);
				
			}
			Attribute attribute = new BasicAttribute("userAccountControl", "512");
			container.put(attribute);
			
			dctx.createSubcontext(getUserDN(userName, OU), container);
			success = true;
			
		}
		
		
		System.out.println(success);
		return success;
	}
	/**
	 * @param userName
	 * @param OU
	 * @return
	 * Based on user name and OU , this function return UserDN
	 */
	private static String getUserDN(final String userName,String OU) {
		String userDN = new StringBuffer().append("cn=").append(userName).append(",").append(OU).toString();
		System.out.println(userDN);
		return userDN;
	}
	
	/**
	 * @param username
	 * @param userData
	 * @return
	 * This function is used to modify user details in Active Directory
	 */
	public boolean updateUser(String username,HashMap<String,Object> userData) {
		boolean success = false;
		
		return success;
	}
	
	/**
	 * @param domainName
	 * @return
	 * This function return domain Name in DC format.
	 */
	private String toDC(String domainName) {
        StringBuilder buf = new StringBuilder();
        for (String token : domainName.split("\\.")) {
            if(token.length()==0)   continue;   // defensive check
            if(buf.length()>0)  buf.append(",");
            buf.append("DC=").append(token);
        }
        return buf.toString();
    }
	public void fetchAttriubtes(String userName) throws Exception {
		Attributes container = dctx.getAttributes(userName);
		for (NamingEnumeration<? extends Attribute> ae = container.getAll(); ae.hasMore();) {
		    Attribute attr = (Attribute) ae.next();
		    System.out.println(attr.getID());
		}
	}
	/**
	 * @throws Exception
	 * This function is used to close Active Directory Connection.
	 */
	public void closeConnection() throws Exception{
		if(dctx != null) {
			dctx.close();
		}
	}
}
