package com.kpmg.advcyber.testsuite.activedirectory;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateUserStepDefinition {
	private static Logger log = Logger.getLogger(CreateUserStepDefinition.class);
	private ActiveDirectoryOperation activeDirectoryop; 
	public CreateUserStepDefinition() {
		activeDirectoryop = new ActiveDirectoryOperation();
	}
	
	@Given("^user_not_exist_active_directory$")
	public void user_not_exist_active_directory(DataTable data)  throws Exception{
		log.info("------Start step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
		boolean success = true;
		String message = "";
		HashMap<String, Object> inputData=new HashMap<String, Object>();
		List<Map<String,Object>> inputRows = data.asMaps(String.class, Object.class);
		
		for(Map<String,Object> row:inputRows) {
			inputData.put((String) row.get("AttributeName"), row.get("AttributeValue"));
		}
		if(inputData.containsKey("domainshortName")) {
			String domainshortName = (String)inputData.get("domainshortName");
			inputData.remove(domainshortName);
			boolean connectionSuccess = activeDirectoryop.setConnection(domainshortName);
			if(connectionSuccess) {
				String userName = (String)inputData.get("sAMAccountName");
				boolean userExist = activeDirectoryop.userExist(userName);
				if(userExist) {
					success =false;
					message = "User Already Exist";
				}else {
					message = "User Not Found";
				}
			}else {
				success =false;
				message = "AD Connection Failure";
			}
			
			activeDirectoryop.closeConnection();
			
		}else {
			success =false;
			message = "Please specify Short Domain Name";
		}
		
		if(success) {
			log.info("This Use Case is successfully completed");
		}else {
			log.info("------End step with error " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
			throw new Exception("This use has error >>>> " + message);
		}
		
	}
	
	@When("^create_user_Active_directory$")
	public void create_user_Active_directory(DataTable data) throws Exception {
		log.info("------Start step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
		boolean success = false;
		String message = "";
		HashMap<String, Object> inputData=new HashMap<String, Object>();
		List<Map<String,Object>> inputRows = data.asMaps(String.class, Object.class);
		
		for(Map<String,Object> row:inputRows) {
			inputData.put((String) row.get("AttributeName"), row.get("AttributeValue"));
		}
		
		if(inputData.containsKey("domainshortName")) {
			String domainshortName = (String)inputData.get("domainshortName");
			boolean connectionSuccess = activeDirectoryop.setConnection(domainshortName);
			inputData.remove("domainshortName");
			String OU = (String)inputData.get("OU");
			inputData.remove("OU");
			if(connectionSuccess) {
				success = activeDirectoryop.createUser(inputData, OU); 
				if(success) {
					message = "User Successfully Created";
				}else {
					message = "Exception occors while creating User";
				}
			}else {
				success =false;
				message = "AD Connection Failure";
			}
			activeDirectoryop.closeConnection();
			
		}else {
			message = "Please specify Short Domain Name";
		}
		
		if(success) {
			log.info("This Use Case is successfully completed");
		}else {
			log.info("------End step with error " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
			throw new Exception("This use has error >>>> " + message);
		}
	}
}
